import http.client
import json
import threading
import unittest
import test_live_service as fixtures
from factory_dashboard.http_server import create_server


class HttpTests(unittest.TestCase):
    def setUp(self):
        fixture=fixtures.ServiceTests()
        fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        self.service=fixture.service
        self.store=fixture.store
        self.server = create_server(self.service,'127.0.0.1',0)
        self.thread = threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()
        self.addCleanup(self.close_server)
        self.origin = 'http://127.0.0.1:' + str(self.server.server_port)

    def close_server(self):
        self.server.shutdown();self.server.server_close();self.thread.join()

    def request(self, method, path, body=None, headers=None):
        connection = http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=3)
        defaults={'Content-Type':'application/json','Origin':self.origin,'X-Factory-Token':self.server.token}
        defaults.update(headers or {})
        connection.request(method,path,json.dumps(body) if body is not None else None,defaults)
        response=connection.getresponse();data=response.read();status=response.status;connection.close()
        return status,data

    def test_round_trip_and_revision_conflict(self):
        code,data=self.request('GET','/api/report');self.assertEqual(code,200)
        rev=json.loads(data)['configuration']['revision']
        body={'revision':rev,'selection':{'provider':'p','model':'two'}}
        self.assertEqual(self.request('PUT','/api/tasks/t_abc/model',body)[0],200)
        self.assertEqual(self.request('PUT','/api/tasks/t_abc/model',body)[0],409)
        self.assertEqual(self.request('DELETE','/api/tasks/t_abc/model',{'revision':rev+1})[0],200)

    def test_write_rejects_foreign_origin_host_token_and_content_type(self):
        body={'revision':2,'selection':{'provider':'p','model':'two'}}
        for headers in ({'Origin':'https://evil.test'},{'Host':'evil.test'},{'X-Factory-Token':''},{'Content-Type':'text/plain'}):
            self.assertIn(self.request('PUT','/api/defaults/planner',body,headers)[0],(403,415))
        self.assertEqual(self.store.read().revision,2)

    def test_unknown_routes_bad_selection_and_page(self):
        self.assertEqual(self.request('GET','/../model_policy.py')[0],404)
        self.assertEqual(self.request('PUT','/api/defaults/planner',{'revision':2,'selection':{'provider':'p','model':'bad'}})[0],400)
        code,page=self.request('GET','/');self.assertEqual(code,200);self.assertIn(b'Factory',page)

    def test_non_loopback_binding_refused(self):
        with self.assertRaises(ValueError): create_server(self.service,'0.0.0.0',0)

    def test_live_profile_save_and_stale_revision(self):
        from pathlib import Path
        from factory_dashboard.profile_settings import ProfileSettings
        from factory_dashboard.profile_service import ProfileService
        home=Path(self.store.path).parent
        for role,model in [('planner','one'),('builder','two')]:
            path=home/'profiles'/role/'config.yaml';path.parent.mkdir(parents=True)
            path.write_text(json.dumps({'model':{'provider':'p','default':model},'agent':{'reasoning_effort':'high'}}))
        settings=ProfileSettings(home,self.service._catalog,json.loads,lambda p,c:p.write_text(json.dumps(c)),('low','medium','high'))
        self.server.service=ProfileService(self.service,settings)
        code,data=self.request('GET','/api/report');config=json.loads(data)['configuration']
        body={'revision':config['profiles']['planner']['revision'],'selection':{'provider':'p','model':'two'},'effort':'medium'}
        self.assertEqual(self.request('PUT','/api/profiles/planner',body,{'X-Factory-Token':''})[0],403)
        self.assertEqual(self.request('PUT','/api/profiles/planner',body)[0],200)
        self.assertEqual(self.request('PUT','/api/profiles/planner',body)[0],409)
        _,data=self.request('GET','/api/report');config=json.loads(data)['configuration']
        self.assertEqual(config['defaults']['planner']['model'],'two')
        self.assertEqual(config['tasks']['t_abc']['effective']['planner']['effort'],'medium')

import subprocess
import unittest
from pathlib import Path

class TimelineTests(unittest.TestCase):
    def test_intervals_retries_missing_history_and_overlap(self):
        script=r'''
const assert=require('node:assert/strict');
const {buildTimeline}=require('./factory_dashboard/assets/timeline.js');
const root={id:'root',assignee:'planner',attempts:[],timeline:[],stages:[
{id:'build',assignee:'builder',stage:{label:'IMPLEMENT'},status:'running',attempts:[
{id:1,profile:'builder',started_at:100,ended_at:140,status:'failed',model:'old'},
{id:2,profile:'builder',started_at:130,ended_at:null,status:'running',model:'new'},
{id:3,profile:'builder',started_at:80,ended_at:null,status:'done',model:null},
{id:4,profile:'builder',started_at:170,ended_at:160,status:'done'}]},
{id:'review',assignee:'reviewer',stage:{label:'REVIEW'},status:'ready',attempts:[]}]};
const t=buildTimeline(root,200000);
assert.equal(t.attempts.length,4);
assert.equal(t.attempts[0].duration,40);
assert.equal(t.attempts[1].duration,70);
assert.notEqual(t.attempts[0].track,t.attempts[1].track);
assert.equal(t.attempts[2].duration,null);
assert.equal(t.attempts[3].duration,null);
assert.equal(t.attempts[0].model,'old');
assert.equal(t.lanes.some(l=>l.id==='reviewer'),false);
assert.equal(t.lanes.some(l=>l.id==='planner'),false);
assert.equal(buildTimeline({id:'empty',attempts:[],stages:[],timeline:[]},0).attempts.length,0);
const completed=buildTimeline({id:'done',assignee:'planner',status:'done',attempts:[]},0);
assert.equal(completed.lanes.length,0);
assert.equal(completed.unrecorded.length,1);
'''
        result=subprocess.run(['node','-e',script],capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)

# Hermes Factory dashboard

A local HTML snapshot of Factory parent tasks, stages, attempts, recorded events, worker-session usage/cost, blockers and delivery evidence.

See [generation commands and definitions](docs/factory-dashboard.md), [approved design](docs/superpowers/specs/2026-10-16-factory-dashboard-design.md), and [validation results](docs/factory-dashboard-results.md).

No installation, server, model calls or live Factory changes are required.

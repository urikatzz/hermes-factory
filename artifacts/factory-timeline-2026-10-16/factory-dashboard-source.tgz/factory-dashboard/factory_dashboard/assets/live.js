'use strict';
(() => {
 const {el,elapsed,buildTimeline,renderTimeline}=FactoryTimeline;
 const state={report:null,selected:null,attempt:null,editing:null,busy:false,query:'',filter:'all',lastRefresh:null};
 const main=document.getElementById('main'),connection=document.getElementById('connection');
 const dateLabel=value=>value===null||value===undefined?'Not recorded':new Date(value*1000).toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'})+' · '+Intl.DateTimeFormat().resolvedOptions().timeZone;
 const runStart=root=>{const starts=[root,...(root.stages||[])].flatMap(t=>t.attempts||[]).map(a=>a.started_at).filter(v=>typeof v==='number');return starts.length?Math.min(...starts):null;};
 const num=n=>typeof n==='number'?new Intl.NumberFormat('en',{notation:'compact',maximumFractionDigits:1}).format(n):'—';
 const button=(label,fn,cls='button')=>{const b=el('button',label,cls);b.type='button';b.onclick=fn;return b;};
 async function api(path,method='GET',body){
  const response=await fetch(path,{method,headers:{'Content-Type':'application/json','X-Factory-Token':document.querySelector('meta[name=factory-token]').content},body:body===undefined?undefined:JSON.stringify(body)});
  const data=await response.json();if(!response.ok)throw new Error(data.error||`Request failed (${response.status})`);return data;
 }
 function usageLines(container,u){
  FactoryFormat.costLines(u||{}).forEach(text=>container.append(el('p',text,'muted')));
  for(const [key,label] of [['input_tokens','Input'],['output_tokens','Output'],['cache_read_tokens','Cache read'],['cache_write_tokens','Cache write'],['reasoning_tokens','Reasoning']])container.append(el('p',`${label} tokens: ${num(u?.[key])}`,'muted'));
 }
 function renderAttempt(a){
  const panel=document.getElementById('inspector');panel.replaceChildren();state.attempt=a.key;
  panel.append(el('div','ATTEMPT DETAILS','eyebrow'),el('h2',a.label),el('p',`Attempt ${a.id} · ${a.profile||'Unassigned'}`,'muted'));
  const status=el('div',null,'detail-status');status.append(el('span',a.status||'Unknown','badge'),el('span',a.verdict||a.outcome||'No verdict recorded','badge'));panel.append(status);
  panel.append(el('h3','Model used'),el('p',a.model||'Not recorded'),el('p',a.provider||'Provider not recorded','muted'));
  if(a.dispatch_selection){panel.append(el('p',`Dispatched: ${a.dispatch_selection.provider} / ${a.dispatch_selection.model} · ${a.dispatch_selection.source} · revision ${a.dispatch_selection.revision}`,'muted'));}
  panel.append(el('h3','Recorded effort'),el('p',a.effort||'Not recorded'));
  if(a.task_effort_override)panel.append(el('p',`Current task effort override: ${a.task_effort_override} (may differ from this attempt)`,'muted'));
  panel.append(el('h3','Timing'),el('p',`Duration: ${elapsed(a.duration)}`));
  for(const [key,label] of [['started_at','Started'],['ended_at','Ended']])panel.append(el('p',`${label}: ${a[key]===null||a[key]===undefined?'Not recorded':new Date(a[key]*1000).toLocaleString()}`,'muted'));
  panel.append(el('h3','Usage & cost'));usageLines(panel,a.usage);
  if(a.summary){panel.append(el('h3','Summary'),el('pre',a.summary));}if(a.error)panel.append(el('p',a.error,'error'));
  document.querySelectorAll('[data-attempt]').forEach(n=>n.classList.toggle('selected',n.dataset.attempt===a.key));
 }
 function renderOverview(root){
  const panel=document.getElementById('inspector');panel.replaceChildren();
  panel.append(el('div','RUN OVERVIEW','eyebrow'),el('h2','Delivery & evidence'),el('p',root.block_reason||'Select an execution bar to inspect an attempt.','muted'));
  panel.append(el('h3','Latest verification'),el('p',root.latest_verification||'Not recorded'));
  if(root.delivery?.url){try{const url=new URL(root.delivery.url);if(['http:','https:'].includes(url.protocol)){const a=el('a','Open recorded delivery','delivery');a.href=url.href;a.target='_blank';a.rel='noopener noreferrer';panel.append(a);}}catch{}}
  panel.append(el('h3','Usage coverage'),el('p',`${root.usage?.linked_attempts||0} / ${root.usage?.attempts||0} attempts linked`,'muted'));usageLines(panel,root.usage);
  const warnings=state.report.warnings||[];if(warnings.length)panel.append(el('p',`${warnings.length} source warnings. Missing data remains unavailable.`,'error'));
 }
 function editProfile(initialRole){
  if(state.editing)return;
  const cfg=state.report.configuration,profiles=cfg.profiles;
  if(!profiles)return;
  state.editing={profile:true};
  const dialog=el('dialog',null,'profile-dialog');
  dialog.append(el('h2','Profile model & effort'),el('p','Defaults apply to future workers. Running attempts keep their settings. Task-specific overrides take precedence.','muted'));
  const roleLabel=el('label','Factory profile'),roleSelect=el('select');roleSelect.id='profile-role';roleLabel.htmlFor=roleSelect.id;
  for(const role of Object.keys(profiles).sort()){const option=el('option',role);option.value=role;roleSelect.append(option);}
  roleSelect.value=initialRole||Object.keys(profiles).sort()[0];
  const modelLabel=el('label','Provider / model'),model=el('select');model.id='profile-model';modelLabel.htmlFor=model.id;
  const effortLabel=el('label','Reasoning effort'),effort=el('select');effort.id='profile-effort';effortLabel.htmlFor=effort.id;
  const feedback=el('p',null,'form-feedback');feedback.setAttribute('role','status');
  let revision;
  function populate(){
   const role=roleSelect.value,current=profiles[role];revision=current.revision;model.replaceChildren();effort.replaceChildren();
   const choices=[...(cfg.role_choices[role]||[])];if(!choices.some(c=>c.provider===current.provider&&c.model===current.model))choices.unshift({provider:current.provider,model:current.model});
   for(const choice of choices){const option=el('option',`${choice.provider} / ${choice.model}`);option.value=JSON.stringify(choice);model.append(option);}
   model.value=JSON.stringify({provider:current.provider,model:current.model});
   for(const value of current.effort_choices){const option=el('option',value);option.value=value;effort.append(option);}effort.value=current.effort||'';
   feedback.textContent=`Current default: ${current.model} · effort ${current.effort||'provider default'}`;
  }
  roleSelect.onchange=populate;populate();
  const controls=el('div',null,'form-controls');
  function close(){state.editing=null;dialog.close();dialog.remove();render();}
  const cancel=button('Close',close,'button secondary');
  const save=button('Save profile',async()=>{
   save.disabled=cancel.disabled=roleSelect.disabled=true;feedback.textContent='Saving…';let saved=false;
   try{
    await api(`/api/profiles/${encodeURIComponent(roleSelect.value)}`,'PUT',{revision,selection:JSON.parse(model.value),effort:effort.value});saved=true;
    state.report=await api('/api/report');close();connection.textContent='Profile saved · future workers only';
   }catch(error){feedback.textContent=(saved?'Profile saved, but refresh failed. Close and reload. ': 'Not saved. ')+error.message;feedback.classList.add('error');}
   finally{save.disabled=saved;cancel.disabled=roleSelect.disabled=false;}
  },'button primary');controls.append(save,cancel);
  dialog.append(roleLabel,roleSelect,modelLabel,model,effortLabel,effort,el('p','Effort levels are Hermes settings; providers may normalize unsupported levels. Attempt details show recorded session effort.','muted'),feedback,controls);
  dialog.addEventListener('cancel',event=>{event.preventDefault();if(!cancel.disabled)close();});document.body.append(dialog);dialog.showModal();
 }
 function editModel(role){
  if(role&&state.report.configuration.profiles){editProfile(role);return;}
  if(state.editing)return;
  const root=state.report.parents.find(r=>r.id===state.selected),cfg=state.report.configuration;
  if(!root)return;
  const taskCfg=cfg.tasks[root.id];
  const options=role?cfg.role_choices[role]:taskCfg?.choices;
  const panel=document.getElementById('inspector');panel.replaceChildren();
  if(!options?.length){panel.append(el('h2','No compatible choices'),el('p',taskCfg?.error||'Refresh the configured model catalog for these agents.','muted'));return;}
  state.editing={revision:cfg.revision,role,root:root.id};
  const title=role?'Agent default':'Task model override';
  panel.append(el('div','MODEL SETTINGS','eyebrow'),el('h2',title),el('p',role?`Saved for ${role} across tasks. A task override takes precedence.`:'Use one model for every agent in this task.','muted'));
  const label=el('label','Provider / model');label.htmlFor='model-choice';const select=el('select');select.id='model-choice';
  options.forEach(choice=>{const option=el('option',`${choice.provider} / ${choice.model}`);option.value=JSON.stringify(choice);select.append(option);});
  const initial=role?cfg.defaults[role]:taskCfg.override;
  if(initial){const match=options.find(c=>c.provider===initial.provider&&c.model===initial.model);if(match)select.value=JSON.stringify(match);}
  const affected=el('p',`Affects future attempts: ${role||taskCfg.roles.join(', ')}`,'affected');
  const feedback=el('p',null,'form-feedback');feedback.setAttribute('role','status');
  const controls=el('div',null,'form-controls');
  const cancel=button('Cancel',()=>{state.editing=null;render();},'button secondary');
  const save=button('Save model',()=>saveModel(false),'button primary');
  const reset=button('Use agent defaults',()=>saveModel(true),'button secondary');
  controls.append(save,cancel);if(!role)controls.append(reset);
  async function saveModel(clear){
   save.disabled=reset.disabled=cancel.disabled=true;feedback.textContent='Saving…';
   const target=role?`/api/defaults/${encodeURIComponent(role)}`:`/api/tasks/${encodeURIComponent(root.id)}/model`;
   try{
    const updated=await api(target,clear?'DELETE':'PUT',{revision:state.editing.revision,...(clear?{}:{selection:JSON.parse(select.value)})});
    state.report.configuration=updated;state.editing=null;render();connection.textContent='Saved locally · future attempts only';
   }catch(error){feedback.textContent=error.message+' Your selection has not been saved.';feedback.classList.add('error');}
   finally{save.disabled=reset.disabled=cancel.disabled=false;}
  }
  panel.append(label,select,affected,el('p','Running and completed attempts keep their recorded model.','muted'),controls,feedback);
  select.focus();
 }
 function render(){
  if(!state.report||state.editing)return;
  const oldScroll=document.querySelector('.timeline-scroll')?.scrollLeft||0;
  const report=state.report;main.replaceChildren();
  const heading=el('div',null,'page-heading');const words=el('div');words.append(el('div','WORKSPACE / EXECUTIONS','eyebrow'),el('h1','Software factory'),el('p','Follow the work. Understand every handoff.','subtitle'));heading.append(words,el('span',report.demo?'DEMO WORKSPACE':'LOCAL WORKSPACE','workspace-badge'));main.append(heading);if(report.configuration.profiles)heading.append(button('Profile settings',()=>editProfile(null),'button secondary'));
  const running=report.parents.flatMap(r=>[r,...r.stages]).flatMap(t=>t.attempts||[]).filter(a=>a.status==='running');
  main.append(el('p',running.length?`Running now: ${running.map(a=>`${a.profile} · ${a.model||'model not recorded'} · effort ${a.effort||'not recorded'}`).join(' / ')}`:'No Factory attempts running now','subtitle'));
  const banner=el('div',report.configuration.mode,'preview-banner');main.append(banner);
  const layout=el('div',null,'workspace-layout'),sidebar=el('aside',null,'task-sidebar');
  const sideHead=el('div',null,'section-head');sideHead.append(el('h2','Tasks'),el('span',String(report.parents.length),'count'));sidebar.append(sideHead);
  const search=el('input');search.type='search';search.placeholder='Find a task…';search.value=state.query;search.setAttribute('aria-label','Search tasks');
  const filter=el('select');filter.setAttribute('aria-label','Filter task status');for(const value of ['all','running','blocked','done']){const opt=el('option',value==='all'?'All statuses':value);opt.value=value;filter.append(opt);}filter.value=state.filter;
  sidebar.append(search,filter);const list=el('div',null,'task-list');sidebar.append(list);
  function renderList(){list.replaceChildren();report.parents.filter(r=>(state.filter==='all'||r.status===state.filter)&&r.title.toLowerCase().includes(state.query.toLowerCase())).forEach(root=>{
   const b=button('',()=>{state.selected=root.id;state.attempt=null;state.editing=null;render();},'task-item'+(state.selected===root.id?' active':''));
   b.dataset.focusKey='task:'+root.id;
   b.append(el('span',root.status,'task-state '+root.status),el('strong',root.title.replace(/^FACTORY:\s*/,'')),el('small',`${root.stages.length} stages · ${root.execution_retries} retries`));b.append(el('small','Run: '+dateLabel(runStart(root))));list.append(b);
  });if(!list.children.length)list.append(el('p','No matching tasks.','muted'));}
  search.oninput=()=>{state.query=search.value;renderList();};filter.onchange=()=>{state.filter=filter.value;renderList();};renderList();
  sidebar.append(el('p',`${report.unlinked_tasks.length} unlinked tasks · ${report.coverage?.missing_attempts||0} attempts without usage links`,'sidebar-note'));
  const center=el('section',null,'run-panel');layout.append(sidebar,center);main.append(layout);
  const root=report.parents.find(r=>r.id===state.selected)||report.parents[0];
  if(!root){center.append(el('h2','No Factory tasks recorded'),el('p','Select a board containing Factory parent tasks.','muted'));return;}
  state.selected=root.id;
  const runHead=el('div',null,'run-heading');const title=el('div');title.append(el('div',`${root.id} / TIMELINE`,'eyebrow'),el('h2',root.title.replace(/^FACTORY:\s*/,'')));runHead.append(title,el('span',root.status,'badge status-'+root.status));center.append(runHead);center.append(el('p','Run started: '+dateLabel(runStart(root)),'subtitle'));
  const metrics=el('div',null,'metrics');for(const [label,value] of [['Elapsed',elapsed(root.duration_seconds)],['Recorded estimate',root.usage?.estimated_usd===null?'Unavailable':FactoryFormat.money(root.usage?.estimated_usd)],['Input tokens',num(root.usage?.input_tokens)],['Output tokens',num(root.usage?.output_tokens)],['Attempts linked',`${root.usage?.linked_attempts||0}/${root.usage?.attempts||0}`]]){const item=el('div',null,'metric');item.append(el('span',label),el('strong',value));metrics.append(item);}center.append(metrics);
  const toolbar=el('div',null,'timeline-toolbar');toolbar.append(el('span','EXECUTION TIMELINE','eyebrow'));
  const cfg=report.configuration.tasks[root.id];
  const override=button(cfg?.override?`Task model: ${cfg.override.model}`:'Set model for all agents',()=>editModel(null),'button secondary');override.dataset.focusKey='task-model';override.disabled=!cfg?.editable;toolbar.append(override);center.append(toolbar);
  const scroll=el('div',null,'timeline-scroll'),canvas=el('div',null,'timeline-canvas');scroll.append(canvas);center.append(scroll);
  const timeline=buildTimeline(root,Date.now());timeline.configuration=cfg;
  renderTimeline(canvas,timeline,a=>{if(!state.editing)renderAttempt(a);},editModel);
  center.append(el('p',`Bars show recorded attempts. ${timeline.unrecorded.length} completed tasks have no recorded attempts. Model controls affect future attempts; costs reflect linked sessions only.`,'timeline-note'));
  const inspector=el('aside',null,'inspector');inspector.id='inspector';layout.append(inspector);
  const selected=timeline.attempts.find(a=>a.key===state.attempt);if(selected)renderAttempt(selected);else renderOverview(root);
  scroll.scrollLeft=oldScroll;
  const footer=el('footer',null,'page-footer');footer.append(el('span',`Board ${report.board.id} · Snapshot ${new Date(report.generated_at).toLocaleString()}`),el('span','Local data · No provider calls on refresh'));main.append(footer);
 }
 async function refresh(){
  if(state.busy||document.hidden)return;
  state.busy=true;
  try{
   const report=await api('/api/report');state.report=report;state.lastRefresh=new Date();
   if(!state.selected)state.selected=report.parents[0]?.id;
   const active=document.activeElement,focusKey=active?.dataset.focusKey,attemptKey=active?.dataset.attempt;
   const paused=state.editing||['INPUT','SELECT'].includes(active?.tagName);
   if(!paused){
    render();
    if(focusKey||attemptKey){const replacement=[...main.querySelectorAll('button')].find(b=>focusKey?b.dataset.focusKey===focusKey:b.dataset.attempt===attemptKey);replacement?.focus({preventScroll:true});}
   }
   connection.classList.remove('stale');connection.textContent=paused?'● Refresh paused while editing':`● Updated ${state.lastRefresh.toLocaleTimeString()}`;
  }catch(error){connection.classList.add('stale');connection.textContent=`Refresh failed · ${state.lastRefresh?'last updated '+state.lastRefresh.toLocaleTimeString():'no data yet'}`;if(!state.report)main.replaceChildren(el('p',error.message,'error'));}
  finally{state.busy=false;}
 }
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
 setInterval(refresh,2000);refresh();
})();

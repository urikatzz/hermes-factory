"""Model resolution is captured before dispatch, never reconstructed from defaults."""
import json
from itertools import pairwise
from pathlib import Path

import pytest
from hermes_cli import kanban_db as kb
from hermes_cli import kanban_db_connect as kbc
from hermes_cli import kanban_db_dispatch as dispatch
from hermes_cli.plugins import get_plugin_manager


@pytest.fixture
def board(tmp_path, monkeypatch):
    home = tmp_path / '.hermes'
    home.mkdir()
    monkeypatch.setenv('HERMES_HOME', str(home))
    monkeypatch.setattr(Path, 'home', lambda: tmp_path)
    kb.init_db()
    conn = kbc.connect()
    manager = get_plugin_manager()
    saved = {k: list(v) for k, v in manager._hooks.items()}
    manager._hooks['resolve_kanban_worker_model'] = []
    yield conn, manager
    manager._hooks = saved
    conn.close()


def choice(**kwargs):
    return dict(provider='test-provider', model='chosen-model', source='task_override', revision=7, root_id='t_ab')


def test_dispatch_captures_model_before_spawn(board, all_assignees_spawnable):
    conn, manager = board
    manager._hooks['resolve_kanban_worker_model'] = [choice]
    tid = kb.create_task(conn, title='work', assignee='alice')
    observed = []
    def spawn(task, workspace, **kwargs):
        row = conn.execute('SELECT metadata FROM task_runs WHERE id=?', (task.current_run_id,)).fetchone()
        observed.append((task.model_override, task.provider_override, json.loads(row[0] or '{}')))
    result = dispatch.dispatch_once(conn, spawn_fn=spawn)
    assert result.spawned
    assert observed[0][0:2] == ('chosen-model', 'test-provider')
    assert observed[0][2]['worker_model_selection']['revision'] == 7
    assert kb.get_task(conn, tid).model_override is None


def test_resolver_failure_prevents_spawn(board, all_assignees_spawnable):
    conn, manager = board
    def broken(**kwargs): raise ValueError('model policy unavailable')
    manager._hooks['resolve_kanban_worker_model'] = [broken]
    tid = kb.create_task(conn, title='work', assignee='alice')
    spawned = []
    dispatch.dispatch_once(conn, spawn_fn=lambda *a, **k: spawned.append(a))
    assert not spawned
    row = conn.execute('SELECT outcome,error FROM task_runs WHERE task_id=?', (tid,)).fetchone()
    assert row['outcome'] == 'spawn_failed'
    assert 'model policy unavailable' in row['error']


def test_unmanaged_dispatch_keeps_native_override(board, all_assignees_spawnable):
    conn, _ = board
    kb.create_task(conn, title='ordinary', assignee='alice', model_override='native', provider_override='native-provider')
    seen = []
    dispatch.dispatch_once(conn, spawn_fn=lambda task, *a, **k: seen.append(task.model_override))
    assert seen == ['native']


def test_capture_preserves_metadata_and_rejects_duplicate_resolvers(board):
    from hermes_cli.kanban_db_worker_model import prepare_worker_model
    conn, manager = board
    tid = kb.create_task(conn, title='work', assignee='alice')
    kb.promote_task(conn, tid, actor='test')
    task = kb.claim_task(conn, tid)
    conn.execute('UPDATE task_runs SET metadata=? WHERE id=?', ('{"worker_session_id":"session"}', task.current_run_id))
    conn.commit()
    manager._hooks['resolve_kanban_worker_model'] = [choice]
    captured = prepare_worker_model(conn, task, '/tmp', 'default')
    manager._hooks['resolve_kanban_worker_model'] = [lambda **kw: {**choice(), 'model':'later', 'revision':8}]
    # Re-entering the same claimed attempt must retain its original decision.
    again = prepare_worker_model(conn, task, '/tmp', 'default')
    assert again.model_override == captured.model_override == 'chosen-model'
    metadata = json.loads(conn.execute('SELECT metadata FROM task_runs WHERE id=?', (task.current_run_id,)).fetchone()[0])
    assert metadata['worker_session_id'] == 'session'
    conn.execute('UPDATE task_runs SET metadata=NULL WHERE id=?', (task.current_run_id,))
    conn.commit()
    manager._hooks['resolve_kanban_worker_model'] = [choice, choice]
    with pytest.raises(ValueError, match='Multiple'):
        prepare_worker_model(conn, task, '/tmp', 'default')


def test_snapshot_effort_is_captured_and_reused(board):
    from hermes_cli.kanban_db_worker_model import prepare_worker_model
    conn, manager = board
    tid = kb.create_task(conn, title='work', assignee='alice')
    kb.promote_task(conn, tid, actor='test')
    task = kb.claim_task(conn, tid)
    manager._hooks['resolve_kanban_worker_model'] = [lambda **kw: {**choice(), 'effort': 'medium', 'snapshot_id': 'snapshot-a'}]
    resolved = prepare_worker_model(conn, task, '/tmp', 'default')
    assert resolved.reasoning_effort == 'medium'
    argv = dispatch._worker_argv(resolved, 'alice', None)
    assert argv[argv.index('--reasoning') + 1] == 'medium'
    assert ('-m', 'chosen-model') in list(pairwise(argv))
    assert ('--provider', 'test-provider') in list(pairwise(argv))
    manager._hooks['resolve_kanban_worker_model'] = [lambda **kw: {**choice(), 'effort': 'high', 'snapshot_id': 'snapshot-b'}]
    assert prepare_worker_model(conn, task, '/tmp', 'default').reasoning_effort == 'medium'
    metadata = json.loads(conn.execute('SELECT metadata FROM task_runs WHERE id=?', (task.current_run_id,)).fetchone()[0])
    assert metadata['worker_model_selection']['snapshot_id'] == 'snapshot-a'

"""Creation hooks run inside the transaction before any task becomes eligible."""
from pathlib import Path
import pytest
from hermes_cli import kanban_db as kb, kanban_db_connect as kbc
from hermes_cli.plugins import get_plugin_manager

@pytest.fixture
def board(tmp_path,monkeypatch):
    monkeypatch.setenv('HERMES_HOME',str(tmp_path/'home'))
    monkeypatch.setattr(Path,'home',lambda:tmp_path)
    kb.init_db();conn=kbc.connect();manager=get_plugin_manager()
    saved={k:list(v) for k,v in manager._hooks.items()}
    manager._hooks['before_kanban_task_create']=[]
    yield conn,manager
    manager._hooks=saved;conn.close()

def test_hook_precedes_insert_and_idempotent_retry(board):
    conn,manager=board;seen=[]
    def capture(task,board_path,**kwargs):
        assert conn.in_transaction
        assert conn.execute('SELECT id FROM tasks WHERE id=?',(task['id'],)).fetchone() is None
        assert Path(board_path).exists()
        seen.append(task)
    manager._hooks['before_kanban_task_create']=[capture]
    tid=kb.create_task(conn,title='FACTORY: test',idempotency_key='same')
    assert kb.create_task(conn,title='FACTORY: test',idempotency_key='same')==tid
    assert len(seen)==1

def test_hook_error_and_outer_rollback_leave_no_task(board):
    conn,manager=board
    def reject(**kwargs):raise ValueError('capture failed')
    manager._hooks['before_kanban_task_create']=[reject]
    with pytest.raises(ValueError,match='capture failed'):kb.create_task(conn,title='FACTORY: reject')
    assert conn.execute('SELECT count(*) FROM tasks').fetchone()[0]==0
    manager._hooks['before_kanban_task_create']=[]
    with pytest.raises(RuntimeError):
        with kb.write_txn(conn):
            kb.create_task(conn,title='ordinary')
            raise RuntimeError('rollback')
    assert conn.execute('SELECT count(*) FROM tasks').fetchone()[0]==0


def test_concurrent_keyed_creation_inserts_once(board, monkeypatch):
    from concurrent.futures import ThreadPoolExecutor
    from threading import Barrier, local
    from hermes_cli import kanban_db_task_creation as creation
    conn, manager = board
    path = Path(conn.execute('PRAGMA database_list').fetchone()[2])
    barrier = Barrier(2)
    thread = local()
    original = creation.existing_task
    def synchronized_lookup(connection, key):
        found = original(connection, key)
        if not getattr(thread, 'read_once', False):
            thread.read_once = True
            barrier.wait(timeout=5)
        return found
    monkeypatch.setattr(creation, 'existing_task', synchronized_lookup)
    captured = []
    manager._hooks['before_kanban_task_create'] = [lambda **kw: captured.append(kw['task']['id'])]
    def create():
        connection = kbc.connect(path)
        try:
            return kb.create_task(connection, title='TICKET: concurrent', triage=True, idempotency_key='factory-submit-concurrent')
        finally:
            connection.close()
    with ThreadPoolExecutor(max_workers=2) as executor:
        futures = [executor.submit(create) for _ in range(2)]
        ids = [future.result(timeout=10) for future in futures]
    assert ids[0] == ids[1]
    assert captured == [ids[0]]

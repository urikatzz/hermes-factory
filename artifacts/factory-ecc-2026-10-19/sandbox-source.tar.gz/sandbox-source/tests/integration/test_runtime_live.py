import io
import json
import os
from pathlib import Path
import subprocess
import tarfile
import tempfile
import unittest

from factory_sandbox.policy import AllowedDestination, AttemptIdentity, SandboxPolicy
from factory_sandbox.runtime import DockerRuntime
from factory_sandbox.workspace import WorkspaceStore


class RuntimeLiveTests(unittest.TestCase):
    def test_real_runtime_isolates_files_network_and_retains_stopped_output(self):
        image = json.loads(subprocess.check_output(["docker", "image", "inspect", "hermes-factory-sandbox-probe:local"]))[0]["Id"]
        policy = SandboxPolicy("live-1", image, image, (AllowedDestination("example.com", 443),), 1, 256, 64, 10)
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "source"
            source.mkdir()
            (source / "answer.py").write_text("answer = 41\n")
            identity = AttemptIdentity(root / "profile", "pilot", "task", "1")
            workspace = WorkspaceStore(root / "workspaces").prepare(source, identity)
            runtime = DockerRuntime(root / "runtime")
            handle = runtime.start(identity, policy, workspace)
            try:
                result = runtime.execute(handle, "cat answer.py; printf 'answer = 42\\n' > answer.py")
                self.assertEqual(result["returncode"], 0, result)
                self.assertIn("41", result["output"])
                self.assertEqual((source / "answer.py").read_text(), "answer = 41\n")
                info = json.loads(subprocess.check_output(["docker", "inspect", handle.worker_id]))[0]
                self.assertFalse(any(m["Type"] == "bind" for m in info["Mounts"]))
                self.assertEqual(runtime.execute(handle, "grep 'CapEff:' /proc/self/status")["output"].strip(), "CapEff:\t0000000000000000")
                allowed = runtime.execute(handle, "curl -fsS --max-time 5 https://example.com/")
                if allowed["returncode"]:
                    detail = runtime.execute(handle, "curl -sS --max-time 5 https://example.com/")
                    logs = runtime._call("exec", handle.gateway_id, "cat", "/tmp/policy/cache.log").stdout.decode()
                    self.fail(str(detail) + "\n" + logs)
                self.assertIn("Example Domain", allowed["output"])
                denied = runtime.execute(handle, "curl -fSs --max-time 3 http://example.com/")
                self.assertNotEqual(denied["returncode"], 0)
                self.assertIn("403", denied["output"])
                self.assertNotEqual(runtime.execute(handle, "curl --noproxy '*' -fsS --connect-timeout 1 https://1.1.1.1/")["returncode"], 0)
                background = runtime.execute(handle, "sleep 200 >/dev/null 2>&1 & echo $!")
                self.assertEqual(background["returncode"], 0)
                runtime.stop(handle)
                data = runtime.export(handle)
                with tarfile.open(fileobj=io.BytesIO(data)) as archive:
                    self.assertEqual(archive.extractfile("./answer.py").read(), b"answer = 42\n")
                with self.assertRaises(RuntimeError):
                    runtime.execute(handle, "true")
            finally:
                runtime.remove(handle, allow_missing=True)


if __name__ == "__main__":
    unittest.main()

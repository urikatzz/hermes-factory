"""Document admission must finish before Hermes can invoke any host converter."""
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import Mock, patch


class GuardTests(unittest.TestCase):
    def test_document_and_normalization_bypasses_are_blocked(self):
        root = Path(__file__).resolve().parents[2]
        spec = importlib.util.spec_from_file_location('sandbox_guard_plugin', root / '__init__.py', submodule_search_locations=[str(root)])
        module = importlib.util.module_from_spec(spec)
        import sys
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        context = Mock()
        module.register(context)
        guard = context.register_hook.call_args.args[1]
        with patch('pm.ensure_import', side_effect=AssertionError('host install attempted')):
            for path in ('/workspace/a.pdf', '/workspace/a.PDF', '/workspace/a.docx', '/workspace/a.xlsx',
                         '/workspace/a.pdf/x/..', '/workspace/a.pdf/.', '.', './', '', 'answer.py'):
                with self.subTest(path=path):
                    result = guard('read_file', {'path': path})
                    self.assertEqual(result['action'], 'block')
                    self.assertIn('host document extraction is disabled', result['message'])

"""The real plugin loader and public tool dispatcher must use the sandbox."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import unittest


class ToolRoutingTests(unittest.TestCase):
    def test_registered_plugin_routes_terminal_and_file_handlers(self):
        home = Path(os.environ["HERMES_HOME"])
        root = Path(__file__).resolve().parents[2]
        source = home / "fixture"
        source.mkdir()
        (source / "answer.py").write_text("answer = 41\n")
        image = json.loads(subprocess.check_output(["docker", "image", "inspect", "hermes-factory-sandbox-probe:local"]))[0]["Id"]
        policy = dict(revision="routing-1", worker_image=image, gateway_image=image,
                      allowed_destinations=[dict(hostname="example.com", port=443)],
                      cpu=1, memory_mb=256, pids_limit=64, command_timeout_seconds=5)
        (home / "policy.json").write_text(json.dumps(policy))
        plugin = home / "plugins/factory_sandbox"
        plugin.mkdir(parents=True)
        for name in ("__init__.py", "plugin.yaml"):
            shutil.copyfile(root / name, plugin / name)
        shutil.copytree(root / "factory_sandbox", plugin / "factory_sandbox", ignore=shutil.ignore_patterns("__pycache__"))
        import yaml
        config = dict(terminal=dict(backend="factory_sandbox", cwd="/workspace", container_persistent=False),
                      plugins=dict(enabled=["factory_sandbox"], entries={"factory_sandbox": {"settings": dict(
                          policy_path=str(home / "policy.json"), source_directory=str(source), state_root=str(home / "pilot-state"))}}),
                      platform_toolsets=dict(cli=["file", "terminal", "kanban"]))
        (home / "config.yaml").write_text(yaml.safe_dump(config))
        os.environ.update(HERMES_KANBAN_TASK="routing-task", HERMES_KANBAN_RUN_ID="1", HERMES_KANBAN_BOARD="pilot")
        from model_tools import get_tool_definitions, handle_function_call
        from agent.terminal_env_registry import get_provider
        from tools.terminal_tool_lifecycle import cleanup_vm
        from tools.terminal_tool import _resolve_container_task_id
        self.assertIsNotNone(get_provider("factory_sandbox"), "Real plugin loader did not register backend")
        task = "routing-session"
        try:
            names = {value["function"]["name"] for value in get_tool_definitions(enabled_toolsets=["terminal", "file", "kanban"], quiet_mode=True)}
            self.assertNotIn("execute_code", names)
            self.assertNotIn("delegate_task", names)
            self.assertNotIn("web_extract", names)
            from unittest.mock import patch
            with patch("pm.ensure_import", side_effect=AssertionError("Host install attempted")):
                for suffix in (".pdf", ".docx", ".PDF", ".xlsx", ".pdf/x/..", ".pdf/."):
                    denied_document = handle_function_call("read_file", {"path": "/workspace/file" + suffix}, task_id=task)
                    self.assertIn("host document extraction is disabled", str(denied_document))
            read = handle_function_call("read_file", {"path": "/workspace/answer.py"}, task_id=task)
            self.assertIn("41", str(read))
            write = handle_function_call("write_file", {"path": "/workspace/answer.py", "content": "answer = 42\n"}, task_id=task)
            self.assertNotIn('"error"', str(write), write)
            result = handle_function_call("terminal", {"command": "cat /workspace/answer.py"}, task_id=task)
            self.assertIn("42", str(result))
            denied = handle_function_call("web_extract", {"urls": ["https://example.com/"]}, task_id=task)
            self.assertIn("pilot permits only", str(denied))
            self.assertEqual((source / "answer.py").read_text(), "answer = 41\n")
        finally:
            cleanup_vm(_resolve_container_task_id(task))
        results = list((home / "pilot-state/workspaces").glob("*/result/files/answer.py"))
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].read_text(), "answer = 42\n")

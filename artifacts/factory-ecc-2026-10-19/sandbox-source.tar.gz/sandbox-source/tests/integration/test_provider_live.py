import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

try:
    from factory_sandbox.provider import FactorySandboxProvider
except ImportError:
    FactorySandboxProvider = None


class ProviderLiveTests(unittest.TestCase):
    def test_prompt_probe_does_not_consume_a_workload_attempt(self):
        self.assertIsNotNone(FactorySandboxProvider)
        provider = FactorySandboxProvider(lambda key: None, lambda root: None)
        with self.assertRaisesRegex(RuntimeError, "probe"):
            provider.create_environment(cwd="/workspace", timeout=4, task_id="prompt-backend-probe")

    def test_missing_owned_attempt_cannot_start_a_local_fallback(self):
        self.assertIsNotNone(FactorySandboxProvider, "Hermes terminal provider is missing")
        provider = FactorySandboxProvider(lambda key: None, lambda root: None)
        with self.assertRaises(ValueError):
            provider.create_environment(cwd="/workspace", timeout=10, container_config={"container_persistent": False})

    def test_real_shell_and_file_operations_share_isolated_workspace(self):
        self.assertIsNotNone(FactorySandboxProvider, "Hermes terminal provider is missing")
        from factory_sandbox.evidence import EvidenceStore
        from factory_sandbox.runtime import DockerRuntime
        from factory_sandbox.supervisor import SandboxSupervisor
        from factory_sandbox.workspace import WorkspaceStore
        from tools.file_operations import ShellFileOperations
        image = json.loads(subprocess.check_output(["docker", "image", "inspect", "hermes-factory-sandbox-probe:local"]))[0]["Id"]
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "source"
            source.mkdir()
            (source / "answer.py").write_text("answer = 41\n")
            policy = dict(revision="provider-1", worker_image=image, gateway_image=image,
                          allowed_destinations=[dict(hostname="example.com", port=443)],
                          cpu=1, memory_mb=256, pids_limit=64, command_timeout_seconds=5)
            path = root / "policy.json"
            path.write_text(json.dumps(policy))
            settings = dict(policy_path=str(path), state_root=str(root / "state"), source_directory=str(source))
            def supervisor(state):
                return SandboxSupervisor(WorkspaceStore(state / "workspaces"), DockerRuntime(state / "runtime"), EvidenceStore(state / "evidence"))
            os.environ.update(HERMES_KANBAN_TASK="provider-task", HERMES_KANBAN_RUN_ID="1", HERMES_KANBAN_BOARD="pilot")
            provider = FactorySandboxProvider(settings.get, supervisor)
            environment = provider.create_environment(cwd="/workspace", timeout=5, task_id="provider-session", container_config={"container_persistent": False})
            try:
                result = environment.execute("cat answer.py; printf 'answer = 42\\n' > answer.py")
                self.assertEqual(result["returncode"], 0, result)
                self.assertIn("41", result["output"])
                operations = ShellFileOperations(environment)
                read = operations.read_file("/workspace/answer.py")
                self.assertIn("42", str(read))
                self.assertNotEqual(environment.execute("cat /root/.hermes/.env")["returncode"], 0)
                self.assertEqual((source / "answer.py").read_text(), "answer = 41\n")
                self.assertEqual(environment.execute("cd /tmp")["returncode"], 0)
                recovered = environment.execute("pwd", cwd="/workspace")
                self.assertEqual(recovered["returncode"], 0, recovered)
                self.assertIn("/workspace", recovered["output"])
                timed_out = environment.execute("sleep 30", timeout=1)
                self.assertTrue(timed_out.get("timed_out") or timed_out.get("returncode") != 0, timed_out)
            finally:
                environment.cleanup()
            self.assertEqual((environment.result_path / "files/answer.py").read_text(), "answer = 42\n")
            environment.cleanup()  # Repeated cleanup must preserve the same result.
            evidence = json.loads(environment.evidence_path.read_text())
            self.assertEqual(evidence["result"]["exit_reason"], "timeout_or_cancelled")

from pathlib import Path
import os
import tempfile
import unittest
import io
import tarfile

try:
    from factory_sandbox.policy import AttemptIdentity
    from factory_sandbox.workspace import WorkspaceStore
except ImportError:
    AttemptIdentity = WorkspaceStore = None


class WorkspaceTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(WorkspaceStore, "Safe workspace preparation is missing")
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "source"
        self.source.mkdir()
        (self.source / "main.py").write_text("answer = 41\n")
        self.store = WorkspaceStore(self.root / "store")
        self.identity = AttemptIdentity(self.root / "profile", "pilot", "task", "1")

    def test_snapshot_excludes_credentials_git_and_caches(self):
        for name in (".env", ".git", "credentials.json", "id_ed25519", ".npmrc"):
            (self.source / name).write_text("do not export")
        (self.source / "node_modules").mkdir()
        (self.source / "node_modules/dependency").write_text("generated")
        workspace = self.store.prepare(self.source, self.identity)
        self.assertEqual([p.name for p in workspace.iterdir()], ["main.py"])
        self.assertEqual((workspace / "main.py").read_text(), "answer = 41\n")

    def test_source_links_and_special_files_are_refused(self):
        for kind in ("symlink", "hardlink", "fifo"):
            path = self.source / "unsafe"
            if kind == "symlink":
                path.symlink_to(self.source / "main.py")
            elif kind == "hardlink":
                os.link(self.source / "main.py", path)
            else:
                os.mkfifo(path)
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                self.store.prepare(self.source, self.identity)
            path.unlink()

    def test_collect_refuses_active_execution_and_reports_deletions(self):
        workspace = self.store.prepare(self.source, self.identity)
        with self.assertRaises(RuntimeError):
            self.store.collect(workspace, self.identity)
        (workspace / "main.py").unlink()
        (workspace / "new.py").write_text("answer = 42\n")
        self.store.mark_stopped(self.identity)
        result = self.store.collect(workspace, self.identity)
        import json
        changes = json.loads((result / "changes.json").read_text())
        self.assertEqual(changes["removed"], ["main.py"])
        self.assertEqual(changes["changed"], ["new.py"])

    def test_collect_refuses_substituted_workspace_root(self):
        workspace = self.store.prepare(self.source, self.identity)
        saved = workspace.with_name("saved")
        workspace.rename(saved)
        workspace.symlink_to(saved, target_is_directory=True)
        self.store.mark_stopped(self.identity)
        with self.assertRaises(ValueError):
            self.store.collect(workspace, self.identity)

    def test_duplicate_attempt_cannot_overwrite_existing_workspace(self):
        self.store.prepare(self.source, self.identity)
        with self.assertRaises(FileExistsError):
            self.store.prepare(self.source, self.identity)

    def test_untrusted_archive_cannot_escape_or_create_links(self):
        self.store.prepare(self.source, self.identity)
        self.store.mark_stopped(self.identity)
        self.assertTrue(callable(getattr(self.store, "import_archive", None)), "Bounded archive import is missing")
        for name, kind in (("../escape", tarfile.REGTYPE), ("/absolute", tarfile.REGTYPE),
                           ("link", tarfile.SYMTYPE), ("hard", tarfile.LNKTYPE), ("pipe", tarfile.FIFOTYPE)):
            stream = io.BytesIO()
            with tarfile.open(fileobj=stream, mode="w") as archive:
                info = tarfile.TarInfo(name)
                info.type = kind
                info.linkname = "/etc/passwd"
                archive.addfile(info)
            with self.subTest(name=name), self.assertRaises(ValueError):
                self.store.import_archive(stream.getvalue(), self.identity)

    def test_regular_archive_import_preserves_baseline_and_records_changes(self):
        self.store.prepare(self.source, self.identity)
        self.store.mark_stopped(self.identity)
        self.assertTrue(callable(getattr(self.store, "import_archive", None)), "Bounded archive import is missing")
        stream = io.BytesIO()
        with tarfile.open(fileobj=stream, mode="w") as archive:
            info = tarfile.TarInfo("./answer.py")
            info.size = len(b"answer = 42\n")
            archive.addfile(info, io.BytesIO(b"answer = 42\n"))
        workspace = self.store.import_archive(stream.getvalue(), self.identity)
        self.assertEqual((workspace / "answer.py").read_bytes(), b"answer = 42\n")
        self.assertTrue(self.store.collect(workspace, self.identity).is_dir())

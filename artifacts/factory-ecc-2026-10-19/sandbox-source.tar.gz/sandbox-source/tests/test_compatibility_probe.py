"""The gate must reject mounts outside the administrator's approved workspace."""

import json
import importlib.util
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


SCRIPT = Path(__file__).resolve().parents[1] / "scripts/probe_compatibility.py"


class CompatibilityGateTests(unittest.TestCase):
    def test_child_incompatibility_report_is_preserved(self):
        spec = importlib.util.spec_from_file_location("compatibility_probe", SCRIPT)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        self.assertTrue(callable(getattr(module, "read_probe_report", None)),
                        "Child exit status 2 must be treated as a gate result")
        report = module.read_probe_report([
            sys.executable, "-c",
            'import json; print(json.dumps({"composition_compatible": False})); raise SystemExit(2)',
        ], {})
        self.assertFalse(report["composition_compatible"])

    def inspect(self, mounts, network="none", privileged=False):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "inspection.json"
            output = root / "report.json"
            source.write_text(json.dumps({
                "Mounts": mounts,
                "HostConfig": {"NetworkMode": network, "Privileged": privileged},
            }))
            result = subprocess.run([
                sys.executable, str(SCRIPT), "--analyze-inspection", str(source),
                "--approved-workspace", "/fixture/job", "--output", str(output),
            ], capture_output=True, text=True)
            self.assertTrue(output.exists(), result.stderr)
            return result.returncode, json.loads(output.read_text())

    def test_readonly_profile_cache_mount_fails_boundary(self):
        code, report = self.inspect([{
            "Type": "bind", "Source": "/fixture/profile/cache/documents",
            "Destination": "/root/.hermes/cache/documents", "RW": False,
        }])
        self.assertEqual(code, 2)
        self.assertFalse(report["composition_compatible"])
        self.assertEqual(report["violations"][0]["kind"], "unapproved_bind_mount")

    def test_workspace_mount_does_not_claim_full_sandbox_verification(self):
        code, report = self.inspect([{
            "Type": "bind", "Source": "/fixture/job", "Destination": "/workspace", "RW": True,
        }])
        self.assertEqual(code, 0)
        self.assertTrue(report["composition_compatible"])
        self.assertEqual(report["network_enforcement"], "not_verified")
        self.assertFalse(report["sandbox_verified"])

    def test_workspace_prefix_collision_is_refused(self):
        code, report = self.inspect([{
            "Type": "bind", "Source": "/fixture/job-other", "Destination": "/workspace", "RW": True,
        }])
        self.assertEqual(code, 2)
        self.assertFalse(report["composition_compatible"])

    def test_host_network_or_privileged_runtime_is_refused(self):
        for network, privileged in (("host", False), ("none", True)):
            with self.subTest(network=network, privileged=privileged):
                code, report = self.inspect([], network, privileged)
                self.assertEqual(code, 2)
                self.assertFalse(report["composition_compatible"])


if __name__ == "__main__":
    unittest.main()

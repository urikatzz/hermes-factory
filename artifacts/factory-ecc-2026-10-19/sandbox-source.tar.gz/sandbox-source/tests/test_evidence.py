import json
from pathlib import Path
import tempfile
import unittest

from factory_sandbox.policy import AttemptIdentity
try:
    from factory_sandbox.evidence import EvidenceStore
except ImportError:
    EvidenceStore = None


class EvidenceTests(unittest.TestCase):
    def test_event_scope_and_final_result_are_preserved(self):
        self.assertIsNotNone(EvidenceStore, "Supervisor evidence storage is missing")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            store = EvidenceStore(root / "evidence")
            identity = AttemptIdentity(root / "profile", "pilot", "task", "1")
            store.record(identity, {"phase": "running", "policy_revision": "r1"})
            final = store.finish(identity, {"exit_reason": "cancelled", "cleanup_outcome": "removed"})
            data = json.loads(final.read_text())
            self.assertEqual(data["identity"]["task_id"], "task")
            self.assertEqual(data["events"][0]["phase"], "running")
            self.assertEqual(data["result"]["exit_reason"], "cancelled")
            self.assertEqual(store.finish(identity, data["result"]), final)

    def test_raw_environment_and_arbitrary_secret_fields_are_rejected(self):
        self.assertIsNotNone(EvidenceStore, "Supervisor evidence storage is missing")
        with tempfile.TemporaryDirectory() as directory:
            identity = AttemptIdentity(Path(directory) / "profile", "pilot", "task", "1")
            with self.assertRaises(ValueError):
                EvidenceStore(Path(directory) / "evidence").record(identity, {"environment": {"API_KEY": "synthetic"}})

from pathlib import Path
import tempfile
import unittest

try:
    from factory_sandbox.runtime import DockerRuntime, render_gateway_config
except ImportError:
    DockerRuntime = render_gateway_config = None

from factory_sandbox.policy import AllowedDestination, SandboxPolicy


class RuntimeContractTests(unittest.TestCase):
    def test_gateway_rules_keep_hostname_port_address_pairs_together(self):
        self.assertIsNotNone(render_gateway_config, "Explicit gateway policy is missing")
        policy = SandboxPolicy("r1", "sha256:" + "a"*64, "sha256:" + "b"*64,
                               (AllowedDestination("example.com", 443),), 1, 256, 64, 5)
        # Execute the rendered config against real Squid in integration; unit contract
        # only pins refusal to render unvalidated private addresses here.
        with self.assertRaises(ValueError):
            render_gateway_config(policy, {"example.com": ("127.0.0.1",)})

    def test_missing_docker_is_a_visible_startup_failure(self):
        self.assertIsNotNone(DockerRuntime, "Explicit Docker transport is missing")
        with tempfile.TemporaryDirectory() as root:
            with self.assertRaises(FileNotFoundError):
                DockerRuntime(Path(root), docker_executable="/not/an/installed/docker").doctor()

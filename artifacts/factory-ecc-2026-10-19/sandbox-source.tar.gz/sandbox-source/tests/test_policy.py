import dataclasses
import json
from pathlib import Path
import tempfile
import unittest

try:
    from factory_sandbox.policy import AttemptIdentity, load_policy
except ImportError:
    AttemptIdentity = load_policy = None


class PolicyTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(load_policy, "Sandbox policy validation is missing")
        self.data = dict(revision="pilot-1", worker_image="sha256:" + "a" * 64,
                         gateway_image="sha256:" + "b" * 64,
                         allowed_destinations=[dict(hostname="example.com", port=443)],
                         cpu=1, memory_mb=256, pids_limit=64, command_timeout_seconds=10)

    def load(self, data):
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "policy.json"
            path.write_text(json.dumps(data))
            return load_policy(path)

    def test_loaded_policy_is_frozen(self):
        policy = self.load(self.data)
        self.data["allowed_destinations"][0]["hostname"] = "evil.example"
        self.assertEqual(policy.allowed_destinations[0].hostname, "example.com")
        with self.assertRaises(dataclasses.FrozenInstanceError):
            policy.revision = "changed"

    def test_unsafe_or_ambiguous_policy_is_rejected(self):
        for change in (
            {"worker_image": "alpine:latest"}, {"cpu": 0}, {"memory_mb": True},
            {"pids_limit": -1}, {"command_timeout_seconds": 0}, {"unknown": True},
            {"allowed_destinations": [{"hostname": host, "port": port} for host, port in []]},
            *({"allowed_destinations": [{"hostname": host, "port": 443}]} for host in
              ("localhost", "127.0.0.1", "*.example.com", "host.internal", "a\nhttp_access allow all", "EXAMPLE.COM")),
            {"allowed_destinations": [{"hostname": "example.com", "port": 0}]},
            {"allowed_destinations": [{"hostname": "example.com", "port": 443}] * 2},
        ):
            with self.subTest(change=change), self.assertRaises(ValueError):
                self.load({**self.data, **change})

    def test_attempt_identity_separates_boards_profiles_and_runs(self):
        base = AttemptIdentity(Path("/fixture/profile"), "board", "task", "1")
        other = [AttemptIdentity(Path("/fixture/other"), "board", "task", "1"),
                 AttemptIdentity(Path("/fixture/profile"), "other", "task", "1"),
                 AttemptIdentity(Path("/fixture/profile"), "board", "task", "2")]
        self.assertEqual(len({base.key, *(value.key for value in other)}), 4)
        with self.assertRaises(ValueError):
            AttemptIdentity(Path("/fixture/profile"), "board", "../escape", "1")

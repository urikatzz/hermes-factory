import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock
from factory_sandbox.supervisor import SandboxSupervisor


class SupervisorTests(TestCase):
    def test_cleanup_retry_does_not_repeat_output_collection(self):
        workspace, runtime, evidence = Mock(), Mock(), Mock()
        runtime.remove.side_effect = [RuntimeError('busy'), None]
        handle = SimpleNamespace(owner='owner', identity='identity')
        supervisor = SandboxSupervisor(workspace, runtime, evidence)
        with self.assertRaises(RuntimeError):
            supervisor.finish(handle)
        supervisor.finish(handle)
        runtime.stop.assert_called_once()
        runtime.export.assert_called_once()
        workspace.collect.assert_called_once()
        self.assertEqual(runtime.remove.call_count, 2)

    def test_import_failure_records_retained_resources(self):
        workspace, runtime, evidence = Mock(), Mock(), Mock()
        workspace.import_archive.side_effect = ValueError('unsafe archive')
        supervisor = SandboxSupervisor(workspace, runtime, evidence)
        with self.assertRaises(ValueError):
            supervisor.finish(SimpleNamespace(owner='owner', identity='identity'))
        event = evidence.record.call_args.args[1]
        self.assertEqual(event['phase'], 'importing_failed')
        self.assertEqual(event['cleanup_outcome'], 'resources_retained')
        runtime.remove.assert_not_called()

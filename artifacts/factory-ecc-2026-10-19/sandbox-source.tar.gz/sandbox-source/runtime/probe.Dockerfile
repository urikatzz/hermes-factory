FROM alpine@sha256:294b683cb724975bec92580e1e685676bd4b50bda910ddb8c51d4cabeaec77e6
RUN apk add --no-cache bash python3 nftables squid ca-certificates curl openssl coreutils findutils grep
RUN addgroup -g 1000 worker && adduser -D -u 1000 -G worker worker
WORKDIR /workspace
CMD ["sleep", "infinity"]

# Hermes Factory sandbox pilot

A standalone Hermes terminal-provider plugin for a reviewed, small coding task. It runs terminal and file tools in an unprivileged Linux container with no host bind mounts or forwarded model credentials. A trusted network namespace permits only the task's allowlisting proxy; the proxy requires an approved hostname, port, and pinned public address.

The supported Hermes revision is `9e041a7428392b01b989ef9cecf46a5f96be12fc`. The coordinator, model calls, Kanban tools, and host-side Unity/publishing automation remain trusted host infrastructure. This pilot does not isolate the entire agent process or secure Unity execution.

## Build and checks

```sh
docker build -t hermes-factory-sandbox-probe:local -f runtime/probe.Dockerfile .
sh scripts/run_checks.sh
python3 scripts/probe_network.py --output /private/tmp/factory-network-report.json
python3 -m unittest discover -s tests/integration -p test_runtime_live.py -v
python3 scripts/run_hermes_checks.py \
  --hermes-source /absolute/path/to/hermes-agent \
  --hermes-python /absolute/path/to/hermes-python \
  --pattern test_provider_live.py
python3 scripts/run_hermes_checks.py \
  --hermes-source /absolute/path/to/hermes-agent \
  --hermes-python /absolute/path/to/hermes-python \
  --pattern test_tool_routing.py
```

Docker must already be running. The diagnostic gateway permits synthetic private fixtures solely inside its disposable test networks; production policy parsing rejects private/test destinations. The real runtime test uses `example.com:443` and requires internet connectivity. Image builds install trusted infrastructure dependencies before project code is introduced; workers cannot change the policy or runtime image.

## Private Factory pilot

`scripts/run_pilot.py --help` lists explicit paths for the installed Hermes source, Python, configured model, host authentication store, reviewed Factory helper, and a new output directory. It uses the existing `openai-codex` model configuration, creates a private board and two worker profiles, and runs IMPLEMENT then VERIFY through the actual dispatcher and model. The source auth store is read only; temporary host-side copies are removed at exit. Credentials never enter a worker container. The chosen login must have enough remaining lifetime for the bounded pilot; the script refuses an expiring token rather than initiating login.

The successful post-restart pilot and the earlier blocked run are described in [docs/pilot-results.md](docs/pilot-results.md). Scripts never activate the installed Factory roster or publish code.

## Runtime contract and limits

- Each attempt is keyed by profile home, board, task, and run. Existing attempts are refused rather than adopted implicitly.
- A labelled, 128 MiB tmpfs Docker volume holds job files. A trusted namespace container retains the volume while the worker stops and its output is validated. This survives worker termination, not a Docker daemon/VM restart. Completed stage snapshots and evidence are persisted on the host.
- Preparation excludes known credential filenames, Git metadata, and generated caches. Source symlinks, hardlinks, and special files are refused. Operators must select the project source intentionally; exclusion patterns are not an exhaustive secret classifier.
- Import rejects traversal, links, special files, duplicate members, and excessive file/byte counts. Output is retained in a separate result directory; it is never automatically applied over a live repository.
- Production destinations are exact lowercase hostnames and ports. Public IPv4 addresses are resolved and frozen before execution; DNS changes require a new attempt. IPv6-only upstreams and non-HTTP protocols are unsupported in this pilot. Worker IPv6 output and direct DNS remain denied by the namespace policy.
- HTTPS uses ordinary CONNECT tunnelling, without credential injection or TLS interception. The policy controls connection destinations; it does not inspect or classify data sent to an approved service.
- A command timeout stops the worker container, including background project processes. Further commands fail until a new attempt is admitted. Output is retained before resource teardown.
- Document extraction through `read_file` is blocked because Hermes converters run on the host. Use reviewed sandbox terminal commands for document processing.
- Supported worker tools are terminal, process management without handoff, file operations, tool discovery, and the listed stage status tools. The plugin blocks other public tool calls; the pilot selects a narrow schema surface. It does not replace host process isolation.

## Installation review and rollback

Keep the existing Factory profiles unchanged while reviewing the pilot. The plugin config follows Hermes's supported namespace:

```yaml
terminal:
  backend: factory_sandbox
  cwd: /workspace
  container_persistent: false
plugins:
  enabled:
    - factory_sandbox
  entries:
    factory_sandbox:
      settings:
        policy_path: /absolute/admin/path/policy.json
        source_directory: /absolute/reviewed/project
        state_root: /absolute/admin/path/sandbox-state
platform_toolsets:
  cli: [file, terminal, kanban]
```

The policy schema lives in `factory_sandbox/policy.py`; it requires pinned image references, explicit destinations, and positive resource limits. The runtime image used for the namespace must contain nftables, bash, Python, and tar; the gateway image must contain Squid and Python. `runtime/probe.Dockerfile` supplies this pilot toolchain.

Activation requires a separate reviewed profile/dispatcher change. Stop admitting pilot tasks before rollback; stop execution, retain output/evidence, then remove only resources whose ownership label matches the recorded attempt. Keep sandbox-required tasks blocked rather than silently switching them to `local`. Do not restart shared Docker infrastructure to clean up a probe without considering other running workloads.

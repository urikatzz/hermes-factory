"""Hermes plugin entry point; registration does not start Docker or change settings."""

def register(ctx):
    from pathlib import Path
    from .factory_sandbox.evidence import EvidenceStore
    from .factory_sandbox.provider import ALLOWED_TOOLS, FactorySandboxProvider
    from .factory_sandbox.runtime import DockerRuntime
    from .factory_sandbox.supervisor import SandboxSupervisor
    from .factory_sandbox.workspace import WorkspaceStore

    def supervisor(root):
        return SandboxSupervisor(WorkspaceStore(root / "workspaces"), DockerRuntime(root / "runtime"),
                                 EvidenceStore(root / "evidence"))

    def guard(tool_name, args, task_id=None, **kwargs):
        if tool_name not in ALLOWED_TOOLS:
            return {"action": "block", "message": "This pilot permits only sandbox file/terminal operations and its stage status tools."}
        if tool_name == "read_file":
            # Hermes document converters execute on the host, outside this backend.
            from tools.read_extract import EXTRACTABLE_EXTENSIONS, ANYDOC_EXTENSIONS
            import posixpath
            path = str(args.get("path", ""))
            if not posixpath.isabs(path) or ".." in path.split("/") or Path(posixpath.normpath(path)).suffix.lower() in EXTRACTABLE_EXTENSIONS | ANYDOC_EXTENSIONS:
                return {"action": "block", "message": "Read documents with sandbox terminal commands; host document extraction is disabled."}
        if tool_name == "process_manage" and args.get("action") == "handoff":
            return {"action": "block", "message": "Sandbox processes cannot be handed to host sessions."}
        from tools.terminal_tool import _get_env_config
        if _get_env_config()["env_type"] != "factory_sandbox":
            return {"action": "block", "message": "Required sandbox backend is not active."}

    ctx.register_terminal_environment_provider(FactorySandboxProvider(ctx.get_config, supervisor))
    ctx.register_hook("pre_tool_call", guard)

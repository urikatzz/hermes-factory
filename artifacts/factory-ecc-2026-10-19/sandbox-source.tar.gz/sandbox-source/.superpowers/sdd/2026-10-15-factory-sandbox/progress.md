# SDD ledger — plan: docs/superpowers/plans/2026-10-15-factory-sandbox.md

Approved spec and plan; native execution selected by approval of the recommended approach.

Workspace: /private/tmp/hermes-factory-sandbox, branch feat/factory-sandbox, base b4364b6aeb588e40401fd118d067efbe688b353c. No commits or pushes authorized.

Pre-flight: Tasks 2→3 share immutable policy, attempt identity, and prepared workspace; signatures agree. Tasks 3→4 share RuntimeHandle and execute/cleanup contract; upstream result keys must be characterized by Task 1. Tasks 4→5 share lifecycle and identity; evidence must be supervisor-owned. Tasks 2/4/5→6 share output/manifest and scoped profile contracts; full pilot depends on all gates.

Ruling: Build in a linked worktree under /private/tmp; keep approved documents copied there because they are untracked in the original checkout. Git worktree metadata creation required and received tool approval. No commits or installed-code edits.

Task 1: in progress. Docker 29.8.2 / Desktop 4.95.0 is available. Static inspection found unconditional automatic credential/skill/cache mounts in DockerEnvironment; test this integration boundary before attempting the larger network topology.

Task 1: Ruling: reorder the mount characterization before the network topology — the plan explicitly stops on unsafe composition, so early falsification avoids building a topology around an incompatible backend. Cost: network/gateway questions remain unverified.

Task 1: diagnostic harness RED→GREEN: four initial tests failed because the CLI/report did not exist, then passed. A fifth test exposed loss of child reports with compatibility exit status 2; it failed then passed after preserving that status as a normal diagnostic result. Five current tests pass.

Task 1: composition gate rejected in two real Docker runs. Credential registration case: synthetic credential/cache visible, 14 unapproved mounts. Control with no credential registration: credential absent, cache visible, 13 unapproved mounts. Both runs cleaned their owned containers; no containers remain under either unique ownership label. Network topology/proxy not exercised.

Task 1: paused at the plan's explicit compatibility checkpoint; do not mark the full task complete. Proposed amendment in docs/superpowers/specs/2026-10-15-factory-sandbox-amendment.md replaces built-in DockerEnvironment composition with an explicit transport using the documented BaseEnvironment provider contract. Installed code/live profiles remain unchanged. No commits or pushes.

User approved the explicit-transport amendment; execution resumed. Ruling: use the documented BaseEnvironment extension points and direct Docker control; do not instantiate DockerEnvironment. Task 1 continues with disposable network characterization.

Task 1: Ruling: evaluate Squid as the dedicated gateway because inspection of iron-proxy v0.39.0's allowlist/hostmatch code shows domain matching strips ports. Squid supports paired hostname/port ACLs. This is a gateway implementation choice under the existing topology and acceptance policy, not permission to relax the network boundary. Cost: no reuse of the existing credential-injection proxy; the coding container needs no provider credentials.

Task 1: explicit-transport network fixture passed: approved HTTP/TLS; proxy 403 for forbidden hostname, port and private destination; DNS denied; direct IPv4/raw TCP/host/metadata connections unavailable; effective worker caps zero; proxy death fails closed. IPv6 lacks a route, so runtime IPv6 filtering is configured but reachable-IPv6 denial is not claimed. Evidence: /private/tmp/hermes-factory-sandbox-network-copy.json. Its owned containers/networks were removed.

Task 1: Ruling: avoid host bind mounts entirely. Docker Desktop bind-mounted probe containers hung even in the escalated run. Use bounded, task-owned tmpfs Docker volumes retained by a trusted namespace container; transfer validated snapshots through container stdin/export. This narrows host exposure and bounds workspace size to 128 MiB. Two early bind-mounted gateway probes remained in Created state; their removal requests stalled. No Docker restart was attempted because other host workloads exist. Track this cleanup limitation separately from the functioning volume-based runtime.

Task 2: complete — immutable policy and descriptor-relative source copying, source link/special-file refusal, duplicate-attempt isolation, stopped-only collection, validated archive import, and deletion/change records. Tests first failed for missing behavior, then passed. Ruling: use Python unittest for this standalone plugin to avoid adding a dependency solely for the runner. Hermes integration checks use its installed dependency environment; upstream tests retain the canonical runner requirement.

Task 3: implemented explicit transport and paired hostname/port/pinned-public-address Squid policy. Live runtime test passed: independent source unchanged, no host bind mounts, zero effective capabilities, allowed HTTPS, rejected port 80, direct route unavailable, background process termination, output retained after stop. Red→green fixes: volume-nocopy preserves tmpfs UID ownership; public A records are pinned because the observed Docker bridge lacks IPv6 egress. IPv6-only approved destinations are unsupported in this pilot. No DNS re-resolution during the attempt; the frozen hosts file closes DNS rebinding into a new destination.

Task 4: real plugin loader + model_tools dispatcher integration passed. File read/write and terminal see the same container; unexpected web extraction is blocked; source remains unchanged; cleanup exports the expected result. Direct provider cancellation test exposed incorrect timeout evidence; fixed and passing. Resource-warning cleanup under the shared timeout path is being checked in the latest run.

Task 5: evidence unit tests pass; supervisor retains output before teardown, scoped final records reject raw environment fields. No completed-stage state is inferred from diagnostic tests alone.

Task 6: real-model private Kanban pilot started with the existing configured model. First real attempt correctly blocked: Hermes's reserved prompt-backend-probe provisioned and disposed the job before its first tool. Added a failing regression and now reject only that reserved probe so Hermes uses its documented environment-description fallback. A new private pilot is running. No provider substitution or live profile changes.

Review follow-up: earlier actual two-stage pilot 4 passed. Fresh review identified four Important gaps; patched document admission (with normalized-path regression), in-instance cleanup retry, collection/startup failure evidence, and pilot final evidence/artifact validation. Added bounded export read and explicit cwd recovery. Current 21 unit tests and actual-Hermes document guard test pass; previous real tool-routing passed.

Task 6 remains incomplete: upstream configuration/session suites passed 30 tests, built-in Docker backend suite timed out300s. Current standalone runtime/provider and stricter real pilot 6 blocked on namespace container starts hanging Created; pilot reports sandbox_verified=false. Docker recovery/restart requires user permission due unrelated running databases/game servers. No live profile activation, commits, or pushes. Cleanup recovery is in-instance only; restart recovery is not implemented.

2026-10-16: user restarted Docker. Revalidation passed:21 units,1 real runtime,3 real Hermes provider checks including cwd recovery/cancellation,1 document guard including relative/normalized bypasses,1 actual tool-routing check, and full network fixture (cleaned). Reviewer confirmed last document bypass closed; no remaining Important issue in that narrow review.

Strict real private pilot7 passed: IMPLEMENT t_d7a8264a and VERIFY t_283bcd63, both exit0/done, manifest9b734edbedb2. Host verified finalized removed evidence, expected content/manifest, unchanged helper/verifier snapshot/source and absence of temporary authcopies. No pilot containers remain. Old gateway removal succeeded. Milestone acceptance evidence recorded in docs/pilot-results.md; built-in upstream Docker suite remains unverified after earlier timeout, with no pass claimed. Durable recovery and production activation remain unimplemented/outside current pilot. No commits/pushes/installedprofile changes.

### Task 1: Establish the supported integration and network topology

**Files:** Create `scripts/probe_compatibility.py`, `docs/compatibility.md`. Inspect the existing interfaces listed above, their applicable `AGENTS.md` files, and Hermes's canonical test runner.

**Interfaces:** Produces a compatibility report with exact Hermes revision, Docker version, immutable image references, gateway pin, mount/environment behavior, namespace filtering behavior, and accepted provider lifecycle contract. The probe is disposable; it does not register a plugin or change a profile.

- [ ] Read the terminal-provider documentation, plugin manifest validation rules, Docker constructor and lifecycle code, file tool routing, and plugin/session identity behavior at the pinned revision.
- [ ] Inspect the existing iron-proxy protocol/configuration to establish whether it can run as a dedicated gateway with a narrow host/port allowlist, no model-provider credentials, and destination/address validation. Record the exact pinned artifact and config fields; do not infer these from `HTTPS_PROXY` support.
- [ ] Implement a disposable probe that creates uniquely labelled resources: a worker namespace, a gateway, a permitted HTTP/TLS fixture, and a denied fixture. Keep any test CA and all credentials synthetic.
- [ ] Establish the topology: worker joins the namespace container's network namespace; trusted initialization installs output filtering before project code starts; only the proxy IP/port is permitted. Worker has no `NET_ADMIN`/`NET_RAW`, no Docker socket, no host networking, no published ports, and runs unprivileged. Deny other IPv4/IPv6 output and DNS; ensure host gateway access is blocked. The gateway alone has upstream access.
- [ ] Run `python3 scripts/probe_compatibility.py --output /private/tmp/hermes-factory-sandbox-compatibility.json`. The output must include successful allowed HTTP/TLS, rejected proxy destination, rejected direct TCP/DNS/IPv6/host access, capability restrictions, and cleanup evidence. A missing Docker daemon is a failure with a setup message, not a passing skip.
- [ ] Inspect actual `DockerEnvironment` container mounts and environment with synthetic sentinels. Confirm that automatic skills/cache mounts, credential forwarding, recovery, and generated container names can be constrained to the spec without altering core.
- [ ] Record the exact compatible construction arguments and gateway config in `docs/compatibility.md`. If either gateway enforcement or safe Docker composition cannot be demonstrated, stop at this checkpoint and revise the design/plan with the evidence. Do not compensate with application-only guards, private-method monkey patches, or local fallback.


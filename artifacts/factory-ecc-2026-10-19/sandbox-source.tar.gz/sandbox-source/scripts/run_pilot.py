#!/usr/bin/env python3
"""Run a real two-stage Kanban pilot in a private Hermes home.

The original authentication file is read only; its temporary host-side copies are
removed at exit. No model credentials are forwarded or mounted into containers.
"""

import argparse
import hashlib
from dataclasses import asdict
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time


def run(args):
    import yaml
    from hermes_cli import kanban_db as db
    from hermes_cli.kanban_db_connect import connect, init_db
    from hermes_cli.kanban_db_dispatch import dispatch_once, detect_crashed_workers

    root = args.output.resolve()
    root.mkdir(mode=0o700, parents=True, exist_ok=False)
    home = root / "home"
    home.mkdir(mode=0o700)
    # HERMES_HOME was pinned by the parent before importing Hermes modules.
    if Path(os.environ["HERMES_HOME"]) != home:
        raise RuntimeError("Pilot home scope mismatch")
    report = {"sandbox_verified": False, "pilot": "running", "stages": [], "home": str(home)}
    auth_copies = []
    try:
        config_source = yaml.safe_load(args.model_config.read_text())
        model = config_source["model"]
        provider = model["provider"]
        if provider != "openai-codex":
            raise ValueError("This pilot launcher supports the inspected openai-codex host credential path only")
        auth = json.loads(args.auth_source.read_text())
        state = auth.get("providers", {}).get(provider)
        if not state:
            raise RuntimeError("Selected model provider has no authentication state; no substitution is permitted")
        from hermes_cli.auth import _codex_access_token_is_expiring
        if _codex_access_token_is_expiring(state["tokens"]["access_token"], args.timeout * 2 + 300):
            raise RuntimeError("Refresh the existing host login before running the isolated pilot")
        credential = {"version": auth.get("version", 1), "providers": {provider: state}, "active_provider": provider}
        image = json.loads(subprocess.check_output(["docker", "image", "inspect", args.image]))[0]["Id"]
        policy = dict(revision="pilot-1", worker_image=image, gateway_image=image,
                      allowed_destinations=[dict(hostname="example.com", port=443)],
                      cpu=1, memory_mb=256, pids_limit=64, command_timeout_seconds=15)
        (home / "policy.json").write_text(json.dumps(policy, indent=2))
        board = "sandbox-pilot"
        profiles = ["pilot-developer", "pilot-verifier"]
        root_config = dict(kanban=dict(dispatch_profiles=profiles, dispatch_in_gateway=False))
        (home / "config.yaml").write_text(yaml.safe_dump(root_config))
        fixture = home / "fixture"
        fixture.mkdir()
        (fixture / "answer.py").write_text("answer = 41\n")
        helper = args.factory_helper
        shutil.copyfile(helper, fixture / "fw.py")
        repo = Path(__file__).resolve().parents[1]
        for profile in profiles:
            profile_home = home / "profiles" / profile
            profile_home.mkdir(mode=0o700, parents=True)
            plugin = profile_home / "plugins/factory_sandbox"
            plugin.mkdir(parents=True)
            for name in ("__init__.py", "plugin.yaml"):
                shutil.copyfile(repo / name, plugin / name)
            shutil.copytree(repo / "factory_sandbox", plugin / "factory_sandbox", ignore=shutil.ignore_patterns("__pycache__"))
            cfg = dict(model=model, agent=dict(max_turns=12, reasoning_effort=config_source.get("agent", {}).get("reasoning_effort", "high")),
                       terminal=dict(backend="factory_sandbox", cwd="/workspace", container_persistent=False),
                       platform_toolsets=dict(cli=["file", "terminal", "kanban"]),
                       kanban=dict(dispatch_in_gateway=False),
                       plugins=dict(enabled=["factory_sandbox"], entries={"factory_sandbox": {"settings": dict(
                           policy_path=str(home / "policy.json"), state_root=str(root / "state"), source_directory=str(fixture))}}))
            if "approvals" in config_source:
                cfg["approvals"] = config_source["approvals"]
            (profile_home / "config.yaml").write_text(yaml.safe_dump(cfg))
            (profile_home / "SOUL.md").write_text(
                "You are a coding pilot worker. Complete your assigned Kanban task with evidence. "
                "Your terminal and file tools use /workspace inside an isolated Linux sandbox. "
                "Use absolute /workspace paths. Do not attempt host paths or publishing.\n")
            auth_path = profile_home / "auth.json"
            fd = os.open(auth_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "w") as stream:
                json.dump(credential, stream)
            auth_copies.append(auth_path)
        db.create_board(board, name="Sandbox pilot")
        init_db(board=board)
        conn = connect(board=board)
        try:
            stages = [
                (profiles[0], "IMPLEMENT sandbox fixture", "Change /workspace/answer.py from answer = 41 to answer = 42. "
                 "Create /workspace/.factory/PLAN.md with a short plan and /workspace/.factory/include.txt containing answer.py on one line. "
                 "Run python3 /workspace/fw.py manifest /workspace. Complete this task using kanban_complete and include the manifest sha12 in the result. "
                 "Do not use git or modify fw.py. No dependency installation is required."),
                (profiles[1], "VERIFY sandbox fixture", "Independently verify /workspace/answer.py contains answer = 42, "
                 "run python3 /workspace/fw.py check /workspace and report its sha12. Do not change source files. "
                 "Complete this task using kanban_complete only if both checks pass."),
            ]
            for index, (profile, title, body) in enumerate(stages):
                if index:
                    previous = report["stages"][-1]
                    evidence = json.loads(Path(previous["evidence_path"]).read_text())
                    delivered = Path(evidence["result"]["result_path"]) / "files"
                    cfg_path = home / "profiles" / profile / "config.yaml"
                    cfg = yaml.safe_load(cfg_path.read_text())
                    cfg["plugins"]["entries"]["factory_sandbox"]["settings"]["source_directory"] = str(delivered)
                    cfg_path.write_text(yaml.safe_dump(cfg))
                task_id = db.create_task(conn, title=title, body=body, assignee=profile,
                                         workspace_kind="dir", workspace_path=str(fixture), max_runtime_seconds=args.timeout, board=board)
                dispatched = dispatch_once(conn, max_spawn=1, max_in_progress=1, board=board)
                task = db.get_task(conn, task_id)
                pid = task.worker_pid
                stage = dict(task_id=task_id, assignee=profile, dispatch=str(dispatched), worker_pid=pid)
                report["stages"].append(stage)
                if not pid:
                    raise RuntimeError("Private-board dispatcher did not start its worker")
                deadline = time.monotonic() + args.timeout
                while time.monotonic() < deadline:
                    task = db.get_task(conn, task_id)
                    ended, status = os.waitpid(pid, os.WNOHANG)
                    if ended:
                        stage["worker_exit"] = os.waitstatus_to_exitcode(status)
                        break
                    time.sleep(1)
                else:
                    os.killpg(pid, signal.SIGTERM)
                    raise RuntimeError("Pilot worker exceeded its bounded runtime")
                task = db.get_task(conn, task_id)
                stage["task_status"] = task.status
                records = list((root / "state/evidence").glob("*/attempt.json"))
                evidence_path = next((path for path in records if json.loads(path.read_text())["identity"]["task_id"] == task_id), None)
                if evidence_path:
                    stage["evidence_path"] = str(evidence_path)
                if task.status != "done" or stage["worker_exit"] != 0 or evidence_path is None:
                    raise RuntimeError("Private worker did not deliver a completed, retained sandbox result; inspect its scoped log")
                evidence = json.loads(evidence_path.read_text())
                final = evidence.get("result", {})
                if final.get("cleanup_outcome") != "removed" or final.get("exit_reason") != "session_end":
                    raise RuntimeError("Sandbox evidence is not successfully finalized")
                delivered = Path(final["result_path"]) / "files"
                if (delivered / "answer.py").read_text() != "answer = 42\n":
                    raise RuntimeError("Retained answer does not match the pilot requirement")
                if (delivered / "fw.py").read_bytes() != helper.read_bytes():
                    raise RuntimeError("Worker modified the trusted Factory helper")
                manifest = (delivered / ".factory/SHA256SUMS").read_bytes()
                expected = "".join(hashlib.sha256((delivered / name).read_bytes()).hexdigest() + "  " + name + "\n"
                                   for name in (".factory/PLAN.md", ".factory/include.txt", "answer.py"))
                if manifest.decode() != expected:
                    raise RuntimeError("Retained manifest does not identify the expected file")
                stage["manifest_sha12"] = hashlib.sha256(manifest).hexdigest()[:12]
                if index:
                    previous_files = Path(json.loads(Path(report["stages"][0]["evidence_path"]).read_text())["result"]["result_path"]) / "files"
                    before = {p.relative_to(previous_files): p.read_bytes() for p in previous_files.rglob("*") if p.is_file()}
                    after = {p.relative_to(delivered): p.read_bytes() for p in delivered.rglob("*") if p.is_file()}
                    if before != after:
                        raise RuntimeError("Verifier changed the delivered snapshot")
                if (fixture / "answer.py").read_text() != "answer = 41\n":
                    raise RuntimeError("Original fixture was modified")
                db.add_comment(conn, task_id, "sandbox-supervisor", "Retained sandbox evidence: " + str(evidence_path))
        finally:
            conn.close()
        report["pilot"] = "passed"
        report["sandbox_verified"] = True
    except Exception as error:
        report["pilot"] = "blocked"
        report["error"] = str(error)
    finally:
        for path in auth_copies:
            path.unlink(missing_ok=True)
        (root / "pilot.json").write_text(json.dumps(report, indent=2) + "\n")
    return 0 if report["pilot"] == "passed" else 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--hermes-source", type=Path, required=True)
    parser.add_argument("--hermes-python", type=Path, required=True)
    parser.add_argument("--auth-source", type=Path, required=True)
    parser.add_argument("--model-config", type=Path, required=True)
    parser.add_argument("--factory-helper", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--timeout", type=int, default=180)
    parser.add_argument("--image", default="hermes-factory-sandbox-probe:local")
    parser.add_argument("--child", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.child:
        return run(args)
    env = {key: os.environ[key] for key in ("PATH", "HOME", "DOCKER_HOST", "DOCKER_CONTEXT", "DOCKER_CONFIG") if key in os.environ}
    env.update(HERMES_HOME=str(args.output.resolve() / "home"), PYTHONDONTWRITEBYTECODE="1",
               PYTHONNOUSERSITE="1", PYTHONPATH=os.pathsep.join((str(Path(__file__).resolve().parents[1]), str(args.hermes_source.resolve()))))
    return subprocess.run([str(args.hermes_python), str(Path(__file__).resolve()), *sys.argv[1:], "--child"], env=env).returncode


if __name__ == "__main__":
    raise SystemExit(main())

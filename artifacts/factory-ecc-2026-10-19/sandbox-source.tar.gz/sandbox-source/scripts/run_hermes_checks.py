#!/usr/bin/env python3
"""Run scoped integration checks with installed Hermes dependencies and synthetic state."""
import argparse
import os
from pathlib import Path
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--hermes-source", type=Path, required=True)
parser.add_argument("--hermes-python", type=Path, required=True)
parser.add_argument("--pattern", default="test_provider_live.py")
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix="factory-hermes-checks-") as temporary:
    env = {key: os.environ[key] for key in ("PATH", "HOME", "DOCKER_HOST", "DOCKER_CONTEXT", "DOCKER_CONFIG") if key in os.environ}
    env.update(HERMES_HOME=temporary, PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1",
               PYTHONPATH=os.pathsep.join((str(root), str(args.hermes_source))))
    result = subprocess.run([str(args.hermes_python), "-m", "unittest", "discover", "-s", "tests/integration", "-p", args.pattern, "-v"], cwd=root, env=env)
    raise SystemExit(result.returncode)

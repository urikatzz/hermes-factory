#!/usr/bin/env python3
"""Disposable Linux namespace/proxy experiment; not a production gateway config.

Private fixture exceptions exist only in this diagnostic, never in a pilot policy.
"""

import argparse
import json
import os
import shlex
from pathlib import Path
import subprocess
import tempfile
import time
import uuid


def docker(*args, check=True, stdin=None):
    print("docker " + " ".join(map(str, args[:4])), flush=True)
    return subprocess.run(["docker", *map(str, args)], input=stdin, text=True,
                          capture_output=True, timeout=60, check=check)


def ip(container, network):
    info = json.loads(docker("inspect", container).stdout)[0]
    return info["NetworkSettings"]["Networks"][network]["IPAddress"]


def run(output):
    owner = "fs-probe-" + uuid.uuid4().hex[:10]
    image = json.loads(docker("image", "inspect", "hermes-factory-sandbox-probe:local").stdout)[0]["Id"]
    containers, networks, results = [], [], {}
    report = {"owner": owner, "image": image, "checks": results, "sandbox_verified": False}

    def start(suffix, net, *command, extra=(), user="1000:1000", caps=()):
        name = owner + "-" + suffix
        containers.append(name)
        docker("run", "-d", "--name", name, "--label", "factory-sandbox-network-probe=" + owner,
               "--network", net, "--cap-drop", "ALL", *caps,
               "--security-opt", "no-new-privileges", "--pids-limit", "64",
               "--memory", "256m", "--cpus", "1", "--read-only", "--user", user,
               "--tmpfs", "/tmp:rw,nosuid,nodev,size=32m", *extra, image, *command)
        return name

    def execute(worker, *command):
        return docker("exec", worker, *command, check=False)

    def expect(name, result, allowed, content=None):
        ok = (result.returncode == 0) if allowed else (result.returncode != 0)
        if content is not None:
            ok = ok and content in result.stdout
        results[name] = {"passed": ok, "returncode": result.returncode,
                         "stdout": result.stdout[-700:], "stderr": result.stderr[-700:]}
        if not ok:
            raise RuntimeError(f"Network probe check failed: {name}")

    with tempfile.TemporaryDirectory(prefix="factory-network-probe-", dir="/private/tmp") as temporary:
        root = Path(temporary).resolve()
        os.chmod(root, 0o755)
        config = root / "policy"
        config.mkdir(mode=0o755)
        job = root / "job"
        job.mkdir(mode=0o777)
        try:
            for suffix in ("worker", "fixture"):
                network = owner + "-" + suffix
                docker("network", "create", "--internal", "--label", "factory-sandbox-network-probe=" + owner, network)
                networks.append(network)
            worker_net, fixture_net = networks
            fixture_code = (
                "import http.server,ssl,threading; "
                "h=http.server.SimpleHTTPRequestHandler; "
                "a=http.server.HTTPServer(('0.0.0.0',8000),h); "
                "b=http.server.HTTPServer(('0.0.0.0',8443),h); "
                "c=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); c.load_cert_chain('/tmp/cert','/tmp/key'); "
                "b.socket=c.wrap_socket(b.socket,server_side=True); "
                "threading.Thread(target=a.serve_forever,daemon=True).start(); b.serve_forever()"
            )
            fixture = start("fixture", fixture_net, "sh", "-c",
                            "cd /tmp; echo FIXTURE-OK > index.html; "
                            "openssl req -x509 -newkey rsa:2048 -nodes -keyout key -out cert -days 1 "
                            "-subj /CN=approved.test >/dev/null 2>&1; exec python3 -c " + shlex.quote(fixture_code))
            fixture_ip = ip(fixture, fixture_net)
            (config / "hosts").write_text(f"{fixture_ip} approved.test private.test forbidden.test\n")
            # Only the synthetic approved.test endpoint bypasses private-address denial here.
            (config / "squid.conf").write_text(f"""http_port 3128
visible_hostname factory-probe
pid_filename none
cache_log /dev/stderr
access_log stdio:/dev/stdout
cache_store_log none
cache deny all
shutdown_lifetime 1 seconds
hosts_file /policy/hosts
acl fixture_host dstdomain -n approved.test
acl fixture_ports port 8000 8443
acl fixture_ip dst {fixture_ip}/32
http_access allow fixture_host fixture_ports fixture_ip
acl private_host dstdomain -n private.test
acl private_port port 8000
acl private_dst dst 0.0.0.0/8 10.0.0.0/8 100.64.0.0/10 127.0.0.0/8 169.254.0.0/16 172.16.0.0/12 192.168.0.0/16 ::1/128 fc00::/7 fe80::/10
http_access deny private_dst
http_access allow private_host private_port
http_access deny all
""")
            gateway = start("gateway", worker_net, "sleep", "infinity")
            docker("exec", gateway, "mkdir", "/tmp/policy")
            for name in ("hosts", "squid.conf"):
                content = (config / name).read_text().replace("/policy/hosts", "/tmp/policy/hosts")
                docker("exec", "-i", gateway, "sh", "-c", "cat > /tmp/policy/" + name, stdin=content)
            docker("exec", "-d", gateway, "squid", "-N", "-f", "/tmp/policy/squid.conf")
            docker("network", "connect", fixture_net, gateway)
            gateway_ip = ip(gateway, worker_net)
            namespace = start("namespace", worker_net, "sleep", "infinity", user="0:0", caps=("--cap-add", "NET_ADMIN"))
            rules = f"""table inet factory {{
chain output {{ type filter hook output priority -200; policy drop;
udp dport 53 counter drop
tcp dport 53 counter drop
oifname "lo" accept
ip daddr {gateway_ip} tcp dport 3128 counter accept
counter drop
}}
chain input {{ type filter hook input priority -200; policy drop;
iifname "lo" accept
ct state established,related accept
counter drop
}}
}}
"""
            docker("exec", "-i", namespace, "nft", "-f", "-", stdin=rules)
            worker = start("worker", "container:" + namespace, "sleep", "infinity",
                           extra=("--tmpfs", "/workspace:rw,nosuid,nodev,mode=1777,size=32m"))
            proxy = "http://" + gateway_ip + ":3128"
            for _ in range(40):
                ready = execute(worker, "curl", "-fsS", "--max-time", "1", "--noproxy", "", "-x", proxy, "http://approved.test:8000/")
                if ready.returncode == 0:
                    break
                time.sleep(0.1)
            expect("approved_http", ready, True, "FIXTURE-OK")
            curl = ("curl", "-fkSs", "--connect-timeout", "1", "--max-time", "2", "--noproxy", "", "-x", proxy)
            expect("approved_tls", execute(worker, *curl, "https://approved.test:8443/"), True, "FIXTURE-OK")
            expect("unapproved_hostname", execute(worker, *curl, "http://forbidden.test:8000/"), False)
            expect("unapproved_port", execute(worker, *curl, "http://approved.test:8001/"), False)
            expect("approved_name_private_address", execute(worker, *curl, "http://private.test:8000/"), False)
            for name, target in (("direct_ipv4", fixture_ip), ("host_gateway", gateway_ip.rsplit('.',1)[0] + '.1'), ("metadata", "169.254.169.254")):
                expect(name, execute(worker, "curl", "-fsS", "--noproxy", "*", "--connect-timeout", "1", "--max-time", "2", f"http://{target}:8000/"), False)
            expect("direct_dns", execute(worker, "python3", "-c", "import socket;s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);s.settimeout(1);s.sendto(b'query',('127.0.0.11',53));s.recv(100)"), False)
            expect("raw_tcp_socket", execute(worker, "python3", "-c", f"import socket;socket.create_connection(('{fixture_ip}',8000),1)"), False)
            expect("capabilities_dropped", execute(worker, "sh", "-c", "grep -q 'CapEff:[[:space:]]*0000000000000000' /proc/self/status"), True)
            expect("host_profile_unmounted", execute(worker, "test", "-e", "/root/.hermes/cache/documents/sentinel.txt"), False)
            ipv6 = execute(worker, "python3", "-c", "import socket;s=socket.socket(socket.AF_INET6);s.settimeout(1);s.connect(('2606:4700:4700::1111',443))")
            expect("direct_ipv6_unreachable", ipv6, False)
            results["direct_ipv6_unreachable"]["limitation"] = "No IPv6 route is distinct from demonstrated firewall denial; inspect rules below."
            report["effective_rules"] = json.loads(docker("exec", namespace, "nft", "-j", "list", "ruleset").stdout)
            # Proxy death must not enable a direct route.
            docker("stop", "-t", "1", gateway)
            expect("proxy_down_fail_closed", execute(worker, *curl, "http://approved.test:8000/"), False)
            report["gate"] = "network_fixture_pass"
        except Exception as error:
            report["gate"] = "probe_error"
            report["error"] = str(error)
            if isinstance(error, subprocess.CalledProcessError):
                report["stderr"] = error.stderr[-3000:]
            for container in containers:
                report.setdefault("logs", {})[container] = docker("logs", "--tail", "15", container, check=False).stderr[-2000:]
        finally:
            failures = []
            for container in reversed(containers):
                result = docker("rm", "-f", container, check=False)
                if result.returncode:
                    failures.append(result.stderr)
            for network in reversed(networks):
                result = docker("network", "rm", network, check=False)
                if result.returncode:
                    failures.append(result.stderr)
            report["cleanup_errors"] = failures
            report["remaining_containers"] = docker("ps", "-aq", "--filter", "label=factory-sandbox-network-probe=" + owner).stdout.split()
            report["remaining_networks"] = docker("network", "ls", "-q", "--filter", "label=factory-sandbox-network-probe=" + owner).stdout.split()
            output.write_text(json.dumps(report, indent=2) + "\n")
    return 0 if report.get("gate") == "network_fixture_pass" and not report["cleanup_errors"] else 2


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    raise SystemExit(run(parser.parse_args().output))

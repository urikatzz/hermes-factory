#!/usr/bin/env python3
"""Disposable characterization of the existing Hermes Docker mount boundary.

This first gate intentionally stops before networking probes if composing the
upstream backend exposes files outside the approved job workspace.
"""

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import uuid


def analyze(inspection, approved_workspace):
    approved = str(Path(approved_workspace).resolve())
    violations = []
    for mount in inspection["Mounts"]:
        if mount["Type"] != "bind":
            continue
        source = str(Path(mount["Source"]).resolve())
        if source != approved or mount["Destination"] != "/workspace":
            violations.append({
                "kind": "unapproved_bind_mount", "source": source,
                "destination": mount["Destination"], "read_only": not mount["RW"],
            })
    host = inspection["HostConfig"]
    if host["NetworkMode"] == "host":
        violations.append({"kind": "host_network"})
    if host["Privileged"]:
        violations.append({"kind": "privileged_container"})
    return {
        "composition_compatible": not violations,
        "violations": violations,
        "network_enforcement": "not_verified",
        "sandbox_verified": False,
    }


def capture(argv, timeout=60, env=None):
    return subprocess.run(argv, stdin=subprocess.DEVNULL, capture_output=True,
                          text=True, timeout=timeout, env=env, check=True).stdout


def read_probe_report(argv, env):
    result = subprocess.run(argv, stdin=subprocess.DEVNULL, capture_output=True,
                            text=True, timeout=150, env=env, check=False)
    if result.returncode not in (0, 2):
        raise subprocess.CalledProcessError(result.returncode, argv, result.stdout, result.stderr)
    return json.loads(result.stdout)


def child_probe(source, image, workspace, ownership):
    # The parent supplies a synthetic HERMES_HOME and a minimal environment.
    sys.path.insert(0, str(source))
    from tools.environments.docker import DockerEnvironment

    runtime = None
    report = {}
    try:
        runtime = DockerEnvironment(
            image=image, cwd="/workspace", timeout=20, cpu=1, memory=256,
            persistent_filesystem=False, task_id=ownership,
            volumes=[f"{workspace}:/workspace"], forward_env=[], env={},
            network=False, auto_mount_cwd=False, persist_across_processes=False,
            image_pinned=True, extra_args=["--label", f"factory-sandbox-probe={ownership}"],
        )
        inspection = json.loads(capture(["docker", "inspect", runtime._container_id]))[0]
        report = analyze(inspection, workspace)
        report["actual_mounts"] = inspection["Mounts"]
        report["container_id"] = runtime._container_id
        # Only synthetic files are read; no existing host credentials are used.
        credential = runtime.execute("cat /root/.hermes/probe-credential.txt")
        cache = runtime.execute("cat /root/.hermes/cache/documents/sentinel.txt")
        report["synthetic_credential_visible"] = "SYNTHETIC-CREDENTIAL-ONLY" in credential.get("output", "")
        report["synthetic_cache_visible"] = "SYNTHETIC-CACHE-ONLY" in cache.get("output", "")
    finally:
        if runtime is not None:
            runtime.cleanup(force_remove=True)
            report["cleanup_finished"] = DockerEnvironment.wait_for_all_teardowns(timeout=45)
    return report


def minimal_env(home):
    # Keep the actual HOME; scope Hermes to synthetic data with its own setting.
    env = {key: os.environ[key] for key in (
        "PATH", "HOME", "TMPDIR", "DOCKER_HOST", "DOCKER_CONTEXT", "DOCKER_CONFIG",
    ) if key in os.environ}
    env.update(HERMES_HOME=str(home), PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1")
    return env


def probe(args):
    docker = shutil.which("docker")
    if not docker:
        raise RuntimeError("Docker CLI unavailable; install/start Docker before this gate")
    version = json.loads(capture([docker, "version", "--format", "{{json .}}"], timeout=15))
    image_data = json.loads(capture([docker, "image", "inspect", args.image]))[0]
    pins = image_data.get("RepoDigests", [])
    if not pins:
        raise RuntimeError("Probe requires an already available image with a repository digest")
    image = pins[0]
    revision = capture(["git", "-C", str(args.hermes_source), "rev-parse", "HEAD"]).strip()
    ownership = "factory-probe-" + uuid.uuid4().hex[:12]
    report = {"hermes_revision": revision, "worker_image": image,
              "docker_version": version, "ownership": ownership}
    with tempfile.TemporaryDirectory(prefix="hermes-sandbox-probe-") as directory:
        root = Path(directory).resolve()
        home = root / "profile"
        workspace = root / "job"
        home.mkdir()
        workspace.mkdir()
        terminal = "terminal: {}\n" if args.without_credential_registration else (
            "terminal:\n  credential_files:\n    - probe-credential.txt\n")
        (home / "config.yaml").write_text(terminal + "proxy:\n  enabled: false\n")
        (home / "probe-credential.txt").write_text("SYNTHETIC-CREDENTIAL-ONLY\n")
        cache = home / "cache/documents"
        cache.mkdir(parents=True)
        (cache / "sentinel.txt").write_text("SYNTHETIC-CACHE-ONLY\n")
        env = minimal_env(home)
        try:
            result = read_probe_report([
                str(args.hermes_python), "-I", str(Path(__file__).resolve()),
                "--child", "--hermes-source", str(args.hermes_source),
                "--image", image, "--approved-workspace", str(workspace),
                "--ownership", ownership,
            ], env)
            report.update(result)
        finally:
            # Constructor failure can leave a container before its handle returns.
            # Match only this probe's unique label, never other Hermes resources.
            ids = capture([docker, "ps", "-aq", "--filter", f"label=factory-sandbox-probe={ownership}"]).split()
            for container in ids:
                capture([docker, "rm", "-f", container])
            remaining = capture([docker, "ps", "-aq", "--filter", f"label=factory-sandbox-probe={ownership}"]).split()
            report["owned_containers_remaining"] = remaining
            report["cleanup_finished"] = not remaining
    report["gate"] = "pass_composition_only" if report["composition_compatible"] else "blocked_backend_composition"
    report["synthetic_credential_registered"] = not args.without_credential_registration
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analyze-inspection", type=Path)
    parser.add_argument("--approved-workspace", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--hermes-source", type=Path, default=Path("/Users/example/.hermes/hermes-agent"))
    parser.add_argument("--hermes-python", type=Path, default=Path("/Users/example/.hermes/hermes-agent/venv/bin/python"))
    parser.add_argument("--image", default="golang:1.23")
    parser.add_argument("--without-credential-registration", action="store_true")
    parser.add_argument("--child", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--ownership", help=argparse.SUPPRESS)
    args = parser.parse_args()
    try:
        if args.child:
            report = child_probe(args.hermes_source, args.image, args.approved_workspace, args.ownership)
        elif args.analyze_inspection:
            if args.approved_workspace is None:
                parser.error("--approved-workspace is required for inspection analysis")
            report = analyze(json.loads(args.analyze_inspection.read_text()), args.approved_workspace)
        else:
            report = probe(args)
    except (OSError, RuntimeError, subprocess.SubprocessError, ValueError) as exc:
        report = {"gate": "probe_error", "sandbox_verified": False, "error": str(exc)}
        if isinstance(exc, subprocess.CalledProcessError):
            report["stderr"] = exc.stderr[-5000:]
    text = json.dumps(report, indent=2) + "\n"
    if args.output:
        args.output.write_text(text)
    print(text, end="")
    if "error" in report:
        return 3
    return 0 if report["composition_compatible"] else 2


if __name__ == "__main__":
    raise SystemExit(main())

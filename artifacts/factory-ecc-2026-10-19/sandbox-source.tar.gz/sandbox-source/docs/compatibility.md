> Historical composition probe: the approved amendment replaced this rejected approach with explicit Docker transport. Current runtime and pilot evidence is in [pilot-results.md](pilot-results.md).

# Factory sandbox compatibility gate

Result: **blocked at the DockerEnvironment composition gate**. No sandbox backend or live profile was enabled. Network enforcement and the full Factory pilot have not been verified.

## Environment

- Hermes source revision: `9e041a7428392b01b989ef9cecf46a5f96be12fc`.
- Docker Engine: `29.8.2`; Docker Desktop: `4.95.0 (242831)`; Linux/arm64 runtime.
- Existing local image pinned for the disposable check: `golang@sha256:60deed95d3888cc5e4d9ff8a10c54e5edc008c6ae3fba6187be6fb592e19e8c0`.
- Probe environment: temporary synthetic `HERMES_HOME`, minimal child environment, synthetic credential/cache sentinels, dedicated job directory, `network=False`, `forward_env=[]`, `env={}`, `auto_mount_cwd=False`, `persistent_filesystem=False`, and `persist_across_processes=False`.

## Observed behavior

The existing backend mounted the approved workspace plus profile attachments, composer pastes, images, skills, and cache directories. With a configured synthetic credential-file entry, it mounted that file too. The container successfully read both synthetic credential and document-cache sentinels.

A second run removed the credential-file registration entirely. The credential sentinel was correctly unavailable, while the profile cache sentinel remained readable and 13 unapproved profile directory mounts remained. This control distinguishes intended operator-selected credential forwarding from unconditional directory mounting.

This is an incompatibility with our selected job-only filesystem boundary, not a claim that Hermes always exposes its master credential stores or that its deliberate file-passthrough feature is a vulnerability.

Source explanation:

- `tools/environments/docker.py`: the constructor always extends mount arguments with `_readonly_skill_mount_args()`.
- `_readonly_skill_mount_args()` includes credential, skills, and cache mount sources. The constructor has no public per-instance parameter to disable these categories.
- `tools/credential_files.py::get_cache_directory_mounts()` returns profile cache/staging directories and creates missing staging directories when needed.
- Read-only mounting prevents modification but does not prevent project code reading those files.

Inspected egress integration:

- `agent/proxy_sources/iron_proxy.py::build_config` builds domain allowlisting and optional upstream address denial rules.
- The existing Docker wiring expects a host proxy, injects proxy variables/CA mounts, and does not install a worker network firewall.
- Gateway deployment, per-port enforcement, raw socket denial, DNS/IPv6 filtering, and host-service isolation remain **unverified**. No assertion of network confinement follows from this check.

## Reproduction and evidence

From this implementation worktree:

```sh
python3 -m unittest discover -s tests -p 'test_compatibility_probe.py' -v
python3 scripts/probe_compatibility.py --output /private/tmp/hermes-factory-sandbox-compatibility.json
python3 scripts/probe_compatibility.py --without-credential-registration --output /private/tmp/hermes-factory-sandbox-control.json
```

Five diagnostic contract tests passed. Both real container probes exited `2`, meaning the composition gate rejected the observed mount boundary. This is the expected diagnostic result, not a passing implementation acceptance run.

Both probes stopped and removed their uniquely labelled containers. Their reports recorded `cleanup_finished=true` and `owned_containers_remaining=[]`. No real credential values were read. No installed profiles, live Factory scripts, scheduler configuration, or installed Hermes code were changed.

## Required adjustment

Use the existing terminal-provider plugin interface but implement its execution adapter on the documented `BaseEnvironment` contract, with supervisor-owned Docker creation and an explicit mount/environment list. Reuse Hermes's shared command/file interfaces without composing the built-in DockerEnvironment's automatic file passthrough. This adds responsibility for Docker transport/lifecycle in the plugin and needs review before proceeding.

Alternative: make a maintained upstream change adding explicit per-instance mount/passthrough controls to DockerEnvironment and use those controls from the plugin. That is a smaller adapter but requires maintaining or landing a Hermes core change. It is outside the approved no-core-edit implementation path.

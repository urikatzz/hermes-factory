# Proposed amendment: explicit Docker transport

Status: approved by the user after the compatibility gate failed.

Parent design: `2026-10-15-factory-sandbox-design.md`.

## Evidence

Two disposable runtime probes showed that the installed DockerEnvironment automatically mounts profile cache/staging/skill directories outside the approved job workspace. A synthetic cache file was readable even with no configured credential mounts. See `../../compatibility.md` and the retained JSON evidence paths there.

## Proposed change

Keep the approved standalone `factory_sandbox` terminal provider, host coordinator, dedicated workspace, network enforcement, cancellation, evidence, and pilot acceptance criteria. Replace composition of the built-in DockerEnvironment with a backend adapter implementing the documented BaseEnvironment contract and a trusted Docker CLI transport owned by the plugin.

The transport creates containers using an explicit mount and environment list. It does not call the built-in backend's automatic credential/skill/cache mount helpers, env forwarding, shared-container adoption, or automatic recovery. Only the prepared job directory and specifically reviewed runtime policy inputs enter the worker. Required helper/skill text is copied into the prepared snapshot, with no profile directory mounts.

The adapter implements the BaseEnvironment extension points for spawning commands and cleanup, preserving shared shell/file behavior. Before using any shared initialization or synchronization helper, verify it cannot copy host profile state into the container. This shared-code audit becomes part of the first compatibility gate, with synthetic sentinels and real tool-routing tests.

## Tradeoff

Recommended: standalone explicit transport. It preserves the no-core-edit deployment path and makes the isolation policy independent of the ordinary Docker backend's file-sharing features. It adds a small Docker transport/lifecycle implementation that must be tested at the supported Hermes revision.

Alternative: add upstream public constructor controls for automatic mounts and passthrough, then use those controls. This reduces transport duplication but creates a Hermes core change and a version/maintenance dependency.

## Plan changes after approval

1. Task 1 records the current composition gate as rejected, then continues with a disposable explicit-transport characterization and the unchanged real network checks.
2. Task 3 owns direct Docker create/exec/stop/remove transport, explicit mount/environment enforcement, and disabled uncontrolled adoption/recreation.
3. Task 4 uses BaseEnvironment's documented extension interface instead of DockerEnvironment composition, and verifies its shared file/background/cancellation behavior through actual Hermes handlers.
4. All original security acceptance criteria remain required. No live activation occurs until the pilot passes.

Network gateway compatibility is still unresolved and remains a separate gate. This amendment does not claim iron-proxy is a proven fit or permit weakening the hostname/port/address policy.

# Pilot observations

Implementation status: standalone pilot built and exercised; Docker restarted by the user on 2026-10-16. Current standalone/runtime/provider/routing/document-guard/network checks and repeated private Factory pilot pass. Not installed into the live Factory roster.

## Review and latest checks

Final review identified host document extraction, cleanup retry, failure evidence, and an insufficient pilot success gate. These were addressed: document conversion reads (including normalized-path bypasses) are blocked before host extraction; cleanup retries reuse retained output within the supervisor instance; collection failures record retained-resource state; startup preserves the primary failure; pilot success requires finalized cleanup evidence, expected answer/manifest, unchanged helper, and unchanged verifier output. Export reads now have a 30-second deadline.

Current post-restart checks: 21 standalone tests, actual runtime lifecycle, three actual-Hermes provider checks (including cwd recovery), actual plugin/tool routing, and document admission regression pass. Document reads require absolute paths, preventing cwd-dependent extraction bypasses. The network fixture passed again with all its resources removed. Upstream canonical configuration/session tests passed (30 tests); the built-in Docker backend file timed out after 300 seconds and is not passing.

The stricter private rerun at `/private/tmp/hermes-factory-sandbox-pilot-6/pilot.json` correctly reports `sandbox_verified=false`, with the worker blocked on Docker startup. Current runtime/provider rechecks likewise timed out creating the namespace container. This was the pre-restart result. After the user restarted Docker, current runtime/provider/routing checks passed. The repeated private model pilot passed, as recorded below. The successful earlier pilot below remains historical evidence, not a replacement for the blocked rerun.


## Post-restart real Factory pilot

`/private/tmp/hermes-factory-sandbox-pilot-7/pilot.json` reports `sandbox_verified=true` with the stricter gate. IMPLEMENT `t_d7a8264a` and VERIFY `t_283bcd63` both completed with exit 0 and manifest SHA12 `9b734edbedb2`. Both finalized supervisor records report `cleanup_outcome=removed`. The host independently verified answer content, exact manifest hashes, unchanged helper, unchanged verifier output, and unchanged original fixture. Temporary host authentication copies were removed. No pilot containers remain running.

The previously stalled gateway `fs-probe-60e3bf2852-gateway` was removed successfully after restart. Production activation is still separate. The earlier upstream built-in Docker backend suite timeout is not converted into a pass by these plugin checks; that suite remains unverified after restart.

## Earlier real model and Kanban run

The private pilot at `/private/tmp/hermes-factory-sandbox-pilot-4/pilot.json` passed through Hermes's actual `dispatch_once` worker launch and the configured `openai-codex` / `gpt-6-luna` model.

| Stage | Private task | Outcome |
| --- | --- | --- |
| IMPLEMENT | `t_c7d64921` | Done, worker exit 0, changed answer from 41 to 42, produced manifest |
| VERIFY | `t_d8559cb6` | Done, worker exit 0, independently checked the retained snapshot and manifest |

Manifest SHA12 reported by implementation: `1e6f37074d29`. Each stage's host-owned evidence records `cleanup_outcome=removed` and its retained result path. The original fixture remained separate from the changed result. Temporary host auth copies were removed after the run.

An earlier real attempt exposed Hermes's reserved `prompt-backend-probe`: it created and disposed the workload before the first command. The provider now refuses that reserved OS probe, letting Hermes use its existing description fallback. A regression test covers this behavior. No local execution fallback was introduced.

## Network experiment

`/private/tmp/hermes-factory-sandbox-network-copy.json` records the successful disposable fixture topology. Approved HTTP and TLS returned fixture content. Forbidden hostname, port, and private-address requests returned proxy 403. Direct DNS was denied; direct TCP/host/metadata requests were unavailable. Effective worker capabilities were zero. Proxy shutdown failed closed. Its labelled resources were removed.

IPv6 had no reachable route in Docker Desktop, so reachable-IPv6 denial is not claimed from that request alone. The inspected nftables policy defaults to dropping IPv4/IPv6 output except the designated IPv4 proxy endpoint and local sandbox traffic, with DNS explicitly denied before loopback handling.

The production runtime additionally passed a real `example.com:443` request and rejected `example.com:80`; its destination addresses are validated public IPv4 values and frozen in the proxy policy.

## File and lifecycle checks

Standard-library tests cover immutable/strict policy parsing, scoped attempt identities, source exclusion rules, symlink/hardlink/special-file refusal, stopped-only collection, substituted roots, duplicate attempts, archive traversal/link refusal, output import, changes/deletions, and evidence scoping.

Real Docker checks cover unprivileged execution, no host bind mounts, output retained after stopping a worker with a background process, and blocked execution after stop. Real Hermes checks cover provider startup failure, the prompt probe regression, shared shell/file operations, timeout termination with retained output/evidence, repeated cleanup, actual plugin discovery, public handler routing, and blocked web extraction.

## Limitations and cleanup

The first built-in Docker backend experiment correctly rejected automatic profile/cache mounts. Later direct bind-mounted Docker Desktop probe containers stalled in Created state; privileged repetition reproduced the stall. Two uniquely named early gateways (`fs-probe-0c52751ef5-gateway`, `fs-probe-60e3bf2852-gateway`) had stalled removal requests. They did not execute project code. The working implementation uses no host bind mounts; its own resources and the successful network fixture were cleaned. Shared Docker was not restarted because unrelated workloads exist.

Host Unity checks, publishing, full agent process isolation, daemon/VM-restart preservation of active tmpfs state, automatic retry/recovery, IPv6-only upstreams, and broad production rollout remain outside this pilot. They must not be inferred from a successful two-stage run.

"""Descriptor-relative copying into supervisor-owned job snapshots."""

import fnmatch
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import stat
import tempfile
import tarfile
import uuid

from .policy import AttemptIdentity


_EXCLUDED_DIRS = {".git", ".hg", ".svn", ".worktrees", "node_modules", "dist", "n8n",
                  "__pycache__", ".venv", "venv", ".cache", "coverage", "screenshots",
                  ".pytest_cache", ".next", ".parcel-cache", ".ssh", ".aws", ".gnupg", ".docker", ".kube"}
_EXCLUDED_NAMES = (".env*", "*.env", ".npmrc", ".netrc", ".pypirc", ".pgpass", ".git-credentials",
                   "*.pem", "*.key", "*.p12", "*.pfx", "*.ppk", "*.keystore", "*.jks", "*.kdbx",
                   "id_rsa*", "id_dsa*", "id_ecdsa*", "id_ed25519*", "credentials", "credentials.json",
                   "auth.json", "*service-account*.json", "serviceaccount*.json", ".ds_store", "._*")
_MAX_BYTES = 128 * 1024 * 1024
_MAX_FILES = 10000


def excluded(name):
    lower = name.casefold()
    return lower in _EXCLUDED_DIRS or any(fnmatch.fnmatchcase(lower, pattern) for pattern in _EXCLUDED_NAMES)


def atomic_json(path, value):
    fd, temporary = tempfile.mkstemp(prefix=".state-", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as stream:
            json.dump(value, stream, sort_keys=True, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def _copy_tree(source: Path, target: Path):
    hashes, budget = {}, [0, 0]
    root_fd = os.open(source, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)

    def walk(parent_fd, dest, prefix):
        for name in sorted(os.listdir(parent_fd)):
            if excluded(name):
                continue
            info = os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
            relative = prefix + name
            if stat.S_ISDIR(info.st_mode):
                fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent_fd)
                try:
                    actual = os.fstat(fd)
                    if (actual.st_dev, actual.st_ino) != (info.st_dev, info.st_ino):
                        raise ValueError("Source directory changed while copying")
                    (dest / name).mkdir(mode=0o700)
                    walk(fd, dest / name, relative + "/")
                finally:
                    os.close(fd)
            elif stat.S_ISREG(info.st_mode) and info.st_nlink == 1:
                fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent_fd)
                try:
                    actual = os.fstat(fd)
                    if not stat.S_ISREG(actual.st_mode) or actual.st_nlink != 1 or (
                            actual.st_dev, actual.st_ino) != (info.st_dev, info.st_ino):
                        raise ValueError("Source file changed while copying")
                    budget[1] += 1
                    if budget[1] > _MAX_FILES:
                        raise ValueError("Snapshot exceeds the pilot file limit")
                    digest = hashlib.sha256()
                    with os.fdopen(fd, "rb", closefd=False) as original, (dest / name).open("xb") as copied:
                        while chunk := original.read(1024 * 1024):
                            budget[0] += len(chunk)
                            if budget[0] > _MAX_BYTES:
                                raise ValueError("Snapshot exceeds the pilot byte limit")
                            copied.write(chunk)
                            digest.update(chunk)
                    os.chmod(dest / name, 0o600 | (info.st_mode & 0o111))
                    hashes[relative] = digest.hexdigest()
                finally:
                    os.close(fd)
            else:
                raise ValueError(f"Snapshot refuses links and special files: {relative}")

    try:
        walk(root_fd, target, "")
    finally:
        os.close(root_fd)
    return hashes


class WorkspaceStore:
    def __init__(self, root: Path):
        self._root = root.resolve()
        self._root.mkdir(parents=True, exist_ok=True, mode=0o700)

    def prepare(self, source_root: Path, identity: AttemptIdentity) -> Path:
        attempt = self._root / identity.key
        attempt.mkdir(mode=0o700)
        job = attempt / "job"
        job.mkdir(mode=0o700)
        try:
            hashes = _copy_tree(source_root, job)
            info = job.stat()
            atomic_json(attempt / "state.json", dict(device=info.st_dev, inode=info.st_ino,
                                                     stopped=False, hashes=hashes))
        except BaseException:
            shutil.rmtree(attempt)
            raise
        return job

    def _state(self, identity):
        path = self._root / identity.key / "state.json"
        return path, json.loads(path.read_text())

    def mark_stopped(self, identity: AttemptIdentity) -> None:
        path, state = self._state(identity)
        atomic_json(path, {**state, "stopped": True})

    def import_archive(self, data: bytes, identity: AttemptIdentity) -> Path:
        path, state = self._state(identity)
        if not state["stopped"]:
            raise RuntimeError("Stop project execution before importing results")
        job = path.parent / "job"
        actual = job.lstat()
        if not stat.S_ISDIR(actual.st_mode) or (actual.st_dev, actual.st_ino) != (state["device"], state["inode"]):
            raise ValueError("Workspace identity changed")
        staging = path.parent / (".import-" + uuid.uuid4().hex)
        staging.mkdir(mode=0o700)
        budget, count, seen = 0, 0, set()
        try:
            with tarfile.open(fileobj=io.BytesIO(data), mode="r:") as archive:
                for entry in archive:
                    name = entry.name
                    if name in (".", "./") and entry.isdir():
                        continue
                    if name.startswith("./"):
                        name = name[2:]
                    parts = name.rstrip("/").split("/")
                    if (not name or name.startswith("/") or "\\" in name or
                            any(part in ("", ".", "..") for part in parts) or
                            any(ord(char) < 32 for char in name)):
                        raise ValueError("Unsafe archive path")
                    if any(excluded(part) for part in parts):
                        continue
                    normalized = "/".join(parts)
                    if normalized in seen or not (entry.isfile() or entry.isdir()):
                        raise ValueError("Duplicate archive member, link, or special file")
                    seen.add(normalized)
                    count += 1
                    budget += entry.size
                    if count > _MAX_FILES or entry.size < 0 or budget > _MAX_BYTES:
                        raise ValueError("Archive exceeds the pilot limits")
                    target = staging.joinpath(*parts)
                    target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                    if entry.isdir():
                        target.mkdir(mode=0o700, exist_ok=True)
                    else:
                        with archive.extractfile(entry) as source, target.open("xb") as dest:
                            shutil.copyfileobj(source, dest, length=1024 * 1024)
                        os.chmod(target, 0o600 | (entry.mode & 0o111))
            old = path.parent / (".previous-" + uuid.uuid4().hex)
            job.rename(old)
            try:
                staging.rename(job)
            except BaseException:
                old.rename(job)
                raise
            info = job.stat()
            atomic_json(path, {**state, "device": info.st_dev, "inode": info.st_ino})
            shutil.rmtree(old)
            return job
        except (tarfile.TarError, OSError) as error:
            raise ValueError("Workspace archive import failed") from error
        finally:
            if staging.exists():
                shutil.rmtree(staging)

    def collect(self, workspace: Path, identity: AttemptIdentity) -> Path:
        path, state = self._state(identity)
        expected = path.parent / "job"
        info = workspace.lstat()
        if workspace != expected or not stat.S_ISDIR(info.st_mode) or (
                info.st_dev, info.st_ino) != (state["device"], state["inode"]):
            raise ValueError("Workspace identity changed")
        if not state["stopped"]:
            raise RuntimeError("Stop project execution before collecting results")
        staging = path.parent / (".result-" + uuid.uuid4().hex)
        staging.mkdir(mode=0o700)
        source = staging / "files"
        source.mkdir(mode=0o700)
        try:
            hashes = _copy_tree(workspace, source)
            atomic_json(staging / "changes.json", {
                "removed": sorted(set(state["hashes"]) - set(hashes)),
                "changed": sorted(name for name, digest in hashes.items() if state["hashes"].get(name) != digest),
                "hashes": hashes,
            })
            final = path.parent / "result"
            if final.exists():
                raise FileExistsError("Result already collected")
            staging.rename(final)
        except BaseException:
            shutil.rmtree(staging)
            raise
        return final

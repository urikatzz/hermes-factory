"""Hermes's documented provider interface backed by explicit Docker transport."""

import os
from pathlib import Path
import shutil
import subprocess
import threading

from agent.terminal_env_provider import TerminalEnvironmentProvider
from hermes_constants import get_hermes_home
from tools.environments.base import BaseEnvironment

from .policy import AttemptIdentity, load_policy


ALLOWED_TOOLS = frozenset({"terminal", "process_manage", "read_file", "write_file", "patch", "search_files", "tool_search",
                           "kanban_show", "kanban_comment", "kanban_complete", "kanban_heartbeat", "kanban_block"})


class FactorySandboxEnvironment(BaseEnvironment):
    def __init__(self, docker_runtime, runtime_handle, finalize):
        self._runtime = docker_runtime
        self._handle = runtime_handle
        self._finalize = finalize
        self._closed = False
        self._exit_reason = "session_end"
        self._cleanup_lock = threading.RLock()
        self.result_path = None
        self.evidence_path = None
        super().__init__(cwd="/workspace", timeout=runtime_handle.timeout)
        self.init_session()
        if not self._snapshot_ready:
            self.cleanup()
            raise RuntimeError("Sandbox shell initialization failed")

    def _prepare_command(self, command):
        # Project commands never request or consume the host sudo password.
        return command, None

    def _run_bash(self, cmd_string, *, login=False, timeout=120, stdin_data=None):
        if self._closed:
            raise RuntimeError("Sandbox execution is closed")
        argv = self._runtime.exec_argv(self._handle, cmd_string, self.cwd, stdin_data is not None)
        process = subprocess.Popen(argv, stdin=subprocess.PIPE if stdin_data is not None else subprocess.DEVNULL,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                   encoding="utf-8", errors="replace", env=self._runtime._environment)
        if stdin_data is not None:
            def feed():
                try:
                    process.stdin.write(stdin_data)
                except BrokenPipeError:
                    pass
                finally:
                    process.stdin.close()
            # This thread only forwards provided bytes; it reads no profile context.
            threading.Thread(target=feed, daemon=True).start()
        return process

    def execute(self, command, cwd="", **kwargs):
        kwargs["timeout"] = min(kwargs.get("timeout") or self.timeout, self.timeout)
        if cwd:
            if cwd != "/workspace" and not cwd.startswith("/workspace/"):
                raise ValueError("Sandbox cwd must be inside /workspace")
            # The transport must be able to recover after a command leaves /workspace.
            self.cwd = cwd
        return super().execute(command, cwd, **kwargs)

    def _wait_for_process(self, process, *args, **kwargs):
        try:
            return super()._wait_for_process(process, *args, **kwargs)
        finally:
            # The shared timeout branch joins its drain thread but returns before
            # closing stdout; close completed transports without touching yielded ones.
            if process.poll() is not None and process.stdout is not None:
                process.stdout.close()

    def _kill_process(self, process):
        # Killing only the local Docker CLI would leave project code running.
        self._exit_reason = "timeout_or_cancelled"
        self._runtime.kill(self._handle)
        if process.poll() is None:
            process.kill()

    def cleanup(self, **kwargs):
        with self._cleanup_lock:
            if not self._closed:
                self.result_path, self.evidence_path = self._finalize(self._handle, reason=self._exit_reason)
                self._closed = True


class FactorySandboxProvider(TerminalEnvironmentProvider):
    name = "factory_sandbox"
    display_name = "Factory sandbox"
    is_remote = True
    is_container = True
    session_isolated_when_nonpersistent = True
    skip_container_guards = False

    def __init__(self, settings_reader, supervisor_factory):
        self._settings = settings_reader
        self._supervisor_factory = supervisor_factory

    def is_available(self):
        path = self._settings("policy_path")
        return bool(path and Path(path).is_file() and shutil.which("docker"))

    def create_environment(self, *, cwd, timeout, task_id="default", image=None, container_config=None, **kwargs):
        if task_id == "prompt-backend-probe":
            # This reserved call is made before the live session and immediately
            # disposed. Hermes uses env_description when a probe is unavailable.
            raise RuntimeError("Factory sandbox does not provision workloads for a prompt probe")
        values = {key: self._settings(key) for key in ("policy_path", "source_directory", "state_root")}
        if any(not isinstance(value, str) or not Path(value).is_absolute() for value in values.values()):
            raise ValueError("Sandbox requires administrator-authored absolute policy, source, and state paths")
        config = container_config or {}
        if config.get("container_persistent", True):
            raise ValueError("Factory sandbox requires nonpersistent per-session execution")
        forbidden = ("docker_volumes", "docker_forward_env", "docker_env", "docker_extra_args", "docker_shared_container_key")
        if any(config.get(key) for key in forbidden):
            raise ValueError("Unrestricted Docker configuration cannot be used by Factory sandbox")
        if image:
            raise ValueError("Image overrides are not permitted; use the administrator policy")
        policy = load_policy(Path(values["policy_path"]))
        identity = AttemptIdentity(get_hermes_home(), os.environ.get("HERMES_KANBAN_BOARD", ""),
                                   os.environ.get("HERMES_KANBAN_TASK", ""), os.environ.get("HERMES_KANBAN_RUN_ID", ""))
        supervisor = self._supervisor_factory(Path(values["state_root"]))
        handle = supervisor.start(identity, policy, Path(values["source_directory"]))
        return FactorySandboxEnvironment(supervisor._runtime, handle, supervisor.finish)

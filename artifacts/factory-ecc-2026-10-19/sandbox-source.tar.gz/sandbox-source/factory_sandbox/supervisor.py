"""Coordinate workspace retention, execution lifecycle, and durable evidence."""

from datetime import datetime, timezone
from pathlib import Path
import threading


class SandboxSupervisor:
    def __init__(self, workspace_store, docker_runtime, evidence_store):
        self._workspaces = workspace_store
        self._runtime = docker_runtime
        self._evidence = evidence_store
        self._results = {}
        self._retained = {}
        self._lock = threading.RLock()

    def start(self, identity, policy, source: Path):
        workspace = self._workspaces.prepare(source, identity)
        self._evidence.record(identity, {
            "phase": "initializing", "policy_revision": policy.revision,
            "workspace_identity": identity.key,
            "images": {"worker": policy.worker_image, "gateway": policy.gateway_image},
            "started_at": datetime.now(timezone.utc).isoformat(),
        })
        try:
            handle = self._runtime.start(identity, policy, workspace)
        except BaseException:
            self._evidence.finish(identity, {"exit_reason": "startup_failed", "cleanup_outcome": "see_runtime_state"})
            raise
        self._evidence.record(identity, {"phase": "running"})
        return handle

    def finish(self, handle, reason="session_end"):
        with self._lock:
            if handle.owner in self._results:
                return self._results[handle.owner]
            if handle.owner not in self._retained:
                phase = "stopping"
                try:
                    self._evidence.record(handle.identity, {"phase": phase, "exit_reason": reason})
                    self._runtime.stop(handle)
                    phase = "exporting"
                    data = self._runtime.export(handle)
                    self._workspaces.mark_stopped(handle.identity)
                    phase = "importing"
                    workspace = self._workspaces.import_archive(data, handle.identity)
                    phase = "collecting"
                    result = self._workspaces.collect(workspace, handle.identity)
                    self._retained[handle.owner] = result
                    self._evidence.record(handle.identity, {"phase": "output_retained", "result_path": str(result)})
                except BaseException as error:
                    self._evidence.record(handle.identity, {"phase": phase + "_failed",
                        "message": type(error).__name__, "cleanup_outcome": "resources_retained"})
                    raise
            result = self._retained[handle.owner]
            try:
                self._runtime.remove(handle, allow_missing=True)
            except BaseException as error:
                self._evidence.record(handle.identity, {"phase": "cleanup_failed", "message": type(error).__name__,
                                                       "cleanup_outcome": "resources_retained"})
                raise
            evidence = self._evidence.finish(handle.identity, {
                "exit_reason": reason, "cleanup_outcome": "removed", "result_path": str(result),
                "ended_at": datetime.now(timezone.utc).isoformat(),
            })
            self._results[handle.owner] = (result, evidence)
            return result, evidence

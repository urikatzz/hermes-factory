"""Immutable administrator policy and scoped attempt identities."""

from dataclasses import dataclass, fields
import hashlib
import ipaddress
import json
from pathlib import Path
import re


_IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}\Z")
_HOSTNAME = re.compile(r"(?=.{1,253}\Z)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}\Z")
_IMAGE = re.compile(r"(?:[a-zA-Z0-9./:_-]+@)?sha256:[a-f0-9]{64}\Z")


def _identifier(value):
    if not isinstance(value, str) or not _IDENTIFIER.fullmatch(value) or ".." in value:
        raise ValueError("Invalid nonempty scoped identifier")


@dataclass(frozen=True)
class AttemptIdentity:
    profile_home: Path
    board: str
    task_id: str
    run_id: str

    def __post_init__(self):
        if not isinstance(self.profile_home, Path) or not self.profile_home.is_absolute():
            raise ValueError("Profile home must be an absolute path")
        for value in (self.board, self.task_id, self.run_id):
            _identifier(value)

    @property
    def key(self):
        value = [str(self.profile_home.resolve()), self.board, self.task_id, self.run_id]
        return hashlib.sha256(json.dumps(value, separators=(",", ":")).encode()).hexdigest()


@dataclass(frozen=True)
class AllowedDestination:
    hostname: str
    port: int

    def __post_init__(self):
        host = self.hostname
        if not isinstance(host, str) or not _HOSTNAME.fullmatch(host):
            raise ValueError("Destination must be an exact lowercase DNS hostname")
        try:
            ipaddress.ip_address(host)
        except ValueError:
            pass
        else:
            raise ValueError("IP-literal destinations are not permitted")
        if host.endswith((".local", ".localhost", ".internal", ".test", ".invalid")):
            raise ValueError("Private and test hostnames are not permitted in production policies")
        if type(self.port) is not int or not 1 <= self.port <= 65535:
            raise ValueError("Destination port must be in 1..65535")


@dataclass(frozen=True)
class SandboxPolicy:
    revision: str
    worker_image: str
    gateway_image: str
    allowed_destinations: tuple[AllowedDestination, ...]
    cpu: float
    memory_mb: int
    pids_limit: int
    command_timeout_seconds: int

    def __post_init__(self):
        _identifier(self.revision)
        for image in (self.worker_image, self.gateway_image):
            if not isinstance(image, str) or not _IMAGE.fullmatch(image):
                raise ValueError("Runtime images require immutable SHA256 addresses")
        if not self.allowed_destinations or not isinstance(self.allowed_destinations, tuple):
            raise ValueError("Policy requires immutable explicit destinations")
        if any(not isinstance(item, AllowedDestination) for item in self.allowed_destinations):
            raise ValueError("Invalid allowed destination")
        if len(set(self.allowed_destinations)) != len(self.allowed_destinations):
            raise ValueError("Duplicate allowed destinations")
        if type(self.cpu) not in (int, float) or not 0 < self.cpu <= 64:
            raise ValueError("CPU limit must be positive and at most 64")
        for value in (self.memory_mb, self.pids_limit, self.command_timeout_seconds):
            if type(value) is not int or value <= 0:
                raise ValueError("Memory, PID, and timeout limits must be positive integers")


def load_policy(path: Path) -> SandboxPolicy:
    with path.open() as stream:
        data = json.load(stream)
    if not isinstance(data, dict) or set(data) != {field.name for field in fields(SandboxPolicy)}:
        raise ValueError("Policy fields do not match the required schema")
    try:
        destinations = tuple(AllowedDestination(**value) for value in data["allowed_destinations"])
        return SandboxPolicy(**{**data, "allowed_destinations": destinations})
    except (TypeError, KeyError) as error:
        raise ValueError("Malformed policy destination") from error

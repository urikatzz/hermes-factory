"""Host-owned, scoped attempt evidence; raw environment serialization is forbidden."""

from dataclasses import asdict
from datetime import datetime, timezone
import json
from pathlib import Path
import threading

from .workspace import atomic_json


_FIELDS = {"phase", "policy_revision", "workspace_identity", "images", "exit_reason",
           "output_identity", "cleanup_outcome", "started_at", "ended_at", "message", "result_path"}


class EvidenceStore:
    def __init__(self, root: Path):
        self._root = root.resolve()
        self._root.mkdir(parents=True, exist_ok=True, mode=0o700)
        self._lock = threading.RLock()

    def _path(self, identity):
        directory = self._root / identity.key
        directory.mkdir(exist_ok=True, mode=0o700)
        return directory / "attempt.json"

    def _read(self, path, identity):
        if path.exists():
            return json.loads(path.read_text())
        return {"identity": {**asdict(identity), "profile_home": str(identity.profile_home)}, "events": []}

    def record(self, identity, event: dict) -> None:
        if set(event) - _FIELDS:
            raise ValueError("Unsupported evidence fields; never serialize raw environments")
        with self._lock:
            path = self._path(identity)
            data = self._read(path, identity)
            if "result" in data:
                raise RuntimeError("Final evidence is immutable")
            data["events"].append({"timestamp": datetime.now(timezone.utc).isoformat(), **event})
            atomic_json(path, data)

    def finish(self, identity, result: dict) -> Path:
        if set(result) - _FIELDS:
            raise ValueError("Unsupported final evidence fields")
        with self._lock:
            path = self._path(identity)
            data = self._read(path, identity)
            if "result" in data and data["result"] != result:
                raise RuntimeError("Conflicting final evidence")
            data["result"] = result
            atomic_json(path, data)
            return path

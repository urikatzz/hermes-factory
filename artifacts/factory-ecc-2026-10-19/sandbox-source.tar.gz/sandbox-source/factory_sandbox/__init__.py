"""Standalone Factory execution sandbox; no import-time registration or I/O."""

"""Trusted, explicit Docker transport. No host bind mounts or implicit passthrough."""

from dataclasses import dataclass
import io
import ipaddress
import json
import os
from pathlib import Path
import socket
import select
import subprocess
import tarfile
import time
import uuid

from .policy import AttemptIdentity, SandboxPolicy
from .workspace import atomic_json


_LABEL = "hermes-factory-sandbox-owner"
_MAX_ARCHIVE = 150 * 1024 * 1024


def resolve_destinations(policy):
    addresses = {}
    for destination in policy.allowed_destinations:
        values = tuple(sorted({record[4][0] for record in socket.getaddrinfo(
            destination.hostname, destination.port, family=socket.AF_INET, type=socket.SOCK_STREAM)}))
        if not values or any(not ipaddress.ip_address(value).is_global for value in values):
            raise ValueError(f"Approved hostname resolved to a nonpublic address: {destination.hostname}")
        addresses[destination.hostname] = values
    return addresses


def render_gateway_config(policy, addresses):
    rules = ["http_port 3128", "visible_hostname factory-sandbox", "pid_filename none",
             "cache_log /tmp/policy/cache.log", "access_log stdio:/tmp/policy/access.log", "cache_store_log none",
             "cache deny all", "shutdown_lifetime 1 seconds", "hosts_file /tmp/policy/hosts",
             "http_access deny manager", "forwarded_for delete", "via off",
             "dns_nameservers 127.0.0.1"]
    for index, destination in enumerate(policy.allowed_destinations):
        values = addresses[destination.hostname]
        if not values or any(not ipaddress.ip_address(value).is_global for value in values):
            raise ValueError("Gateway refuses nonpublic resolved destinations")
        cidrs = " ".join(value + ("/128" if ":" in value else "/32") for value in values)
        rules.extend([f"acl name_{index} dstdomain -n {destination.hostname}",
                      f"acl port_{index} port {destination.port}", f"acl address_{index} dst {cidrs}",
                      f"http_access allow name_{index} port_{index} address_{index}"])
    return "\n".join([*rules, "http_access deny all", ""])


@dataclass(frozen=True)
class RuntimeHandle:
    identity: AttemptIdentity
    workspace: Path
    namespace_id: str
    worker_id: str
    gateway_id: str
    policy_revision: str
    owner: str
    network_id: str
    volume_id: str
    worker_image: str
    gateway_image: str
    timeout: int


class DockerRuntime:
    def __init__(self, root: Path, docker_executable="docker"):
        self._root = root.resolve()
        self._root.mkdir(parents=True, exist_ok=True, mode=0o700)
        self._docker = docker_executable
        self._environment = {key: os.environ[key] for key in
                             ("PATH", "HOME", "DOCKER_HOST", "DOCKER_CONTEXT", "DOCKER_CONFIG")
                             if key in os.environ}
        self._started = {}

    def _call(self, *args, data=None, check=True, timeout=30):
        result = subprocess.run([self._docker, *map(str, args)], input=data,
                                capture_output=True, timeout=timeout, env=self._environment)
        if check and result.returncode:
            raise RuntimeError(result.stderr.decode(errors="replace")[-2000:])
        return result

    def doctor(self):
        result = self._call("version", "--format", "{{json .Server.Version}}", timeout=10)
        return json.loads(result.stdout)

    def _inspect(self, kind, name):
        return json.loads(self._call(kind, "inspect", name).stdout)[0]

    def _owned(self, kind, name, owner):
        info = self._inspect(kind, name)
        labels = info["Config"].get("Labels", {}) if kind == "container" else info.get("Labels", {})
        if labels.get(_LABEL) != owner:
            raise RuntimeError("Resource ownership does not match this attempt")
        return info

    def _container(self, name, owner, image, policy, network, command, *, user="1000:1000", extra=()):
        self._call("run", "-d", "--pull", "never", "--name", name, "--label", f"{_LABEL}={owner}",
                   "--network", network, "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
                   "--pids-limit", policy.pids_limit, "--cpus", policy.cpu, "--memory", f"{policy.memory_mb}m",
                   "--read-only", "--user", user, "--tmpfs", "/tmp:rw,nosuid,nodev,size=64m",
                   "--entrypoint", "/bin/sleep", *extra, image, command)

    def _write(self, container, path, data):
        # All paths are fixed supervisor literals, never worker output.
        self._call("exec", "-i", container, "sh", "-c", "cat > " + path, data=data)

    def start(self, identity: AttemptIdentity, policy: SandboxPolicy, workspace: Path) -> RuntimeHandle:
        self.doctor()
        addresses = resolve_destinations(policy)
        gateway_config = render_gateway_config(policy, addresses)
        lock = self._root / identity.key
        lock.mkdir(mode=0o700)  # An existing attempt is never silently adopted.
        owner = "factory-" + identity.key[:16] + "-" + uuid.uuid4().hex[:8]
        network, volume = owner + "-net", owner + "-files"
        namespace, worker, gateway = (owner + suffix for suffix in ("-namespace", "-worker", "-gateway"))
        handle = RuntimeHandle(identity, workspace, namespace, worker, gateway, policy.revision,
                               owner, network, volume, policy.worker_image, policy.gateway_image,
                               policy.command_timeout_seconds)
        self._started[owner] = handle
        atomic_json(lock / "runtime.json", {"owner": owner, "phase": "initializing", "policy": policy.revision})
        try:
            self._call("network", "create", "--internal", "--label", f"{_LABEL}={owner}", network)
            self._call("volume", "create", "--label", f"{_LABEL}={owner}", "--driver", "local",
                       "--opt", "type=tmpfs", "--opt", "device=tmpfs", "--opt",
                       "o=size=128m,uid=1000,gid=1000,mode=0700,nodev,nosuid", volume)
            self._container(namespace, owner, policy.worker_image, policy, network, "infinity", user="0:0",
                            extra=("--cap-add", "NET_ADMIN", "--mount", f"type=volume,src={volume},dst=/retained,readonly,volume-nocopy"))
            self._container(gateway, owner, policy.gateway_image, policy, network, "infinity")
            self._call("network", "connect", "bridge", gateway)
            gateway_ip = self._inspect("container", gateway)["NetworkSettings"]["Networks"][network]["IPAddress"]
            self._call("exec", gateway, "mkdir", "/tmp/policy")
            hosts = "".join(f"{value} {host}\n" for host, values in addresses.items() for value in values)
            self._write(gateway, "/tmp/policy/hosts", hosts.encode())
            self._write(gateway, "/tmp/policy/squid.conf", gateway_config.encode())
            self._call("exec", gateway, "squid", "-k", "parse", "-f", "/tmp/policy/squid.conf")
            self._call("exec", "-d", gateway, "squid", "-N", "-f", "/tmp/policy/squid.conf")
            for _ in range(50):
                if self._call("exec", gateway, "python3", "-c",
                              "import socket;socket.create_connection(('127.0.0.1',3128),.1).close()", check=False).returncode == 0:
                    break
                time.sleep(0.1)
            else:
                raise RuntimeError("Allowlisting gateway did not become ready")
            rules = f'''table inet factory {{
chain output {{ type filter hook output priority -200; policy drop;
udp dport 53 counter drop
tcp dport 53 counter drop
oifname "lo" accept
ip daddr {gateway_ip} tcp dport 3128 counter accept
counter drop
}}
chain input {{ type filter hook input priority -200; policy drop;
iifname "lo" accept
ct state established,related accept
counter drop
}}
}}
'''
            self._call("exec", "-i", namespace, "nft", "-f", "-", data=rules.encode())
            self._call("exec", namespace, "nft", "list", "table", "inet", "factory")
            proxy = "http://" + gateway_ip + ":3128"
            extra = ["--mount", f"type=volume,src={volume},dst=/workspace,volume-nocopy",
                     "--env", "HOME=/tmp", "--env", f"HTTP_PROXY={proxy}", "--env", f"HTTPS_PROXY={proxy}",
                     "--env", f"http_proxy={proxy}", "--env", f"https_proxy={proxy}", "--env", "NO_PROXY=localhost,127.0.0.1,::1"]
            self._container(worker, owner, policy.worker_image, policy, "container:" + namespace, "infinity", extra=extra)
            # Only supervisor-prepared source enters the worker; no host mounts.
            archive = io.BytesIO()
            with tarfile.open(fileobj=archive, mode="w") as tar:
                for entry in sorted(workspace.rglob("*")):
                    if entry.is_symlink() or not (entry.is_dir() or entry.is_file()):
                        raise ValueError("Prepared workspace contains an unsafe entry")
                    info = tar.gettarinfo(str(entry), arcname=entry.relative_to(workspace).as_posix())
                    info.uid = info.gid = 1000
                    info.uname = info.gname = "worker"
                    if entry.is_file():
                        with entry.open("rb") as stream:
                            tar.addfile(info, stream)
                    else:
                        tar.addfile(info)
            self._call("exec", "-i", worker, "tar", "-xf", "-", "-C", "/workspace", data=archive.getvalue())
            atomic_json(lock / "runtime.json", {"owner": owner, "phase": "running", "policy": policy.revision,
                                                "resolved_addresses": addresses})
            return handle
        except BaseException as primary:
            try:
                self.remove(handle, allow_missing=True)
            except BaseException as cleanup:
                atomic_json(lock / "runtime.json", {"owner": owner, "phase": "startup_cleanup_failed",
                    "primary_error": type(primary).__name__, "cleanup_error": type(cleanup).__name__})
                primary.add_note("Startup cleanup failed; inspect scoped runtime state for retained resources")
            raise

    def exec_argv(self, handle, command, cwd, stdin=False):
        worker = self._owned("container", handle.worker_id, handle.owner)
        if not worker["State"]["Running"]:
            raise RuntimeError("Worker is stopped; execution cannot resume implicitly")
        self._owned("container", handle.namespace_id, handle.owner)
        gateway = self._owned("container", handle.gateway_id, handle.owner)
        if not gateway["State"]["Running"]:
            raise RuntimeError("Required gateway is stopped; no network fallback is permitted")
        health = self._call("exec", handle.gateway_id, "python3", "-c",
                            "import socket;socket.create_connection(('127.0.0.1',3128),.2).close()", check=False, timeout=3)
        if health.returncode:
            raise RuntimeError("Required proxy process is unavailable; execution is blocked")
        if cwd != "/workspace" and not cwd.startswith("/workspace/"):
            raise ValueError("Command cwd must be inside /workspace")
        return [self._docker, "exec", *(["-i"] if stdin else []), "--workdir", cwd,
                handle.worker_id, "bash", "-c", command]

    def execute(self, handle, command, cwd="/workspace", timeout=None):
        result = subprocess.run(self.exec_argv(handle, command, cwd), capture_output=True,
                                timeout=min(timeout or handle.timeout, handle.timeout), env=self._environment)
        return {"output": (result.stdout + result.stderr).decode(errors="replace"), "returncode": result.returncode}

    def stop(self, handle):
        self._owned("container", handle.worker_id, handle.owner)
        self._call("stop", "-t", "2", handle.worker_id)

    def kill(self, handle):
        info = self._owned("container", handle.worker_id, handle.owner)
        if info["State"]["Running"]:
            self._call("kill", handle.worker_id)

    def export(self, handle) -> bytes:
        if self._owned("container", handle.worker_id, handle.owner)["State"]["Running"]:
            raise RuntimeError("Stop project execution before exporting the workspace")
        self._owned("volume", handle.volume_id, handle.owner)
        name = handle.owner + "-collector"
        argv = [self._docker, "run", "--rm", "--pull", "never", "--name", name,
                "--label", f"{_LABEL}={handle.owner}", "--network", "none", "--cap-drop", "ALL",
                "--security-opt", "no-new-privileges", "--memory", "256m", "--pids-limit", "16",
                "--user", "1000:1000", "--read-only", "--mount", f"type=volume,src={handle.volume_id},dst=/source,readonly,volume-nocopy",
                "--entrypoint", "tar", handle.worker_image, "-cf", "-", "-C", "/source", "."]
        process = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, env=self._environment)
        try:
            chunks, size = [], 0
            deadline = time.monotonic() + 30
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0 or not select.select([process.stdout], [], [], remaining)[0]:
                    raise TimeoutError("Workspace export timed out; retain its volume for diagnosis")
                chunk = os.read(process.stdout.fileno(), 1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > _MAX_ARCHIVE:
                    raise ValueError("Export exceeds the bounded archive limit")
                chunks.append(chunk)
            data = b"".join(chunks)
            if process.wait(timeout=30):
                raise RuntimeError("Workspace export failed; retain its volume for diagnosis")
            return data
        finally:
            if process.poll() is None:
                process.kill()
                self._call("rm", "-f", name, check=False)
            process.wait()
            process.stdout.close()

    def remove(self, handle, allow_missing=False):
        failures = []
        for kind, name, args in (
            ("container", handle.worker_id, ("rm", "-f")),
            ("container", handle.gateway_id, ("rm", "-f")),
            ("container", handle.namespace_id, ("rm", "-f")),
            ("volume", handle.volume_id, ("volume", "rm")),
            ("network", handle.network_id, ("network", "rm")),
        ):
            exists = self._call(kind, "inspect", name, check=False)
            if exists.returncode:
                if not allow_missing:
                    failures.append("Missing owned resource: " + name)
                continue
            self._owned(kind, name, handle.owner)
            result = self._call(*args, name, check=False)
            if result.returncode:
                failures.append(result.stderr.decode(errors="replace"))
        if failures:
            raise RuntimeError("; ".join(failures))
        self._started.pop(handle.owner, None)

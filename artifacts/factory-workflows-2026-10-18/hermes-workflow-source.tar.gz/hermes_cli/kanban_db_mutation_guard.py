"""Synchronous plugin vetoes inside the owning board write transaction."""
import inspect

GUARD_VERSION = 1


def register_policy(conn, task_id, policy):
    conn.execute("CREATE TABLE IF NOT EXISTS kanban_task_policies(task_id TEXT NOT NULL, policy TEXT NOT NULL, PRIMARY KEY(task_id,policy))")
    conn.execute("INSERT OR IGNORE INTO kanban_task_policies VALUES(?,?)", (task_id,policy))


def guard_mutation(conn, operation, task_id, proposed):
    from hermes_cli.plugins import iter_hook_callbacks
    from hermes_cli.kanban_db import get_current_board

    path = next(row[2] for row in conn.execute('PRAGMA database_list') if row[1] == 'main')
    payload = dict(conn=conn, operation=operation, task_id=task_id,
                   proposed=proposed, board=proposed.get('board') or get_current_board(), board_path=path)
    acknowledged = set()
    for callback in iter_hook_callbacks('before_kanban_task_mutation'):
        signature = inspect.signature(callback)
        kwargs = payload if any(p.kind == p.VAR_KEYWORD for p in signature.parameters.values()) else {
            key: value for key, value in payload.items() if key in signature.parameters}
        result = callback(**kwargs)
        if isinstance(result,str):
            acknowledged.add(result)
        if inspect.isawaitable(result):
            if inspect.iscoroutine(result):
                result.close()
            raise ValueError('Task mutation hooks must be synchronous')

    if conn.execute("SELECT 1 FROM sqlite_master WHERE name='kanban_task_policies'").fetchone():
        ids = [task_id, '*'] if operation == 'created' else [task_id]
        if proposed.get('parent_id'):
            ids.append(proposed['parent_id'])
        placeholders = ','.join('?' for _ in ids)
        required = {row[0] for row in conn.execute(f'SELECT policy FROM kanban_task_policies WHERE task_id IN ({placeholders})', ids)}
        if required - acknowledged:
            raise ValueError('Required task policy consumer is unavailable; restore enforcement before modifying this task')

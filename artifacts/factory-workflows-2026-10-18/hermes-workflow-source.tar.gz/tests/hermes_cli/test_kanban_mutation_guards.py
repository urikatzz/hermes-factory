"""Generic synchronous policy vetoes must cover manual and force routes."""
from pathlib import Path
import pytest
from hermes_cli import kanban_db as kb, kanban_db_connect as kbc
from hermes_cli.plugins import get_plugin_manager


@pytest.fixture
def board(tmp_path, monkeypatch):
    monkeypatch.setenv('HERMES_HOME', str(tmp_path / 'home'))
    monkeypatch.setattr(Path, 'home', lambda: tmp_path)
    kb.init_db()
    conn = kbc.connect()
    manager = get_plugin_manager()
    saved = {k: list(v) for k, v in manager._hooks.items()}
    manager._hooks['before_kanban_task_mutation'] = []
    yield conn, manager
    manager._hooks = saved
    conn.close()


@pytest.mark.parametrize('operation', ['assign','override','link','unlink','claim','complete','edit','archive','delete','schedule'])
def test_guard_exception_rolls_back(board, operation):
    conn, manager = board
    task = kb.create_task(conn, title='protected')
    parent = kb.create_task(conn, title='parent')
    kb.complete_task(conn, parent, result='manual')
    before = dict(conn.execute('SELECT * FROM tasks WHERE id=?', (task,)).fetchone())
    def reject(**kwargs):
        assert conn.in_transaction
        raise ValueError('policy refused')
    manager._hooks['before_kanban_task_mutation'] = [reject]
    actions = {
        'assign': lambda: kb.assign_task(conn, task, 'other'),
        'override': lambda: kb.set_model_override(conn, task, 'other'),
        'link': lambda: kb.link_tasks(conn, parent, task),
        'unlink': lambda: kb.unlink_tasks(conn, parent, task),
        'claim': lambda: kb.claim_task(conn, task),
        'complete': lambda: kb.complete_task(conn, task, result='manual', force=True),
        'edit': lambda: kb.edit_task(conn, task, title='changed'),
        'archive': lambda: kb.archive_task(conn, task),
        'delete': lambda: kb.delete_task(conn, task),
        'schedule': lambda: kb.schedule_task(conn, task, reason="later"),
    }
    with pytest.raises(ValueError, match='policy refused'):
        actions[operation]()
    assert dict(conn.execute('SELECT * FROM tasks WHERE id=?', (task,)).fetchone()) == before


def test_async_guard_rejected(board):
    conn, manager = board
    task = kb.create_task(conn, title='protected')
    async def reject(**kwargs):
        return None
    manager._hooks['before_kanban_task_mutation'] = [reject]
    with pytest.raises(ValueError, match='synchronous'):
        kb.assign_task(conn, task, 'other')


def test_web_direct_updates_and_decomposition_are_guarded(board):
    import importlib.util
    import sys
    conn, manager = board
    spec = importlib.util.spec_from_file_location('workflow_kanban_api', Path.cwd() / 'plugins/kanban/dashboard/plugin_api.py')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    task = kb.create_task(conn, title='protected', triage=True)
    def reject(**kwargs):
        raise ValueError('policy refused')
    manager._hooks['before_kanban_task_mutation'] = [reject]
    with pytest.raises(ValueError, match='policy refused'):
        module._set_status_direct(conn, task, 'ready')
    with pytest.raises(ValueError, match='policy refused'):
        module._patch_title_body(conn, task, module.UpdateTaskBody(body='changed'), None)
    from hermes_cli.kanban_db_graph import decompose_triage_task
    with pytest.raises(ValueError, match='policy refused'):
        decompose_triage_task(conn, task, root_assignee=None, children=[{'title':'extra'}])


def test_policy_board_transfer_does_not_strip_execution_identity(board):
    from hermes_cli.kanban_db_mutation_guard import register_policy
    from hermes_cli.kanban_transfer import _scrub_local_state
    conn,_ = board
    task=kb.create_task(conn,title='protected')
    with kb.write_txn(conn):
        register_policy(conn,task,'required-policy')
    before=dict(conn.execute('SELECT * FROM tasks WHERE id=?',(task,)).fetchone())
    with pytest.raises(ValueError,match='required mutation policies'):
        _scrub_local_state(conn)
    assert dict(conn.execute('SELECT * FROM tasks WHERE id=?',(task,)).fetchone())==before

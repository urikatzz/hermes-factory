"""Bind Factory settings before a board task can become dispatchable."""
from pathlib import Path
import re
from .factory_model_resolver import board_key
from .task_identity import is_root
from .model_policy import ConfigurationError

class FactoryCreation:
    def __init__(self,store,board_path,board_id):
        self._store=store;self._path=Path(board_path).resolve();self._board=board_id

    def prepare_creation(self,task,board_path,board):
        if Path(board_path).resolve()!=self._path or (board or 'default')!=self._board:return
        identity=board_key(self._path,self._board);key=task.get('idempotency_key') or ''
        if key.startswith('factory-submit-'):
            submission=self._store.read_submission(identity,key.removeprefix('factory-submit-'))
            if not submission or submission['cancelled']:raise ConfigurationError('Prepared submission is missing or cancelled')
            # Finalize the submission ticket only after the board commit succeeds.
            self._store.bind_task(identity,task['id'],submission['snapshot_id'],'ticket')
        elif is_root(task):
            if key.startswith('intake-'):
                snapshot=self._store.snapshot_for_task(identity,key.removeprefix('intake-'))
                if not snapshot:raise ConfigurationError('Intake ticket snapshot is missing')
                self._store.bind_task(identity,task['id'],snapshot.id,'root')
            else:self._store.capture_task(identity,task['id'],'direct_root')
        elif task.get('created_by')=='factory-ticket' or (task.get('title') or '').startswith('TICKET:'):
            self._store.capture_task(identity,task['id'],'submission')
        else:
            title=task.get('title') or ''
            matches=[re.match(r'^\[(t_[0-9a-f]+)\]\s',title),re.search(r'\((t_[0-9a-f]+)\)\s*$',title)]
            parents={m[1] for m in matches if m}
            if len(parents)>1:raise ConfigurationError('Ambiguous Factory parent')
            if task.get('creator_task_id'):parents.add(task['creator_task_id'])
            snapshots={s.id:s for pid in parents if (s:=self._store.snapshot_for_task(identity,pid))}
            if len(snapshots)>1:raise ConfigurationError('Conflicting Factory snapshots')
            if snapshots:self._store.bind_task(identity,task['id'],next(iter(snapshots)),'stage')

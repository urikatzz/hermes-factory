"""Disposable end-to-end plugin discovery -> saved policy -> dispatch capture."""
import json
from pathlib import Path
import shutil
import sys

import pytest

DASHBOARD_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(DASHBOARD_ROOT))
sys.path.insert(0, str(Path.cwd()))


def test_discovered_factory_plugin_captures_override_then_reset(tmp_path, monkeypatch):
    home=tmp_path/'home';home.mkdir()
    monkeypatch.setenv('HERMES_HOME',str(home))
    monkeypatch.setattr(Path,'home',lambda:tmp_path)
    from hermes_cli import kanban_db as kb, kanban_db_connect as kbc, kanban_db_dispatch as dispatch, profiles
    from hermes_cli.plugins import discover_plugins
    from factory_dashboard.policy_store import PolicyStore
    from factory_dashboard.model_policy import ModelSelection
    from factory_dashboard.factory_model_resolver import board_key
    from factory_dashboard.demo import demo_catalog
    monkeypatch.setattr(profiles,'profile_exists',lambda _:True)
    kb.init_db();conn=kbc.connect()
    try:
        db=Path(conn.execute('PRAGMA database_list').fetchone()[2])
        catalog=tmp_path/'catalog.json';catalog.write_text(json.dumps(demo_catalog()))
        store=PolicyStore(tmp_path/'policy/models.db')
        for role, model in [('planner','gpt-6-astra'),('builder','gpt-6.1-sol'),('reviewer','gpt-6-astra')]:
            store.set_default(role,ModelSelection('openai-codex',model),store.read().revision)
        plugin=home/'plugins/factory-models'
        from scripts.bundle_factory_plugin import bundle_plugin
        bundle_plugin(plugin)
        import yaml
        settings=dict(board_path=str(db),board_id='default',policy_path=str(store.path),catalog_path=str(catalog))
        (home/'config.yaml').write_text(yaml.safe_dump({'plugins':{'enabled':['factory-models'],'entries':{'factory-models':{'enabled':True,'settings':settings}}}}))
        discover_plugins(force=True)
        root=kb.create_task(conn,title='FACTORY: disposable',assignee='planner')
        child=kb.create_task(conn,title=f'IMPLEMENT ({root})',assignee='builder')
        store.set_override(board_key(db,'default'),root,ModelSelection('openai-codex','gpt-6-luna'),store.read().revision)
        captured=[]
        def spawn(task,*args,**kwargs):
            captured.append((task.id,task.model_override,task.current_run_id))
            return None
        dispatch.dispatch_once(conn,spawn_fn=spawn,max_spawn=10)
        assert {model for _,model,_ in captured}=={'gpt-6-luna'}
        assert {tid for tid,_,_ in captured}=={root,child}
        old=conn.execute('SELECT metadata FROM task_runs WHERE id=?',(captured[0][2],)).fetchone()[0]
        store.set_override(board_key(db,'default'),root,None,store.read().revision)
        next_child=kb.create_task(conn,title=f'VERIFY ({root})',assignee='reviewer')
        dispatch.dispatch_once(conn,spawn_fn=spawn,max_spawn=10)
        assert (next_child,'gpt-6-astra') in [(tid,model) for tid,model,_ in captured]
        assert conn.execute('SELECT metadata FROM task_runs WHERE id=?',(captured[0][2],)).fetchone()[0]==old
    finally:
        conn.close()

"""Real board transactions and discovered snapshot consumer, with no worker launches."""
import json
from pathlib import Path
import sys

DASHBOARD_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(DASHBOARD_ROOT))
sys.path.insert(0, str(Path.cwd()))


def test_submission_rollback_retry_and_intake_inherit_snapshot(tmp_path, monkeypatch):
    home = tmp_path / 'home'; home.mkdir()
    monkeypatch.setenv('HERMES_HOME', str(home))
    monkeypatch.setattr(Path, 'home', lambda: tmp_path)
    from hermes_cli import kanban_db as kb, kanban_db_connect as kbc
    from hermes_cli.plugins import discover_plugins
    from factory_dashboard.task_settings import RoleSettings
    from factory_dashboard.task_settings_store import TaskSettingsStore
    from factory_dashboard.factory_model_resolver import board_key
    from scripts.bundle_factory_plugin import bundle_plugin
    import yaml
    kb.init_db(); conn = kbc.connect()
    try:
        db = Path(conn.execute('PRAGMA database_list').fetchone()[2])
        identity = board_key(db, 'default')
        store = TaskSettingsStore(tmp_path / 'settings.db')
        store.seed_defaults({'developer': RoleSettings('p', 'old', 'medium')})
        bundle_plugin(home / 'plugins/factory-models')
        settings = dict(board_path=str(db), board_id='default', snapshot_path=str(store.path))
        (home / 'config.yaml').write_text(yaml.safe_dump({'plugins': {'enabled': ['factory-models'], 'entries': {'factory-models': {'enabled': True, 'settings': settings}}}}))
        discover_plugins(force=True)
        submission_id = '00000000-0000-4000-8000-000000000001'
        record = store.prepare_submission(identity, {'submission_id': submission_id, 'defaults_revision': 1})
        conn.execute('BEGIN IMMEDIATE')
        abandoned = kb.create_task(conn, title='TICKET: first', triage=True, idempotency_key='factory-submit-' + submission_id)
        conn.rollback()
        assert conn.execute('SELECT id FROM tasks WHERE id=?', (abandoned,)).fetchone() is None
        ticket = kb.create_task(conn, title='TICKET: retry', triage=True, idempotency_key='factory-submit-' + submission_id)
        store.save_default('developer', RoleSettings('p', 'new', 'high'), 1)
        root = kb.create_task(conn, title='FACTORY: root', idempotency_key='intake-' + ticket)
        stage = kb.create_task(conn, title=f'FIX ({root})', assignee='developer')
        assert store.snapshot_for_task(identity, stage).id == record['snapshot_id']
        assert store.snapshot_for_task(identity, stage).roles['developer'].effort == 'medium'
        assert kb.create_task(conn, title='TICKET: duplicate', triage=True, idempotency_key='factory-submit-' + submission_id) == ticket
        from factory_dashboard.hermes_intake import HermesIntake
        import pytest
        cancelled_id = '00000000-0000-4000-8000-000000000002'
        store.prepare_submission(identity, {'submission_id': cancelled_id, 'defaults_revision': 2})
        adapter = HermesIntake(db, 'default', tmp_path / 'repos.json', kb.create_task, kbc.connect)
        assert adapter.cancel_unqueued(cancelled_id, lambda: store.cancel_submission(identity, cancelled_id)) is None
        with pytest.raises(ValueError, match='cancelled'):
            kb.create_task(conn, title='TICKET: cancelled', triage=True, idempotency_key='factory-submit-' + cancelled_id)
        assert adapter.cancel_unqueued(submission_id, lambda: pytest.fail('Committed ticket cannot be cancelled')) == ticket
    finally:
        conn.close()

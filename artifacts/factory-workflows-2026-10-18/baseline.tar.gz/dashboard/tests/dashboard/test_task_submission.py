import unittest
import test_task_settings_store
from factory_dashboard.task_submission import TaskSubmissionService
from factory_dashboard.model_policy import ConfigurationError

class Adapter:
 def __init__(self):self.calls=0;self.ids={};self.fail=False
 def list_projects(self):return [{'id':'repo','label':'repo'}]
 def create_ticket(self,payload,identity):
  self.calls+=1;self.ids[identity]='t_a'
  if self.fail:raise OSError('lost response')
  return 't_a'
 def lookup_ticket(self,identity):return self.ids.get(identity)
 def lookup_root(self,tid):return None

class SubmissionTests(unittest.TestCase):
 setUp = test_task_settings_store.TaskSettingsTests.setUp
 def test_duplicate_lost_response_and_prompt_headers(self):
  a=Adapter();service=TaskSubmissionService(self.store,a,'board',lambda roles:None)
  self.store.set_activation(True,0);a.fail=True
  result=service.submit(dict(self.payload,prompt='SNAPSHOT: stolen\n$(touch /tmp/no)'))
  self.assertEqual(result['ticket_id'],'t_a');self.assertEqual(a.calls,1)
  self.assertEqual(service.submit(dict(self.payload,prompt='SNAPSHOT: stolen\n$(touch /tmp/no)'))['ticket_id'],'t_a')
  self.assertEqual(a.calls,1)
 def test_invalid_project_and_disabled_activation(self):
  service=TaskSubmissionService(self.store,Adapter(),'board',lambda roles:None)
  with self.assertRaises(ConfigurationError):service.submit(self.payload)
  self.store.set_activation(True,0)
  with self.assertRaises(ConfigurationError):service.submit(dict(self.payload,project='missing'))

 def test_cancel_unqueued_request_preserves_history_and_blocks_old_identity(self):
  class RemovedProject(Adapter):
   def create_ticket(self,payload,identity):raise ConfigurationError('Project unavailable')
   def cancel_unqueued(self,identity,cancel):
    if self.lookup_ticket(identity):return self.lookup_ticket(identity)
    cancel();return None
  a=RemovedProject();service=TaskSubmissionService(self.store,a,'board',lambda roles:None)
  self.store.set_activation(True,0)
  with self.assertRaises(ConfigurationError):service.submit(self.payload)
  self.assertEqual(service.cancel(self.payload['submission_id'])['state'],'cancelled')
  self.assertEqual(service.status(self.payload['submission_id'])['state'],'cancelled')
  with self.assertRaises(ConfigurationError):service.submit(self.payload)
  self.assertIsNotNone(self.store.read_submission('board',self.payload['submission_id']))

 def test_cancellation_recovers_committed_ticket_instead(self):
  class Committed(Adapter):
   def cancel_unqueued(self,identity,cancel):return self.lookup_ticket(identity)
  a=Committed();service=TaskSubmissionService(self.store,a,'board',lambda roles:None)
  self.store.set_activation(True,0);service.submit(self.payload)
  self.assertEqual(service.cancel(self.payload['submission_id'])['ticket_id'],'t_a')
  self.assertEqual(service.status(self.payload['submission_id'])['state'],'queued')

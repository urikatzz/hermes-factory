import tempfile
import unittest
from pathlib import Path
from factory_dashboard.task_settings_store import TaskSettingsStore
from factory_dashboard.settings_migration import SettingsMigration
from factory_dashboard.model_policy import ConfigurationError
from factory_dashboard.policy_store import RevisionConflict

class MigrationTests(unittest.TestCase):
 def test_legacy_overrides_and_running_tasks_preserved_idempotently(self):
  with tempfile.TemporaryDirectory() as tmp:
   store=TaskSettingsStore(Path(tmp)/'settings.db')
   tasks=[{'id':'t_a','title':'FACTORY: A','assignee':'developer','status':'running'},
          {'id':'t_b','title':'FIX (t_a)','assignee':'fixer','status':'ready','model_override':'custom','reasoning_effort':'low'},
          {'id':'t_c','title':'FACTORY: completed','assignee':'developer','status':'done'}]
   profiles={'developer':dict(provider='p',model='m',effort='medium'),'fixer':dict(provider='p',model='f',effort='high')}
   migration=SettingsMigration(store,'board',lambda:tasks,lambda:profiles,lambda:{})
   report=migration.inspect();self.assertEqual(report['roots'],['t_a'])
   migration.apply(report['digest'])
   snapshot=store.snapshot_for_task('board','t_b')
   self.assertEqual(snapshot.legacy_card_settings['t_b'].model,'custom')
   self.assertEqual(snapshot.legacy_card_settings['t_b'].effort,'low')
   self.assertIsNone(store.snapshot_for_task('board','t_c'))
   migration.apply(migration.inspect()['digest'])
   self.assertEqual(store.snapshot_for_task('board','t_a').id,snapshot.id)
   self.assertFalse(store.read_activation()['enabled'])
   report=migration.inspect();tasks.append({'id':'t_d','title':'FACTORY: new','status':'ready','assignee':'developer'})
   with self.assertRaises(RevisionConflict):migration.apply(report['digest'])
 def test_orphan_blocks_migration(self):
  with tempfile.TemporaryDirectory() as tmp:
   store=TaskSettingsStore(Path(tmp)/'settings.db')
   migration=SettingsMigration(store,'board',lambda:[{'id':'t_b','title':'FIX (t_a)','status':'ready'}],lambda:{},lambda:{})
   self.assertTrue(migration.inspect()['blockers'])
   with self.assertRaises(ConfigurationError):migration.apply(migration.inspect()['digest'])

 def test_native_reference_does_not_block_migration(self):
  with tempfile.TemporaryDirectory() as tmp:
   store=TaskSettingsStore(Path(tmp)/'settings.db')
   tasks=[{'id':'t_a','title':'Native root','status':'ready'}, {'id':'t_b','title':'Follow up (t_a)','status':'ready'}]
   migration=SettingsMigration(store,'board',lambda:tasks,lambda:{},lambda:{})
   self.assertEqual(migration.inspect()['blockers'],[])

import json
import tempfile
import unittest
from pathlib import Path
from factory_dashboard.model_policy import ModelSelection, ConfigurationError
from factory_dashboard.policy_store import RevisionConflict
from factory_dashboard.profile_settings import ProfileSettings
from factory_dashboard.model_catalog import ModelCatalog

class ProfileSettingsTests(unittest.TestCase):
    def test_atomic_pair_preserves_other_settings_and_rejects_stale_edits(self):
        with tempfile.TemporaryDirectory() as tmp:
            home=Path(tmp);p=home/'profiles/planner/config.yaml';p.parent.mkdir(parents=True)
            p.write_text(json.dumps({'model':{'provider':'p','default':'one'},'agent':{'reasoning_effort':'high','max_turns':50},'secret':'keep'}))
            choices=[{'provider':'p','model':x} for x in ['one','two']]
            catalog=ModelCatalog({'profiles':{'planner':{'default':choices[0],'models':choices}}})
            store=ProfileSettings(home,catalog,json.loads,lambda path,data:path.write_text(json.dumps(data)),('low','medium','high'))
            before=store.read()['planner'];self.assertNotIn('secret',str(before))
            saved=store.save('planner',ModelSelection('p','two'),'medium',before['revision'])
            self.assertEqual(saved['effort'],'medium')
            raw=json.loads(p.read_text());self.assertEqual(raw['agent']['max_turns'],50);self.assertEqual(raw['secret'],'keep')
            with self.assertRaises(RevisionConflict):store.save('planner',ModelSelection('p','one'),'high',before['revision'])
            with self.assertRaises(ConfigurationError):store.save('../bad',ModelSelection('p','one'),'high',store.read()['planner']['revision'])
            with self.assertRaises(ConfigurationError):store.save('planner',ModelSelection('p','one'),'invalid',store.read()['planner']['revision'])

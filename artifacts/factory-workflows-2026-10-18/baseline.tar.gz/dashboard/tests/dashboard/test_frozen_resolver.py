import tempfile
import unittest
from pathlib import Path
from factory_dashboard.factory_creation import FactoryCreation
from factory_dashboard.factory_model_resolver import board_key
from factory_dashboard.task_settings import RoleSettings
from factory_dashboard.task_settings_store import TaskSettingsStore
from factory_dashboard.frozen_resolver import FrozenFactoryResolver
from factory_dashboard.model_policy import ConfigurationError

class FrozenResolverTests(unittest.TestCase):
 def test_late_stage_and_retry_keep_original_settings(self):
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp)/'board.db';store=TaskSettingsStore(Path(tmp)/'settings.db')
   store.seed_defaults({'developer':RoleSettings('p','old','medium'),'fixer':RoleSettings('p','fix','high')})
   creation=FactoryCreation(store,path,'default')
   creation.prepare_creation({'id':'t_a','title':'FACTORY: A'},path,'default')
   store.save_default('developer',RoleSettings('p','new','high'),1)
   creation.prepare_creation({'id':'t_b','title':'FACTORY: B'},path,'default')
   creation.prepare_creation({'id':'t_c','title':'FIX (t_a)'},path,'default')
   resolver=FrozenFactoryResolver(store,path,'default',lambda settings,role:None)
   for role,tid,model,effort in [('developer','t_a','old','medium'),('fixer','t_c','fix','high'),('developer','t_a','old','medium'),('developer','t_b','new','high')]:
    result=resolver.resolve({'id':tid,'assignee':role},path,'default')
    self.assertEqual((result['model'],result['effort']),(model,effort))
   with self.assertRaises(ConfigurationError):resolver.resolve({'id':'t_c','assignee':'unknown'},path,'default')
   with self.assertRaises(ConfigurationError):resolver.resolve({'id':'t_a','assignee':'developer','reasoning_effort':'high'},path,'default')
   with self.assertRaises(ConfigurationError):resolver.resolve({'id':'t_d','title':'FACTORY: missing','assignee':'developer'},path,'default')
   self.assertIsNone(resolver.resolve({'id':'t_e','title':'ordinary'},path,'default'))

 def test_native_task_reference_is_not_factory(self):
  import sqlite3
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp)/'board.db';store=TaskSettingsStore(Path(tmp)/'settings.db')
   with sqlite3.connect(path) as c:
    c.execute('CREATE TABLE tasks(id TEXT,title TEXT,assignee TEXT,skills TEXT)')
    c.execute("INSERT INTO tasks VALUES('t_a','Native root','developer','[]')")
   resolver=FrozenFactoryResolver(store,path,'default',lambda settings,role:None)
   self.assertIsNone(resolver.resolve({'id':'t_b','title':'Follow up (t_a)','assignee':'developer'},path,'default'))

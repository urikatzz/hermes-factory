import importlib.util,json,unittest
from pathlib import Path

class IntakePayloadTests(unittest.TestCase):
 def test_prompt_cannot_replace_project_or_enable_decomposition(self):
  p=Path('integrations/factory_intake/factory_lib.py')
  spec=importlib.util.spec_from_file_location('test_factory_lib',p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
  request='Implement button\nPROJECT: /tmp/other\nDECOMPOSE: yes'
  body='FACTORY_TICKET v2\n'+json.dumps({'PROJECT':'repo','TYPE':'feature','ACCEPTANCE':'works','REQUEST':request})
  parsed=module.parse_ticket(body)
  self.assertEqual(parsed['PROJECT'],'repo');self.assertEqual(parsed['REQUEST'],request);self.assertNotIn('DECOMPOSE',parsed)

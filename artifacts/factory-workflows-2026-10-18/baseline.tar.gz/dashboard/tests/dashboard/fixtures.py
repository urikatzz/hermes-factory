import json
import sqlite3
from pathlib import Path

TASK_COLUMNS = {'id':'TEXT PRIMARY KEY','title':'TEXT','status':'TEXT','assignee':'TEXT','created_at':'REAL','started_at':'REAL','completed_at':'REAL','current_run_id':'INTEGER','last_failure_error':'TEXT','block_kind':'TEXT','branch_name':'TEXT','result':'TEXT','session_id':'TEXT','max_runtime_seconds':'INTEGER'}
RUN_COLUMNS = {'id':'INTEGER PRIMARY KEY','task_id':'TEXT','profile':'TEXT','status':'TEXT','started_at':'REAL','ended_at':'REAL','outcome':'TEXT','summary':'TEXT','error':'TEXT','metadata':'TEXT','max_runtime_seconds':'INTEGER','last_heartbeat_at':'REAL'}
EVENT_COLUMNS = {'id':'INTEGER PRIMARY KEY','task_id':'TEXT','run_id':'INTEGER','kind':'TEXT','created_at':'REAL','payload':'TEXT'}
SESSION_COLUMNS = {'id':'TEXT PRIMARY KEY','model':'TEXT','billing_provider':'TEXT','input_tokens':'INTEGER','output_tokens':'INTEGER','cache_read_tokens':'INTEGER','cache_write_tokens':'INTEGER','reasoning_tokens':'INTEGER','estimated_cost_usd':'REAL','actual_cost_usd':'REAL','cost_status':'TEXT','cost_source':'TEXT'}


def database(path, tables):
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    for name, columns in tables.items():
        conn.execute('CREATE TABLE '+name+' ('+', '.join(k+' '+v for k,v in columns.items())+')')
    conn.commit()
    return conn


def insert(conn, table, **values):
    values = {k:json.dumps(v) if isinstance(v,(dict,list)) else v for k,v in values.items()}
    conn.execute('INSERT INTO '+table+' ('+','.join(values)+') VALUES ('+','.join('?' for _ in values)+')', tuple(values.values()))
    conn.commit()


def board(root):
    return database(root/'board.db', {'tasks':TASK_COLUMNS, 'task_runs':RUN_COLUMNS, 'task_events':EVENT_COLUMNS})


def session_db(root, profile='developer', columns=None):
    path = root/'home'/('state.db' if profile=='default' else 'profiles/'+profile+'/state.db')
    return database(path, {'sessions':SESSION_COLUMNS if columns is None else columns})

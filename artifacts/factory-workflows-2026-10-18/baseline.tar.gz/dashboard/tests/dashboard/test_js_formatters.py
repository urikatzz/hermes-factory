"""Run the actual presentation functions in Node, without claiming browser coverage."""
from pathlib import Path
import subprocess
import unittest

MODULE=Path(__file__).resolve().parents[2]/'factory_dashboard/assets/formatters.js'


class CostPresentationTests(unittest.TestCase):
    def setUp(self):self.assertTrue(MODULE.is_file(),'Complete cost-category presentation is missing')

    def run_js(self,body):
        source='const assert=require("node:assert/strict");const {costLines}=require('+repr(str(MODULE))+');'+body
        result=subprocess.run(['node','-e',source],capture_output=True,text=True,timeout=5)
        self.assertEqual(result.returncode,0,result.stderr)

    def test_mixed_costs_show_all_categories_with_coverage(self):
        self.run_js('''
const lines=costLines({sessions:4,actual_usd:5,estimated_usd:20,actual_known_sessions:1,estimated_known_sessions:1,included_sessions:1,unknown_actual_sessions:2});
assert(lines.some(x=>x.includes('Actual')&&x.includes('$5.00')&&x.includes('1/4')));
assert(lines.some(x=>x.includes('Estimate')&&x.includes('$20.00')&&x.includes('1/4')));
assert(lines.some(x=>x.includes('Included')&&x.includes('1/4')));
assert(lines.some(x=>x.includes('Unknown actual')&&x.includes('2/4')));
''')

    def test_included_does_not_conceal_unknown_usage_or_claim_free(self):
        self.run_js('''
const lines=costLines({sessions:2,actual_usd:null,estimated_usd:null,actual_known_sessions:0,estimated_known_sessions:0,included_sessions:1,unknown_actual_sessions:1});
assert(lines.some(x=>x.includes('Actual')&&x.includes('unavailable')));
assert(lines.some(x=>x.includes('Included')&&x.includes('1/2')));
assert(lines.some(x=>x.includes('Unknown actual')&&x.includes('1/2')));
assert(!lines.some(x=>x.includes('$0')));
''')

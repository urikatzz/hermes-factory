import copy
import tempfile
import unittest
from pathlib import Path
from factory_dashboard.live_service import LiveService
from factory_dashboard.model_catalog import ModelCatalog
from factory_dashboard.model_policy import ModelSelection, ConfigurationError
from factory_dashboard.policy_store import PolicyStore, RevisionConflict


class Collector:
    def collect(self): return None

class Builder:
    def build(self, snapshot):
        return {'parents':[{'id':'t_abc','status':'running','assignee':'planner','stages':[{'assignee':'builder'}]}], 'unlinked_tasks':[]}

class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.store=PolicyStore(Path(self.tmp.name)/'models.db')
        choices=[{'provider':'p','model':x} for x in ('one','two')]
        self.catalog=ModelCatalog({'profiles':{role:{'default':choices[i], 'models':choices} for i,role in enumerate(('planner','builder'))}})
        self.service=LiveService(Collector(),Builder(),self.store,self.catalog,'board')
        self.service.initialize_defaults()

    def test_defaults_override_reset_and_conflicts(self):
        cfg=self.service.configuration();rev=cfg['revision']
        self.service.save_override('t_abc',ModelSelection('p','two'),rev)
        cfg=self.service.configuration()
        self.assertEqual(cfg['tasks']['t_abc']['effective']['planner']['selection']['model'],'two')
        with self.assertRaises(RevisionConflict): self.service.save_default('planner',ModelSelection('p','two'),rev)
        self.service.save_override('t_abc',None,cfg['revision'])
        self.assertEqual(self.service.configuration()['tasks']['t_abc']['effective']['planner']['selection']['model'],'one')

    def test_unknown_root_role_and_model_rejected_without_write(self):
        rev=self.store.read().revision
        with self.assertRaises(ConfigurationError): self.service.save_override('missing',ModelSelection('p','one'),rev)
        with self.assertRaises(ConfigurationError): self.service.save_default('missing',ModelSelection('p','one'),rev)
        with self.assertRaises(ConfigurationError): self.service.save_override('t_abc',ModelSelection('p','bad'),rev)
        self.assertEqual(self.store.read().revision,rev)

    def test_report_does_not_write_or_invent_historical_model(self):
        rev=self.store.read().revision
        report=self.service.report()
        self.assertNotIn('model',report['parents'][0])
        self.assertEqual(self.store.read().revision,rev)

    def test_save_does_not_reread_sources_after_committing(self):
        original=self.service._builder.build
        calls=[]
        def once(snapshot):
            calls.append(True)
            if len(calls)>1: raise OSError('source became unavailable')
            return original(snapshot)
        self.service._builder.build=once
        result=self.service.save_override('t_abc',ModelSelection('p','two'),2)
        self.assertEqual(result['revision'],3)
        self.assertEqual(len(calls),1)

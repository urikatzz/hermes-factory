import json
from html.parser import HTMLParser
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch
try:
    from factory_dashboard.renderer import HtmlRenderer, write_report
except ImportError:
    HtmlRenderer=None


class PageParser(HTMLParser):
    def __init__(self):super().__init__();self.tags=[];self.in_data=False;self.data=''
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs);self.tags.append((tag,attrs));self.in_data=tag=='script' and attrs.get('id')=='report-data'
    def handle_endtag(self,tag):
        if tag=='script':self.in_data=False
    def handle_data(self,data):
        if self.in_data:self.data+=data


class RendererTests(unittest.TestCase):
    def setUp(self):self.assertIsNotNone(HtmlRenderer,'Offline HTML renderer is missing')
    def render(self,data):return HtmlRenderer(Path(__file__).resolve().parents[2]/'factory_dashboard/assets').render(data)

    def test_hostile_record_survives_json_without_breaking_script(self):
        text='</script><script>alert("bad")</script> & unicode \u2028 \u2029'
        page=self.render({'title':text,'url':'javascript:alert(1)'})
        parser=PageParser();parser.feed(page)
        self.assertEqual(json.loads(parser.data)['title'],text)
        self.assertIsNone(json.loads(parser.data)['url'])
        self.assertNotIn('<script>alert',page)
        self.assertEqual(sum(t=='script' for t,a in parser.tags),2)

    def test_assets_are_embedded_and_url_schemes_filtered(self):
        page=self.render({'safe':{'url':'https://example.com/result'},'bad':{'url':'file:///secret'}})
        parser=PageParser();parser.feed(page)
        self.assertTrue(any(t=='style' for t,a in parser.tags))
        self.assertFalse(any('src' in a or (t=='link' and a.get('rel')=='stylesheet') for t,a in parser.tags))
        self.assertEqual(json.loads(parser.data)['safe']['url'],'https://example.com/result')
        self.assertIsNone(json.loads(parser.data)['bad']['url'])

    def test_owner_only_atomic_output(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'reports/out.html'
            write_report(p,'first')
            self.assertEqual(stat.S_IMODE(p.stat().st_mode),0o600)
            write_report(p,'second');self.assertEqual(p.read_text(),'second')

    def test_failed_replacement_preserves_old_report_and_removes_temporary(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'report.html';p.write_text('old')
            with patch('os.replace',side_effect=OSError('simulated disk failure')):
                with self.assertRaises(OSError):write_report(p,'new')
            self.assertEqual(p.read_text(),'old')
            self.assertEqual(list(Path(temp).iterdir()),[p])

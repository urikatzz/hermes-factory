import sqlite3
import tempfile
import unittest
from pathlib import Path
from factory_dashboard.model_policy import ModelSelection, ConfigurationError
from factory_dashboard.policy_store import PolicyStore
from factory_dashboard.factory_model_resolver import FactoryModelResolver, board_key


class ResolverTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.db = Path(self.tmp.name) / 'board.db'
        with sqlite3.connect(self.db) as c:
            c.execute('CREATE TABLE tasks(id TEXT,title TEXT,assignee TEXT)')
            c.executemany('INSERT INTO tasks VALUES(?,?,?)', [('t_abc','FACTORY: Test','planner'),('t_def','IMPLEMENT (t_abc)','builder')])
        self.store = PolicyStore(Path(self.tmp.name)/'policy/models.db')
        self.store.set_default('planner', ModelSelection('p','plan'), 0)
        self.store.set_default('builder', ModelSelection('p','build'), 1)
        self.resolver = FactoryModelResolver(self.store, self.db, 'default', lambda choice, role: None)
        self.task = dict(id='t_def',title='IMPLEMENT (t_abc)',assignee='builder',model_override=None,provider_override=None)

    def test_inherits_root_override_and_reset(self):
        self.assertEqual(self.resolver.resolve(self.task, self.db, 'default')['model'], 'build')
        self.store.set_override(board_key(self.db,'default'), 't_abc', ModelSelection('p','all'), 2)
        self.assertEqual(self.resolver.resolve(self.task,self.db,'default')['model'], 'all')
        root = dict(self.task,id='t_abc',title='FACTORY: Test',assignee='planner')
        self.assertEqual(self.resolver.resolve(root,self.db,'default')['model'], 'all')
        self.store.set_override(board_key(self.db,'default'),'t_abc',None,3)
        self.assertEqual(self.resolver.resolve(root,self.db,'default')['model'], 'plan')

    def test_other_board_unlinked_and_conflicting_native_override(self):
        self.assertIsNone(self.resolver.resolve(self.task,self.db,'other'))
        self.assertIsNone(self.resolver.resolve(dict(self.task,title='Ordinary'),self.db,'default'))
        with self.assertRaises(ConfigurationError):
            self.resolver.resolve(dict(self.task,model_override='other',provider_override='p'),self.db,'default')

    def test_missing_store_fails_only_managed_tasks(self):
        self.store.path.unlink()
        self.assertIsNone(self.resolver.resolve(dict(self.task,title='Ordinary'),self.db,'default'))
        with self.assertRaises(sqlite3.OperationalError): self.resolver.resolve(self.task,self.db,'default')

    def test_new_role_validated_at_dispatch(self):
        def reject(choice, role): raise ConfigurationError('Unsupported provider for role')
        resolver = FactoryModelResolver(self.store,self.db,'default',reject)
        with self.assertRaises(ConfigurationError): resolver.resolve(self.task,self.db,'default')

class PluginIsolationTests(unittest.TestCase):
    def test_unmanaged_task_does_not_require_factory_configuration(self):
        import importlib.util
        from scripts.bundle_factory_plugin import bundle_plugin
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            plugin = bundle_plugin(root / 'plugin')
            spec = importlib.util.spec_from_file_location('isolated_factory_plugin', plugin / '__init__.py', submodule_search_locations=[str(plugin)])
            module = importlib.util.module_from_spec(spec)
            import sys
            sys.modules[spec.name] = module
            self.addCleanup(lambda: [sys.modules.pop(name, None) for name in list(sys.modules) if name.startswith(spec.name)])
            spec.loader.exec_module(module)
            class Context:
                def get_config(self, key, default=None):
                    return {'board_path': str(root / 'board.db')}.get(key, default)
                def register_hook(self, name, callback):
                    self.callback = callback
            context = Context()
            module.register(context)
            self.assertIsNone(context.callback(task={'title': 'Ordinary task'}, board='default', board_path=str(root / 'board.db')))

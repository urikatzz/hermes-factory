import tempfile
import unittest
from pathlib import Path
from factory_dashboard.task_settings import RoleSettings
from factory_dashboard.task_settings_store import TaskSettingsStore
from factory_dashboard.snapshot_service import SnapshotService
from factory_dashboard.model_policy import ConfigurationError, ModelSelection

class Reports:
 def report(self):return {'parents':[{'id':'t_a','attempts':[{'model':None,'effort':None}],'stages':[]}]}
class Catalog:
 def choices(self,roles):return [ModelSelection('p','m')]
 def validate(self,selection,roles):pass
class SnapshotServiceTests(unittest.TestCase):
 def test_defaults_gate_and_history_read_only(self):
  with tempfile.TemporaryDirectory() as tmp:
   store=TaskSettingsStore(Path(tmp)/'settings.db');store.seed_defaults({'developer':RoleSettings('p','m','medium')})
   store.capture_task('board','t_a','direct_root')
   service=SnapshotService(Reports(),store,Catalog(),'board',None,None)
   with self.assertRaises(ConfigurationError):service.save_default('developer',ModelSelection('p','m'),1,'high')
   store.set_activation(True,0)
   service.save_default('developer',ModelSelection('p','m'),1,'high')
   report=service.report()
   self.assertIsNone(report['parents'][0]['attempts'][0]['effort'])
   self.assertEqual(report['parents'][0]['requested_settings']['roles']['developer']['effort'],'medium')
   with self.assertRaises(ConfigurationError):service.save_override('t_a',None,2)
   with self.assertRaises(ConfigurationError):service.save_profile('developer',None,None,2)

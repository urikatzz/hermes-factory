import tempfile,unittest
from pathlib import Path
from factory_dashboard.task_settings import RoleSettings
from factory_dashboard.task_settings_store import TaskSettingsStore
from factory_dashboard.factory_creation import FactoryCreation
from factory_dashboard.factory_model_resolver import board_key
from factory_dashboard.model_policy import ConfigurationError

class CreationTests(unittest.TestCase):
 def test_ticket_root_and_late_stage_share_snapshot(self):
  with tempfile.TemporaryDirectory() as tmp:
   store=TaskSettingsStore(Path(tmp)/'settings.db');store.seed_defaults({'developer':RoleSettings('p','old','medium')})
   board=Path(tmp)/'board.db';key=board_key(board,'default');creation=FactoryCreation(store,board,'default')
   creation.prepare_creation({'id':'t_a','title':'TICKET: do work','created_by':'factory-ticket'},board,'default')
   store.save_default('developer',RoleSettings('p','new','high'),store.read_defaults().revision)
   creation.prepare_creation({'id':'t_b','title':'FACTORY: work','idempotency_key':'intake-t_a'},board,'default')
   creation.prepare_creation({'id':'t_c','title':'FIX (t_b)'},board,'default')
   self.assertEqual(store.snapshot_for_task(key,'t_c').roles['developer'].model,'old')
   with self.assertRaises(ConfigurationError):creation.prepare_creation({'id':'t_d','title':'FACTORY: broken','idempotency_key':'intake-t_missing'},board,'default')
   creation.prepare_creation({'id':'t_e','title':'ordinary'},board,'default')
   self.assertIsNone(store.snapshot_for_task(key,'t_e'))

 def test_rolled_back_submission_creation_can_retry_with_same_snapshot(self):
  with tempfile.TemporaryDirectory() as tmp:
   store=TaskSettingsStore(Path(tmp)/'settings.db');store.seed_defaults({'developer':RoleSettings('p','old','medium')})
   board=Path(tmp)/'board.db';key=board_key(board,'default');creation=FactoryCreation(store,board,'default')
   identity='00000000-0000-0000-0000-000000000001'
   record=store.prepare_submission(key,{'submission_id':identity,'defaults_revision':1})
   creation.prepare_creation({'id':'t_a','idempotency_key':'factory-submit-'+identity},board,'default')
   # The outer board transaction rolled back: the first reserved ID is inert.
   creation.prepare_creation({'id':'t_b','idempotency_key':'factory-submit-'+identity},board,'default')
   store.bind_task(key,'t_b',record['snapshot_id'],'ticket',identity)
   self.assertEqual(store.snapshot_for_task(key,'t_b').id,record['snapshot_id'])
   self.assertEqual(store.read_submission(key,identity)['ticket_id'],'t_b')

import tempfile
import unittest
from pathlib import Path
from factory_dashboard.task_settings import RoleSettings
from factory_dashboard.task_settings_store import TaskSettingsStore
from factory_dashboard.model_policy import ConfigurationError
from factory_dashboard.policy_store import RevisionConflict

class TaskSettingsTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.store=TaskSettingsStore(Path(self.tmp.name)/'settings.db')
        self.store.seed_defaults({'developer':RoleSettings('p','m','medium'),'fixer':RoleSettings('p','f','high')})
        self.payload={'submission_id':'00000000-0000-4000-8000-000000000001','defaults_revision':self.store.read_defaults().revision,'title':'Work','project':'repo','type':'feature','prompt':'do work','acceptance':''}

    def test_snapshot_survives_default_change(self):
        a=self.store.prepare_submission('board',self.payload)
        self.store.save_default('developer',RoleSettings('p','new','high'),self.store.read_defaults().revision)
        snap=self.store.get_snapshot(a['snapshot_id'])
        self.assertEqual(snap.roles['developer'].effort,'medium')
        with self.assertRaises(TypeError):snap.roles['developer']=RoleSettings('x','x','high')
        with self.assertRaises(RevisionConflict):self.store.prepare_submission('board',dict(self.payload,submission_id='00000000-0000-4000-8000-000000000002'))

    def test_submission_idempotency_payload_conflict_and_board_isolation(self):
        a=self.store.prepare_submission('a',self.payload)
        self.assertEqual(a,self.store.prepare_submission('a',self.payload))
        with self.assertRaises(ConfigurationError):self.store.prepare_submission('a',dict(self.payload,prompt='changed'))
        b=self.store.prepare_submission('b',self.payload)
        self.assertNotEqual(a['snapshot_id'],b['snapshot_id'])
        self.store.bind_task('a','t_a',a['snapshot_id'],'ticket')
        self.assertIsNone(self.store.snapshot_for_task('b','t_a'))
        self.assertEqual(self.store.snapshot_for_task('a','t_a').id,a['snapshot_id'])
        with self.assertRaises(ConfigurationError):self.store.bind_task('a','t_a',b['snapshot_id'],'ticket')

    def test_activation_starts_disabled(self):
        self.assertFalse(self.store.read_activation()['enabled'])

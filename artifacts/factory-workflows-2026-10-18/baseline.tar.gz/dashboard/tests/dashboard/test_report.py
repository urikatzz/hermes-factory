from dataclasses import replace
import unittest
from factory_dashboard.models import Snapshot
try:
    from factory_dashboard.report import ReportBuilder
except ImportError:
    ReportBuilder=None


def task(id, title, status='done', **kw):
    return dict(id=id,title=title,status=status,assignee='developer',created_at=10,**kw)


def run(id, task_id='t_b', profile='developer', session='s1', **kw):
    return dict(id=id,task_id=task_id,profile=profile,status='done',metadata={'worker_session_id':session} if session else {},**kw)


def session(id='s1', profile='developer', **kw):
    return dict(id=id,profile=profile,database='/home/'+profile+'/state.db',input_tokens=100,output_tokens=10,cache_read_tokens=80,reasoning_tokens=3,**kw)


def snapshot(tasks=(),runs=(),sessions=(),events=(),evidence=(),published=None):
    return Snapshot('default','2026-10-16T00:00:00+00:00',(),tuple(tasks),tuple(runs),tuple(events),tuple(sessions),published or {},tuple(evidence),())


class ReportTests(unittest.TestCase):
    def test_legacy_prefix_links_fixer_to_factory_parent(self):
        result=self.build(tasks=[dict(task('t_abc','Legacy factory root'),assignee='factory-orchestrator',skills='["software-factory"]'),task('t_def','[t_abc] FIX 1 — security')],runs=[run(1,task_id='t_def',profile='fixer',session=None)])
        self.assertEqual(result['parents'][0]['stages'][0]['stage']['label'],'FIX')
        self.assertEqual(result['parents'][0]['stages'][0]['attempts'][0]['profile'],'fixer')
        self.assertEqual(result['unlinked_tasks'],[])

    def test_recorded_effort_is_read_from_session_only(self):
        data=self.build(tasks=[task('t_b','FACTORY: Work')],runs=[run(1)],sessions=[session(model_config={'reasoning_config':{'enabled':True,'effort':'medium'}})])
        self.assertEqual(data['parents'][0]['attempts'][0]['effort'],'medium')
        data=self.build(tasks=[task('t_b','FACTORY: Work')],runs=[run(1)],sessions=[session()])
        self.assertIsNone(data['parents'][0]['attempts'][0]['effort'])

    def setUp(self):self.assertIsNotNone(ReportBuilder,'Report aggregation is missing')
    def build(self,**kw):return ReportBuilder().build(snapshot(**kw))

    def test_parent_linking_keeps_done_fail_and_orphans_visible(self):
        r=self.build(tasks=[task('t_a','FACTORY: build'),task('t_b','VERIFY c1 (t_a)'),task('t_c','VERIFY (t_dead)'),task('t_d','not FACTORY: other')],runs=[run(1,summary='VERDICT=FAIL STAGE=VERIFY CYCLE=1')])
        self.assertEqual(len(r['parents']),1)
        child=r['parents'][0]['stages'][0]
        self.assertEqual(child['status'],'done');self.assertEqual(child['verdict'],'FAIL')
        self.assertEqual([t['id'] for t in r['unlinked_tasks']],['t_c','t_d'])
        self.assertFalse(r['parents'][0]['verified_delivery'])

    def test_worker_session_link_is_explicit_and_profile_scoped(self):
        r=self.build(tasks=[task('t_b','plain',session_id='origin')],runs=[run(1,session=None),run(2),run(3,profile='verifier')],sessions=[session(actual_cost_usd=1),session(profile='verifier',actual_cost_usd=2)])
        self.assertEqual(r['coverage']['linked_attempts'],2)
        self.assertEqual(r['coverage']['missing_attempts'],1)
        self.assertEqual(r['summary']['usage']['actual_usd'],3)
        self.assertEqual(r['summary']['usage']['input_tokens'],200)

    def test_shared_session_counts_once_and_is_not_allocated_to_parents(self):
        r=self.build(tasks=[task('t_a','FACTORY: A'),task('t_c','FACTORY: C'),task('t_b','IMPLEMENT (t_a)'),task('t_d','IMPLEMENT (t_c)')],runs=[run(1),run(2,task_id='t_d')],sessions=[session(actual_cost_usd=4)])
        self.assertEqual(r['summary']['usage']['actual_usd'],4)
        self.assertEqual(r['summary']['usage']['input_tokens'],100)
        self.assertEqual(len(r['shared_sessions']),1)
        self.assertIsNone(r['parents'][0]['usage']['actual_usd'])
        self.assertEqual(r['parents'][0]['usage']['shared_sessions'],1)

    def test_included_is_not_zero_actual_or_zero_estimated_spend(self):
        r=self.build(tasks=[task('t_b','pilot')],runs=[run(1)],sessions=[session(cost_status='included',estimated_cost_usd=0,actual_cost_usd=None)])
        u=r['summary']['usage'];self.assertEqual(u['included_sessions'],1)
        self.assertIsNone(u['actual_usd']);self.assertIsNone(u['estimated_usd'])
        self.assertEqual(u['reasoning_tokens'],3)
        self.assertNotIn('total_tokens',u)

    def test_cost_and_token_missing_values_remain_partial(self):
        r=self.build(runs=[run(1),run(2,session='s2'),run(3,session='absent')],sessions=[session(actual_cost_usd=1.5),dict(id='s2',profile='developer',database='/home/developer/state.db',estimated_cost_usd=.4)])
        u=r['summary']['usage']
        self.assertEqual(u['actual_usd'],1.5);self.assertEqual(u['estimated_usd'],.4)
        self.assertEqual(u['actual_known_sessions'],1);self.assertEqual(u['estimated_known_sessions'],1)
        self.assertEqual(u['input_tokens_known_sessions'],1);self.assertEqual(r['coverage']['missing_attempts'],1)

    def test_metrics_exclude_archived_and_invalid_intervals_and_separate_fixes(self):
        tasks=[task('t_a','FACTORY: A',completed_at=20),task('t_c','FACTORY: C',completed_at=40),task('t_e','FACTORY: E','archived'),task('t_f','FACTORY: F','running'),task('t_b','IMPLEMENT (t_a)'),task('t_d','FIX c2 (t_a)')]
        r=self.build(tasks=tasks,runs=[run(1),run(2),run(3),run(4,task_id='t_d')])
        self.assertAlmostEqual(r['summary']['card_completion_rate'],2/3)
        self.assertEqual(r['summary']['median_cycle_seconds'],20)
        self.assertEqual(r['parents'][0]['execution_retries'],2)
        self.assertEqual(r['parents'][0]['fix_stages'],1)
        bad=self.build(tasks=[task('t_a','FACTORY: A',completed_at=5)])
        self.assertIsNone(bad['summary']['median_cycle_seconds']);self.assertTrue(bad['warnings'])

    def test_empty_board_has_no_fabricated_zero_spend_or_duration(self):
        r=self.build()
        self.assertIsNone(r['summary']['card_completion_rate'])
        self.assertIsNone(r['summary']['median_cycle_seconds'])
        self.assertIsNone(r['summary']['usage']['actual_usd'])

    def test_timeline_is_stable_and_missing_timestamp_is_unknown(self):
        r=self.build(tasks=[task('t_b','plain')],events=[dict(id=2,task_id='t_b',run_id=1,kind='second',created_at=20,payload={}),dict(id=1,task_id='t_b',run_id=1,kind='first',created_at=20,payload={}),dict(id=3,task_id='t_b',run_id=1,kind='unknown',created_at=None,payload={})])
        timeline=r['unlinked_tasks'][0]['timeline']
        self.assertEqual([e['kind'] for e in timeline],['first','second','unknown'])
        self.assertIsNone(timeline[-1]['timestamp'])

    def test_artifacts_recorded_not_inferred_and_failures_not_double_counted(self):
        r=self.build(tasks=[task('t_a','FACTORY: A',branch_name='feature/a'),task('t_b','VERIFY c1 (t_a)')],runs=[run(1,summary='VERDICT=FAIL',outcome='failed',metadata_unused='ignored')],published={'t_a':{'url':'https://github.com/example/repo/pull/1'}})
        p=r['parents'][0]
        self.assertEqual(p['delivery']['url'],'https://github.com/example/repo/pull/1')
        self.assertFalse(p['verified_delivery'])
        self.assertEqual(r['summary']['failed_attempts'],1)

    def test_sandbox_identity_mismatch_does_not_enter_timeline(self):
        r=self.build(tasks=[task('t_b','plain')],runs=[run(1)],evidence=[{'identity':{'board':'other','task_id':'t_b','run_id':'1'},'events':[{'phase':'bad','timestamp':'2026-10-16T00:00:00Z'}],'result':{}}])
        self.assertEqual(r['unlinked_tasks'][0]['timeline'],[])

    def test_invalid_and_ambiguous_session_links_are_missing(self):
        r=self.build(runs=[run(1)],sessions=[session(),session()])
        self.assertEqual(r['coverage']['linked_attempts'],0)
        self.assertTrue(r['warnings'])

    def test_closed_attempt_without_end_time_has_unknown_duration(self):
        r=self.build(tasks=[task('t_b','plain')],runs=[run(1,started_at=10,ended_at=None)])
        self.assertIsNone(r['unlinked_tasks'][0]['attempts'][0]['duration_seconds'])
        self.assertIsNone(r['unlinked_tasks'][0]['duration_seconds'])

    def test_running_attempt_uses_snapshot_time_for_elapsed_duration(self):
        item=run(1,started_at=1792108790,ended_at=None)
        item['status']='running'
        r=self.build(tasks=[task('t_b','plain','running')],runs=[item])
        self.assertEqual(r['unlinked_tasks'][0]['attempts'][0]['duration_seconds'],10)

    def test_recovered_task_does_not_show_historical_failure_as_current_blocker(self):
        r=self.build(tasks=[task('t_b','plain',last_failure_error='old crash')])
        self.assertIsNone(r['unlinked_tasks'][0]['block_reason'])

    def test_profile_aliases_of_same_database_share_one_session(self):
        first=session(actual_cost_usd=5)
        alias=session(profile='Developer',actual_cost_usd=5)
        first['database_identity']=alias['database_identity']='device:inode'
        r=self.build(tasks=[task('t_b','plain')],runs=[run(1),run(2,profile='Developer')],sessions=[first,alias])
        self.assertEqual(r['summary']['usage']['actual_usd'],5)
        self.assertEqual(r['coverage']['unique_sessions'],1)
        self.assertEqual(r['coverage']['shared_sessions'],1)

    def test_unrecognized_stage_and_large_cycle_sort_without_type_error(self):
        r=self.build(tasks=[task('t_a','FACTORY: A'),task('t_b','VERIFY c999 (t_a)'),task('t_c','CUSTOM (t_a)')])
        self.assertEqual([s['id'] for s in r['parents'][0]['stages']],['t_b','t_c'])

    def test_parent_usage_exposes_missing_attempt_coverage(self):
        r=self.build(tasks=[task('t_a','FACTORY: A'),task('t_b','IMPLEMENT (t_a)')],runs=[run(1),run(2,session=None)],sessions=[session()])
        u=r['parents'][0]['usage']
        self.assertEqual(u.get('attempts'),2)
        self.assertEqual(u.get('linked_attempts'),1)
        self.assertEqual(u.get('missing_attempts'),1)

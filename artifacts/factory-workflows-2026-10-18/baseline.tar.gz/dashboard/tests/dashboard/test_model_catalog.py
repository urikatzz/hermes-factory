import unittest
from factory_dashboard.model_catalog import ModelCatalog
from factory_dashboard.model_policy import ModelSelection, ConfigurationError


class CatalogTests(unittest.TestCase):
    def setUp(self):
        self.data = {'profiles': {
            'planner': {'default': {'provider':'p','model':'a'}, 'models':[{'provider':'p','model':'a'},{'provider':'p','model':'shared'}]},
            'builder': {'default': {'provider':'q','model':'b'}, 'models':[{'provider':'q','model':'b'},{'provider':'p','model':'shared'}]}}}
        self.catalog = ModelCatalog(self.data)

    def test_intersection_validates_every_profile(self):
        self.assertEqual(self.catalog.choices(('planner','builder')), [ModelSelection('p','shared')])
        with self.assertRaises(ConfigurationError): self.catalog.validate(ModelSelection('p','a'),('planner','builder'))
        self.assertEqual(self.catalog.defaults()['builder'], ModelSelection('q','b'))

    def test_unknown_profile_or_missing_default_is_error(self):
        with self.assertRaises(ConfigurationError): self.catalog.choices(('missing',))
        with self.assertRaises(ConfigurationError): ModelCatalog({'profiles':{'planner':{'models':[]}}})

    def test_known_incompatible_model_excluded(self):
        self.data['profiles']['planner']['models'][1]['compatible'] = False
        self.assertEqual(ModelCatalog(self.data).choices(('planner','builder')), [])

    def test_export_reads_each_profile_and_only_whitelisted_fields(self):
        from factory_dashboard.catalog_export import export_catalog
        configs={'planner':{'model':{'provider':'p','default':'a','api_key':'SECRET'},'secret':'SECRET'},
                 'builder':{'model':{'provider':'q','default':'b'}}}
        exported=export_catalog(('planner','builder'),configs.__getitem__)
        self.assertEqual(exported['profiles']['planner']['default'],{'provider':'p','model':'a'})
        self.assertEqual(exported['profiles']['builder']['default'],{'provider':'q','model':'b'})
        self.assertNotIn('SECRET',str(exported))
        with self.assertRaises(ConfigurationError): export_catalog(('planner',),lambda role:{})

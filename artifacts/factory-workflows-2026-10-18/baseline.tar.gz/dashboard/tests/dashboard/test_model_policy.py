import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from factory_dashboard.model_policy import ModelSelection, ModelPolicy, ConfigurationError
from factory_dashboard.policy_store import PolicyStore, RevisionConflict


class PolicyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'policy' / 'models.db'
        self.store = PolicyStore(self.path)
        self.a = ModelSelection('provider-a', 'planner-model')
        self.b = ModelSelection('provider-b', 'builder-model')
        self.x = ModelSelection('provider-x', 'task-model')
        self.store.set_default('planner', self.a, 0)
        self.store.set_default('builder', self.b, 1)

    def resolve(self, role, board='one'):
        return ModelPolicy.resolve(self.store.read(), board, 't_abc', role)

    def test_override_all_roles_reset_and_board_isolation(self):
        self.assertEqual(self.resolve('planner').selection, self.a)
        self.store.set_override('one', 't_abc', self.x, 2)
        for role in ('planner', 'builder'):
            result = self.resolve(role)
            self.assertEqual(result.selection, self.x)
            self.assertEqual(result.source, 'task_override')
            self.assertEqual(result.revision, 3)
        self.assertEqual(self.resolve('builder', 'two').selection, self.b)
        self.store.set_override('one', 't_abc', None, 3)
        self.assertEqual(self.resolve('builder').selection, self.b)
        self.assertEqual(self.resolve('planner').source, 'agent_default')

    def test_snapshot_is_immutable_and_captured_before_edit(self):
        old = self.store.read()
        with self.assertRaises(TypeError): old.defaults['planner'] = self.x
        self.store.set_default('planner', self.x, 2)
        self.assertEqual(ModelPolicy.resolve(old, 'one', 't_abc', 'planner').selection, self.a)
        self.assertEqual(self.resolve('planner').selection, self.x)

    def test_missing_default_rejected(self):
        with self.assertRaises(ConfigurationError): self.resolve('unknown')

    def test_reopen_and_conflict_preserves_value(self):
        with self.assertRaises(RevisionConflict): self.store.set_default('planner', self.x, 0)
        self.assertEqual(PolicyStore(self.path).read().defaults['planner'], self.a)
        self.assertEqual(self.path.stat().st_mode & 0o777, 0o600)

    def test_concurrent_writers_only_one_wins(self):
        def save(role):
            try:
                PolicyStore(self.path).set_default(role, self.x, 2)
                return 'saved'
            except RevisionConflict: return 'conflict'
        with ThreadPoolExecutor(2) as pool:
            self.assertCountEqual(pool.map(save, ('planner', 'builder')), ['saved', 'conflict'])
        self.assertEqual(self.store.read().revision, 3)

    def test_invalid_selection_and_failed_write_keep_revision(self):
        for args in (('', 'm'), ('p', ''), ('p', '-m'), ('p', 'a\nsecret')):
            with self.assertRaises(ConfigurationError): ModelSelection(*args)
        with self.assertRaises(ConfigurationError): self.store.set_default('', self.x, 2)
        self.assertEqual(self.store.read().revision, 2)

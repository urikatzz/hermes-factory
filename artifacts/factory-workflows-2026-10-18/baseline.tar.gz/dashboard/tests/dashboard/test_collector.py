import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from fixtures import board, session_db, insert
try:
    from factory_dashboard.collector import SnapshotCollector, SourceReadError
    from factory_dashboard.models import SourcePaths
except ImportError:
    SnapshotCollector = None


class CollectorTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(SnapshotCollector, 'Read-only snapshot collector is missing')
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.conn = board(self.root)
        self.addCleanup(self.conn.close)

    def collect(self, **kwargs):
        return SnapshotCollector(SourcePaths(self.root/'board.db','default',self.root/'home',kwargs.get('published'),kwargs.get('evidence'))).collect()

    def test_missing_board_is_not_created(self):
        paths = SourcePaths(self.root/'absent.db','default',self.root/'home',None,None)
        with self.assertRaises(SourceReadError): SnapshotCollector(paths).collect()
        self.assertFalse(paths.board_db.exists())

    def test_unsupported_schema_fails_clearly(self):
        self.conn.execute('ALTER TABLE task_runs RENAME TO removed_runs')
        self.conn.commit()
        with self.assertRaises(SourceReadError): self.collect()

    def test_reads_committed_wal_without_reading_private_columns(self):
        self.conn.execute('PRAGMA journal_mode=WAL')
        insert(self.conn,'tasks',id='t_a',title='FACTORY: work',status='todo',created_at=1)
        insert(self.conn,'task_runs',id=1,task_id='t_a',profile='developer',metadata={'worker_session_id':'s1'})
        c = session_db(self.root);self.addCleanup(c.close)
        c.execute('ALTER TABLE sessions ADD COLUMN system_prompt TEXT')
        insert(c,'sessions',id='s1',input_tokens=123,system_prompt='PRIVATE PROMPT')
        before = self.conn.total_changes
        snapshot = self.collect()
        self.assertEqual(snapshot.tasks[0]['title'],'FACTORY: work')
        self.assertEqual(snapshot.sessions[0]['input_tokens'],123)
        self.assertNotIn('PRIVATE PROMPT',str(snapshot))
        self.assertEqual(self.conn.total_changes,before)

    def test_old_optional_usage_schema_is_partial_not_fabricated(self):
        insert(self.conn,'task_runs',id=1,task_id='t_a',profile='default',metadata={'worker_session_id':'s1'})
        c=session_db(self.root,'default',{'id':'TEXT','model':'TEXT'});self.addCleanup(c.close)
        insert(c,'sessions',id='s1',model='model')
        s=self.collect()
        self.assertEqual(s.sessions[0]['model'],'model')
        self.assertIsNone(s.sessions[0]['input_tokens'])
        self.assertTrue(s.warnings)

    def test_malformed_records_and_missing_optional_sources_are_visible(self):
        insert(self.conn,'task_runs',id=1,task_id='t_a',profile='developer',metadata='{bad')
        insert(self.conn,'task_events',id=1,task_id='t_a',kind='blocked',payload='[]')
        s=self.collect(published=self.root/'missing.json')
        self.assertEqual(s.runs[0]['metadata'],{})
        self.assertGreaterEqual(len(s.warnings),3)

    def test_profile_traversal_and_symlink_are_not_read(self):
        for n,profile in enumerate(('../escape','developer'),1):
            insert(self.conn,'task_runs',id=n,task_id='t_a',profile=profile,metadata={'worker_session_id':'s1'})
        external=self.root/'external.db'
        c=sqlite3.connect(external);c.close()
        target=self.root/'home/profiles/developer';target.mkdir(parents=True)
        (target/'state.db').symlink_to(external)
        s=self.collect()
        self.assertEqual(s.sessions,())
        self.assertGreaterEqual(len(s.warnings),2)

    def test_evidence_identity_and_symlinks_are_validated(self):
        insert(self.conn,'tasks',id='t_a',title='FACTORY: x',status='done',created_at=1)
        insert(self.conn,'task_runs',id=1,task_id='t_a',profile='developer',metadata={})
        evidence=self.root/'evidence';evidence.mkdir()
        for name,board_id,run in [('good','default','1'),('other','different','1'),('wrong','default','9')]:
            d=evidence/name;d.mkdir()
            (d/'attempt.json').write_text(json.dumps({'identity':{'board':board_id,'task_id':'t_a','run_id':run},'events':[],'result':{'cleanup_outcome':'removed','result_path':'/do/not/read'}}))
        (evidence/'linked').symlink_to(evidence/'good',target_is_directory=True)
        s=self.collect(evidence=evidence)
        self.assertEqual(len(s.evidence),1)
        self.assertGreaterEqual(len(s.warnings),3)

    def test_required_lock_errors_and_optional_lock_warns(self):
        self.conn.execute('BEGIN EXCLUSIVE')
        with self.assertRaises(SourceReadError): self.collect()
        self.conn.rollback()
        insert(self.conn,'task_runs',id=1,task_id='t_a',profile='developer',metadata={'worker_session_id':'s1'})
        c=session_db(self.root);self.addCleanup(c.close)
        c.execute('BEGIN EXCLUSIVE')
        s=self.collect()
        self.assertTrue(s.warnings)
        self.assertEqual(s.sessions,())

    def test_nonfinite_json_is_invalid_instead_of_poisoning_report(self):
        insert(self.conn,'task_runs',id=1,task_id='t_a',profile='developer',metadata='{"score": NaN}')
        s=self.collect()
        self.assertEqual(s.runs[0]['metadata'],{})
        self.assertTrue(s.warnings)

    def test_profile_database_identity_is_physical_not_path_spelling(self):
        import os
        insert(self.conn,'task_runs',id=1,task_id='t_a',profile='developer',metadata={'worker_session_id':'s1'})
        insert(self.conn,'task_runs',id=2,task_id='t_a',profile='alias',metadata={'worker_session_id':'s1'})
        c=session_db(self.root);self.addCleanup(c.close)
        insert(c,'sessions',id='s1',input_tokens=1)
        alias=self.root/'home/profiles/alias';alias.mkdir(parents=True)
        os.link(self.root/'home/profiles/developer/state.db',alias/'state.db')
        s=self.collect()
        self.assertEqual(len(s.sessions),2)
        self.assertIn('database_identity',s.sessions[0])
        self.assertEqual(s.sessions[0]['database_identity'],s.sessions[1]['database_identity'])

    def test_optional_nonfinite_evidence_is_warned_and_ignored(self):
        insert(self.conn,'task_runs',id=1,task_id='t_a',profile='developer',metadata={})
        evidence=self.root/'evidence';evidence.mkdir()
        for i,constant in enumerate(('NaN','Infinity','1e400')):
            d=evidence/str(i);d.mkdir()
            (d/'attempt.json').write_text('{"identity":{"board":"default","task_id":"t_a","run_id":"1"},"events":[{"phase":"cleanup","message":'+constant+'}]}')
        s=self.collect(evidence=evidence)
        self.assertEqual(s.evidence,())
        self.assertGreaterEqual(len(s.warnings),3)

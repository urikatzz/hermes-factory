import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from fixtures import board, insert, session_db
from test_renderer import PageParser

SCRIPT=Path(__file__).resolve().parents[2]/'scripts/generate_factory_dashboard.py'


class CliTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue(SCRIPT.is_file(),'Dashboard CLI is missing')
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.conn=board(self.root);self.addCleanup(self.conn.close)

    def run_cli(self,*extra):
        return subprocess.run([sys.executable,str(SCRIPT),'--board-db',str(self.root/'board.db'),'--board-id','default','--hermes-home',str(self.root/'home'),'--output',str(self.root/'report.html'),*map(str,extra)],capture_output=True,text=True,timeout=10)

    def test_complete_generation_preserves_failed_verdict_and_unknown_dollars(self):
        insert(self.conn,'tasks',id='t_a',title='FACTORY: sample',status='done',created_at=10)
        insert(self.conn,'tasks',id='t_b',title='VERIFY c1 (t_a)',status='done',created_at=10)
        insert(self.conn,'task_runs',id=1,task_id='t_b',profile='developer',status='done',summary='VERDICT=FAIL',metadata={'worker_session_id':'s1'})
        c=session_db(self.root);self.addCleanup(c.close)
        insert(c,'sessions',id='s1',cost_status='included',estimated_cost_usd=0,input_tokens=10)
        result=self.run_cli();self.assertEqual(result.returncode,0,result.stderr)
        parser=PageParser();parser.feed((self.root/'report.html').read_text())
        data=json.loads(parser.data)
        self.assertEqual(data['parents'][0]['stages'][0]['verdict'],'FAIL')
        self.assertIsNone(data['summary']['usage']['actual_usd'])
        self.assertEqual(data['summary']['usage']['included_sessions'],1)

    def test_optional_source_warning_does_not_hide_report(self):
        result=self.run_cli('--published-state',self.root/'absent.json')
        self.assertEqual(result.returncode,0,result.stderr)
        parser=PageParser();parser.feed((self.root/'report.html').read_text())
        self.assertTrue(json.loads(parser.data)['warnings'])

    def test_missing_board_preserves_previous_output(self):
        output=self.root/'report.html';output.write_text('previous')
        result=self.run_cli('--board-db',self.root/'absent.db')
        self.assertEqual(result.returncode,2)
        self.assertIn('Cannot read',result.stderr)
        self.assertEqual(output.read_text(),'previous')

    def test_output_cannot_replace_input(self):
        result=self.run_cli('--output',self.root/'board.db')
        self.assertEqual(result.returncode,2)
        self.assertEqual(self.conn.execute('SELECT COUNT(*) FROM tasks').fetchone()[0],0)

    def test_invalid_arguments_are_concise(self):
        result=self.run_cli('--board-id','../invalid')
        self.assertEqual(result.returncode,2)
        self.assertNotIn('Traceback',result.stderr)

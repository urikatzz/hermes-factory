import unittest
from factory_dashboard.task_identity import root_id, is_root
from factory_dashboard.model_policy import ConfigurationError

class IdentityTests(unittest.TestCase):
    def test_root_and_both_stage_conventions(self):
        root={'id':'t_abc','title':'Old root','assignee':'factory-orchestrator','skills':'["software-factory"]'}
        lookup=lambda key:root if key=='t_abc' else None
        self.assertTrue(is_root(root))
        self.assertEqual(root_id({'title':'FIX (t_abc)'},lookup),'t_abc')
        self.assertEqual(root_id({'title':'[t_abc] FIX'},lookup),'t_abc')
        self.assertIsNone(root_id({'title':'Ordinary'},lookup))
        with self.assertRaises(ConfigurationError):root_id({'title':'[t_abc] FIX (t_def)'},lookup)

"""Synchronous creation observers before a task becomes eligible to dispatch."""
import inspect


def existing_task(conn, key):
    if not key:
        return None
    row = conn.execute("SELECT id FROM tasks WHERE idempotency_key=? AND (status != 'archived' OR ? LIKE 'factory-submit-%' OR ? LIKE 'intake-%') ORDER BY created_at DESC LIMIT 1", (key, key, key)).fetchone()
    return row['id'] if row else None


def prepare_creation(conn, fields):
    from hermes_cli.plugins import has_hook, iter_hook_callbacks

    existing = existing_task(conn, fields['idempotency_key'])
    if existing:
        return existing
    if not has_hook('before_kanban_task_create'):
        return None
    task = {key: fields.get(key) for key in ('title', 'body', 'assignee', 'created_by', 'idempotency_key',
            'model_override', 'provider_override', 'reasoning_effort', 'creator_task_id')}
    task.update(id=fields['task_id'], skills=fields['skills_list'], status=fields['task_status'])
    path = next(row[2] for row in conn.execute('PRAGMA database_list') if row[1] == 'main')
    payload = dict(task=task, board_path=path, board=fields.get('board'))
    for callback in iter_hook_callbacks('before_kanban_task_create'):
        signature = inspect.signature(callback)
        kwargs = payload if any(p.kind == p.VAR_KEYWORD for p in signature.parameters.values()) else {
            key: value for key, value in payload.items() if key in signature.parameters}
        result = callback(**kwargs)
        if inspect.isawaitable(result):
            if inspect.iscoroutine(result):
                result.close()
            raise ValueError('Task creation hooks must be synchronous')
    return None

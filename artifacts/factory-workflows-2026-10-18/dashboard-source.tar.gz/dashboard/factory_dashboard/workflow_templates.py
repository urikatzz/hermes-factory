"""Immutable template revisions with optimistic edits and replaceable type defaults."""
from dataclasses import asdict
import json
import uuid
from .model_policy import ConfigurationError
from .policy_store import RevisionConflict
from .task_settings_store import encode
from .workflow_types import WorkflowDefinition, TASK_TYPES


def _preset(kind):
    prepare, implement, reviewers = {
        'feature': ('architect', 'developer', ('claude-reviewer', 'security-reviewer', 'ux-reviewer', 'ui-reviewer')),
        'bug': ('fixer', 'fixer', ('claude-reviewer', 'security-reviewer')),
        'chore': ('developer', 'developer', ('claude-reviewer',)),
    }[kind]
    def stage(key, profile, instructions='', stage_kind=None):
        return dict(key=key, kind=stage_kind or key, profile=profile, instructions=instructions)
    instructions = {'feature': 'Design the change and observable acceptance criteria.', 'bug': 'Diagnose the root cause and plan a regression test that fails before the repair and passes afterward.', 'chore': 'Define the scope and demonstrate no unintended behavior change.'}
    return dict(template_id=str(uuid.uuid4()), revision=1, name={'feature':'Feature', 'bug':'Bug fix', 'chore':'Chore'}[kind], description='', task_type=kind,
                prepare=stage('prepare', prepare, instructions[kind]), implement=stage('implement', implement),
                reviewers=[stage(p, p, stage_kind='review') for p in reviewers], verify=stage('verify', 'verifier'), repair=stage('repair', 'fixer'), max_repairs=3)


class WorkflowTemplates:
    def __init__(self, store):
        self._store = store

    def initialize(self):
        with self._store._connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            conn.execute('CREATE TABLE IF NOT EXISTS factory_workflow_templates(id TEXT PRIMARY KEY, revision INTEGER NOT NULL, archived INTEGER NOT NULL DEFAULT 0)')
            conn.execute('CREATE TABLE IF NOT EXISTS factory_workflow_revisions(template_id TEXT NOT NULL, revision INTEGER NOT NULL, document TEXT NOT NULL, PRIMARY KEY(template_id,revision))')
            conn.execute('CREATE TABLE IF NOT EXISTS factory_workflow_defaults(id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL, templates TEXT NOT NULL)')
            if not conn.execute('SELECT 1 FROM factory_workflow_defaults').fetchone():
                mapping = {}
                for kind in TASK_TYPES:
                    doc = _preset(kind)
                    self._insert(conn, doc)
                    mapping[kind] = doc['template_id']
                conn.execute('INSERT INTO factory_workflow_defaults VALUES(1,1,?)', (encode(mapping),))

    @staticmethod
    def _insert(conn, doc):
        conn.execute('INSERT INTO factory_workflow_templates VALUES(?,?,0)', (doc['template_id'], doc['revision']))
        conn.execute('INSERT INTO factory_workflow_revisions VALUES(?,?,?)', (doc['template_id'], doc['revision'], encode(doc)))

    def defaults(self, conn=None):
        if conn is None:
            with self._store._connect() as c:
                return self.defaults(c)
        row = conn.execute('SELECT revision,templates FROM factory_workflow_defaults WHERE id=1').fetchone()
        return dict(revision=row['revision'], templates=json.loads(row['templates']))

    def get(self, template_id, revision=None, *, conn=None, active=False):
        if conn is None:
            with self._store._connect() as c:
                return self.get(template_id, revision, conn=c, active=active)
        head = conn.execute('SELECT * FROM factory_workflow_templates WHERE id=?', (template_id,)).fetchone()
        if not head or (active and head['archived']):
            raise ConfigurationError('Workflow is missing or archived')
        row = conn.execute('SELECT document FROM factory_workflow_revisions WHERE template_id=? AND revision=?', (template_id, head['revision'] if revision is None else revision)).fetchone()
        if not row:
            raise ConfigurationError('Workflow revision is missing')
        return WorkflowDefinition.from_document(json.loads(row[0]))

    def list(self, include_archived=False):
        with self._store._connect() as conn:
            rows = conn.execute('SELECT * FROM factory_workflow_templates ORDER BY rowid').fetchall()
            return [dict(asdict(self.get(r['id'], conn=conn)), archived=bool(r['archived'])) for r in rows if include_archived or not r['archived']]

    def save(self, document, expected_revision):
        if type(expected_revision) is not int or expected_revision < 0:
            raise RevisionConflict('Invalid workflow revision')
        data = dict(document)
        template_id = data.get('template_id')
        if expected_revision == 0:
            if template_id or 'revision' in data:
                raise ConfigurationError('New template IDs and revisions are assigned by the server')
            template_id = str(uuid.uuid4())
        data.update(template_id=template_id, revision=expected_revision + 1)
        definition = WorkflowDefinition.from_document(data)
        with self._store._connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            if expected_revision == 0:
                self._insert(conn, asdict(definition))
            else:
                changed = conn.execute('UPDATE factory_workflow_templates SET revision=? WHERE id=? AND revision=? AND archived=0', (definition.revision, template_id, expected_revision))
                if changed.rowcount != 1:
                    raise RevisionConflict('Workflow changed or was archived; reload and review')
                conn.execute('INSERT INTO factory_workflow_revisions VALUES(?,?,?)', (template_id, definition.revision, encode(asdict(definition))))
        return definition

    def archive(self, template_id, expected_revision):
        self._set_archive(template_id, expected_revision, True)

    def restore(self, template_id, expected_revision):
        self._set_archive(template_id, expected_revision, False)

    def _set_archive(self, template_id, expected_revision, archived):
        with self._store._connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            if archived and template_id in self.defaults(conn)['templates'].values():
                raise ConfigurationError('Choose a replacement type default before archiving')
            changed = conn.execute('UPDATE factory_workflow_templates SET archived=? WHERE id=? AND revision=?', (int(archived), template_id, expected_revision))
            if changed.rowcount != 1:
                raise RevisionConflict('Workflow changed; reload and review')

    def set_type_default(self, task_type, template_id, expected_revision):
        if task_type not in TASK_TYPES:
            raise ConfigurationError('Unsupported task type')
        with self._store._connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            self.get(template_id, conn=conn, active=True)
            mapping = self.defaults(conn)
            if type(expected_revision) is not int or mapping['revision'] != expected_revision:
                raise RevisionConflict('Workflow defaults changed; reload and review')
            mapping['templates'][task_type] = template_id
            conn.execute('UPDATE factory_workflow_defaults SET revision=revision+1,templates=? WHERE id=1', (encode(mapping['templates']),))
            return self.defaults(conn)

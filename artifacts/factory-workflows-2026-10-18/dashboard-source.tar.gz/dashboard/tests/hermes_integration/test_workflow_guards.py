"""Managed identity is durable, and normal Hermes mutation APIs cannot bypass it."""
from pathlib import Path
import sys
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path.cwd()))


@pytest.fixture
def managed(tmp_path, monkeypatch, request):
    monkeypatch.setenv('HERMES_HOME', str(tmp_path / 'home'))
    monkeypatch.setattr(Path, 'home', lambda: tmp_path)
    from hermes_cli import kanban_db as kb, kanban_db_connect as kbc
    from hermes_cli.plugins import get_plugin_manager
    from factory_dashboard.task_settings_store import TaskSettingsStore
    from factory_dashboard.task_settings import RoleSettings
    from factory_dashboard.workflow_types import CAPABILITIES
    from factory_dashboard.workflow_templates import WorkflowTemplates
    from factory_dashboard.workflow_capture import WorkflowCapture
    from factory_dashboard.workflow_guards import WorkflowGuards
    from factory_dashboard.factory_creation import FactoryCreation
    kb.init_db(); conn = kbc.connect()
    path = Path(conn.execute('PRAGMA database_list').fetchone()[2])
    store = TaskSettingsStore(tmp_path / 'settings.db')
    store.seed_defaults({p: RoleSettings('p','m','medium') for p in CAPABILITIES})
    capture = WorkflowCapture(store, WorkflowTemplates(store)); capture.initialize(); capture.set_enabled(True)
    creation = FactoryCreation(store, path, 'default')
    guards = WorkflowGuards(store, path, 'default')
    manager = get_plugin_manager(); saved = {k:list(v) for k,v in manager._hooks.items()}
    manager._hooks['before_kanban_task_create'] = [creation.prepare_creation]
    manager._hooks['before_kanban_task_mutation'] = [guards.before_mutation]
    task_type = getattr(request,'param','feature')
    if isinstance(task_type,dict):
        from dataclasses import asdict
        settings=task_type;task_type=settings['type']
        templates=WorkflowTemplates(store)
        definition=capture.preview({'type':task_type})
        templates.save(dict(asdict(definition),max_repairs=settings['max_repairs']),definition.revision)
    root = kb.create_task(conn, title='FACTORY: managed', body=f'TYPE: {task_type}', assignee='factory-orchestrator')
    yield kb, conn, root, store, guards
    manager._hooks = saved; conn.close()


def test_bulk_and_force_cannot_bypass(managed):
    kb, conn, root, _, _ = managed
    assert kb.get_task(conn, root).status == 'blocked'
    for action in (lambda: kb.complete_task(conn, root, result='done', force=True),
                   lambda: kb.unblock_task(conn, root), lambda: kb.assign_task(conn, root, 'developer'),
                   lambda: kb.delete_task(conn, root)):
        with pytest.raises(ValueError, match='workflow'):
            action()
    assert kb.get_task(conn, root).status == 'blocked'


def test_managed_identity_survives_rename(managed):
    kb, conn, root, _, _ = managed
    kb.edit_task(conn, root, title='renamed')
    with pytest.raises(ValueError, match='workflow'):
        kb.complete_task(conn, root, result='done', force=True)


def test_native_reference_is_not_managed(managed):
    kb, conn, root, store, _ = managed
    native = kb.create_task(conn, title=f'Notes ({root})')
    assert kb.complete_task(conn, native, result='manual')
    from factory_dashboard.factory_model_resolver import board_key
    path = Path(conn.execute('PRAGMA database_list').fetchone()[2])
    assert store.snapshot_for_task(board_key(path,'default'),native) is None
    from factory_dashboard.frozen_resolver import FrozenFactoryResolver
    from dataclasses import asdict
    resolver=FrozenFactoryResolver(store,path,'default',lambda *args:None)
    assert resolver.resolve(asdict(kb.get_task(conn,native)),path,'default') is None


def test_unregistered_extra_stage_is_rejected(managed):
    kb, conn, root, _, _ = managed
    with pytest.raises(ValueError, match='workflow'):
        kb.create_task(conn, title='extra', assignee='fixer', creator_task_id=root)


def test_removed_dependency_still_cannot_claim(managed):
    kb, conn, root, _, _ = managed
    # Simulate an external database edit: ordinary claim must still enforce identity.
    conn.execute("UPDATE tasks SET status='ready' WHERE id=?", (root,)); conn.commit()
    with pytest.raises(ValueError, match='workflow'):
        kb.claim_task(conn, root)


def test_missing_consumer_fails_closed(managed):
    kb,conn,root,_,_=managed
    from hermes_cli.plugins import get_plugin_manager
    manager=get_plugin_manager();manager._hooks['before_kanban_task_mutation']=[]
    with pytest.raises(ValueError,match='policy'):
        kb.complete_task(conn,root,result='forced',force=True)


def test_scheduler_readiness_cannot_release_managed_root(managed):
    kb,conn,root,_,_=managed
    kb.recompute_ready(conn)
    assert kb.get_task(conn,root).status=='blocked'

"""Exercise graph transitions against real board writes, without launching a model."""
import json
import sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).parent))
from test_workflow_guards import managed


def controller(kb):
    from factory_dashboard.workflow_controller import WorkflowController
    from factory_dashboard.workflow_state import WorkflowState
    return WorkflowController(kb,WorkflowState(),Path('/private/tmp/factory-test-projects'))


def stages(conn, root):
    return [dict(r) for r in conn.execute('SELECT s.*,t.status FROM factory_workflow_stages s JOIN tasks t ON t.id=s.task_id WHERE root_id=? ORDER BY s.rowid',(root,))]


def finish(kb,conn,stage,tmp_path,*,fail=False,invalid=False,launched=True,blocked=False):
    task=kb.claim_task(conn,stage['task_id'])
    assert task is not None
    if launched:
        with kb.write_txn(conn):
            kb._append_event(conn,task.id,'spawned',{'pid':12345,'started_at':'test'},run_id=task.current_run_id)
    from hermes_cli.kanban_db_workspace import resolve_workspace
    workspace=resolve_workspace(task)
    with kb.write_txn(conn):
        conn.execute('UPDATE tasks SET workspace_path=? WHERE id=?',(str(workspace),task.id))
    kind=stage['kind'];name={'prepare':'PLAN','implement':'IMPLEMENT','repair':'FIX','review':stage['profile'].upper(),'verify':'VERIFY'}[kind]
    verdict={'prepare':'DONE','implement':'DONE','repair':'DONE','review':'NO_BLOCKING_FINDINGS','verify':'PASS'}[kind]
    if blocked:verdict='BLOCKED'
    if fail: verdict='FAIL' if kind=='verify' else 'CHANGES_REQUIRED'
    artifact=workspace / ('PLAN.md' if kind=='prepare' else 'report.md');artifact.write_text('AC1: expected behavior\nManifest include list: PLAN.md, .factory/include.txt')
    archive=workspace/'src-123456abcdef.tgz'
    if kind=='verify':archive.write_bytes(b'retained source fixture')
    meta=dict(contract='invalid' if invalid else 'factory-worker/v2',workflow_contract='factory-workflow/v1',root=stage['root_id'],stage_key=stage['stage_key'],stage=name,cycle=stage['cycle']+1,verdict=verdict,manifest_sha12='123456abcdef',ac_ids=['AC1'],ac_results={'AC1':'fail' if fail else 'pass'},findings=['F1|HIGH|AC1|file:1|fix this'] if fail else [],artifacts=[str(artifact)]+([str(archive)] if kind=='verify' else []),release_audit='PASS',snapshot=str(archive),publish_commands=['manual'])
    summary=f'VERDICT={verdict} STAGE={name} CYCLE={stage["cycle"]+1} MANIFEST=123456abcdef'
    assert kb.complete_task(conn,task.id,summary=summary,metadata=meta,expected_run_id=task.current_run_id)


def test_materialization_rollback_recovery_and_delivery(managed,tmp_path):
    kb,conn,root,_,_=managed;c=controller(kb)
    with pytest.raises(RuntimeError):
        with kb.write_txn(conn):
            c.reconcile(conn,root)
            raise RuntimeError('crash')
    assert stages(conn,root)==[]
    c.reconcile(conn,root);c.reconcile(conn,root)
    assert len(stages(conn,root))==1
    finish(kb,conn,stages(conn,root)[0],tmp_path)
    c.reconcile(conn,root)
    assert len(stages(conn,root))==2
    finish(kb,conn,stages(conn,root)[1],tmp_path)
    c.reconcile(conn,root)
    panel=[s for s in stages(conn,root) if s['kind'] in ('verify','review')]
    assert len(panel)==5
    for stage in panel[:-1]:finish(kb,conn,stage,tmp_path)
    assert c.reconcile(conn,root)['phase']=='reviewing'
    finish(kb,conn,panel[-1],tmp_path)
    assert c.reconcile(conn,root)['phase']=='delivered'
    assert kb.get_task(conn,root).status=='done'
    delivery=json.loads(kb.get_task(conn,root).result)
    assert Path(delivery['snapshot']).is_file()
    assert Path(delivery['snapshot']).name=='src-123456abcdef.tgz'
    assert len(stages(conn,root))==7
    c.reconcile(conn,root)
    assert len(stages(conn,root))==7


def test_reader_retry_then_human_review(managed,tmp_path):
    kb,conn,root,_,_=managed;c=controller(kb)
    for _ in range(2):
        c.reconcile(conn,root);finish(kb,conn,stages(conn,root)[-1],tmp_path)
    c.reconcile(conn,root)
    reader=stages(conn,root)[-1];finish(kb,conn,reader,tmp_path,invalid=True)
    c.reconcile(conn,root)
    retry=stages(conn,root)[-1]
    assert retry['evidence_retry']==1
    finish(kb,conn,retry,tmp_path,invalid=True)
    assert c.reconcile(conn,root)['phase']=='human_review'


def test_failure_creates_one_fixer_and_full_panel(managed,tmp_path):
    kb,conn,root,_,_=managed;c=controller(kb)
    for _ in range(2):
        c.reconcile(conn,root);finish(kb,conn,stages(conn,root)[-1],tmp_path)
    c.reconcile(conn,root)
    for stage in stages(conn,root)[2:]:finish(kb,conn,stage,tmp_path,fail=stage['kind']=='verify')
    assert c.reconcile(conn,root)['phase']=='repairing'
    c.reconcile(conn,root)
    repair=stages(conn,root)[-1]
    assert (repair['profile'],repair['cycle'])==('fixer',1)
    assert 'BASELINE 123456abcdef' in kb.get_task(conn,repair['task_id']).body
    finish(kb,conn,repair,tmp_path)
    c.reconcile(conn,root)
    assert len([s for s in stages(conn,root) if s['cycle']==1])==6
    panel=[s for s in stages(conn,root) if s['cycle']==1 and s['kind'] in ('review','verify')]
    for stage in panel:
        body=kb.get_task(conn,stage['task_id']).body
        assert 'BASELINE 123456abcdef' in body
        assert 'BASELINE_TGZ none' not in body
        assert 'verifier:F1' in body
        if stage['kind']=='verify':assert 'STAGE REVERIFY' in body
    finish(kb,conn,panel[0],tmp_path,invalid=True)
    controller(kb).reconcile(conn,root)
    retry=stages(conn,root)[-1]
    assert retry['evidence_retry']==1
    assert 'BASELINE 123456abcdef' in kb.get_task(conn,retry['task_id']).body
    assert 'verifier:F1' in kb.get_task(conn,retry['task_id']).body


def test_blocked_worker_can_resume_without_replacing_snapshot(managed,tmp_path):
    kb,conn,root,store,_=managed;c=controller(kb)
    c.reconcile(conn,root);stage=stages(conn,root)[0]
    task=kb.claim_task(conn,stage['task_id'])
    kb.block_task(conn,task.id,kind='needs_input',reason='environment',expected_run_id=task.current_run_id)
    assert c.reconcile(conn,root)['phase']=='blocked'
    sid=c._state.read_root(conn,root)['snapshot_id']
    c.resume(conn,root,'Environment restored; retry preparation')
    assert c._state.read_root(conn,root)['snapshot_id']==sid
    finish(kb,conn,stage,tmp_path)
    assert c.reconcile(conn,root)['phase']=='implementing'


def test_claim_without_worker_launch_cannot_advance(managed,tmp_path):
    kb,conn,root,_,_=managed;c=controller(kb)
    c.reconcile(conn,root)
    finish(kb,conn,stages(conn,root)[0],tmp_path,launched=False)
    assert c.reconcile(conn,root)['phase']=='human_review'
    assert len(stages(conn,root))==1


@pytest.mark.parametrize('managed,preparer,implementer,panel_size',[('bug','fixer','fixer',3),('chore','developer','developer',2)],indirect=['managed'])
def test_other_presets_deliver_with_captured_profiles(managed,tmp_path,preparer,implementer,panel_size):
    kb,conn,root,store,_=managed;c=controller(kb)
    from factory_dashboard.frozen_resolver import FrozenFactoryResolver
    path=Path(conn.execute('PRAGMA database_list').fetchone()[2])
    resolver=FrozenFactoryResolver(store,path,'default',lambda *args:None)
    for expected in (preparer,implementer):
        c.reconcile(conn,root);stage=stages(conn,root)[-1]
        assert stage['profile']==expected
        from dataclasses import asdict
        resolved=resolver.resolve(asdict(kb.get_task(conn,stage['task_id'])),path,'default')
        assert resolved['model']=='m'
        assert resolved['effort']=='medium'
        finish(kb,conn,stage,tmp_path)
    c.reconcile(conn,root)
    panel=stages(conn,root)[2:]
    assert len(panel)==panel_size
    for stage in panel:finish(kb,conn,stage,tmp_path)
    assert c.reconcile(conn,root)['phase']=='delivered'


def test_recovery_scan_only_returns_changed_roots(managed,tmp_path):
    kb,conn,root,_,_=managed;c=controller(kb)
    assert c._state.pending_roots(conn)==[root]
    c.reconcile(conn,root)
    assert c._state.pending_roots(conn)==[]
    finish(kb,conn,stages(conn,root)[0],tmp_path)
    assert c._state.pending_roots(conn)==[root]
    c.reconcile(conn,root)
    assert c._state.pending_roots(conn)==[]


@pytest.mark.parametrize('managed',[{'type':'chore','max_repairs':0},{'type':'chore','max_repairs':3}],indirect=True)
def test_captured_repair_limit_is_enforced_end_to_end(managed,tmp_path):
    kb,conn,root,_,_=managed;c=controller(kb)
    maximum=c._state.read_root(conn,root)['definition']['max_repairs']
    for _ in range(2):
        c.reconcile(conn,root);finish(kb,conn,stages(conn,root)[-1],tmp_path)
    for cycle in range(maximum+1):
        c.reconcile(conn,root)
        for stage in stages(conn,root):
            if stage['cycle']==cycle and stage['kind'] in ('verify','review'):
                finish(kb,conn,stage,tmp_path,fail=stage['kind']=='verify')
        state=c.reconcile(conn,root)
        if cycle==maximum:
            assert state['phase']=='human_review'
        else:
            assert state['phase']=='repairing'
            finish(kb,conn,stages(conn,root)[-1],tmp_path)
    assert len([s for s in stages(conn,root) if s['kind']=='repair'])==maximum


def test_concurrent_reconciliation_creates_one_stage(managed):
    from concurrent.futures import ThreadPoolExecutor
    from threading import Barrier
    from contextlib import closing
    from hermes_cli import kanban_db_connect
    kb,conn,root,_,_=managed
    path=Path(conn.execute('PRAGMA database_list').fetchone()[2]);barrier=Barrier(2)
    def reconcile():
        with closing(kanban_db_connect.connect(path,board='default')) as other:
            barrier.wait()
            return controller(kb).reconcile(other,root)
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(reconcile) for _ in range(2)]
        for future in futures:assert future.result()['phase']=='preparing'
    assert len(stages(conn,root))==1


def test_completed_blocked_writer_can_resume_current_frozen_stage(managed,tmp_path):
    kb,conn,root,_,_=managed;c=controller(kb)
    c.reconcile(conn,root);stage=stages(conn,root)[0]
    finish(kb,conn,stage,tmp_path,blocked=True)
    assert c.reconcile(conn,root)['phase']=='blocked'
    old_run=stages(conn,root)[0]['active_run_id']
    c.resume(conn,root,'Required environment is restored')
    assert kb.get_task(conn,stage['task_id']).status=='ready'
    assert stages(conn,root)[0]['active_run_id'] is None
    finish(kb,conn,stage,tmp_path)
    assert stages(conn,root)[0]['active_run_id']!=old_run
    assert c.reconcile(conn,root)['phase']=='implementing'

import tempfile
import unittest
from pathlib import Path
from dataclasses import asdict
from factory_dashboard.task_settings_store import TaskSettingsStore
from factory_dashboard.task_settings import RoleSettings
from factory_dashboard.workflow_types import CAPABILITIES
from factory_dashboard.workflow_templates import WorkflowTemplates
from factory_dashboard.workflow_capture import WorkflowCapture
from factory_dashboard.workflow_service import WorkflowService
from factory_dashboard.model_policy import ConfigurationError


class WorkflowServiceTests(unittest.TestCase):
    def test_edit_preview_and_historical_definition(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=TaskSettingsStore(Path(tmp)/'db')
            store.seed_defaults({p:RoleSettings('p','m','medium') for p in CAPABILITIES})
            templates=WorkflowTemplates(store);capture=WorkflowCapture(store,templates);capture.initialize()
            service=WorkflowService(templates,capture,store,lambda:{'ready':True})
            listing=service.list()
            self.assertEqual(3,len(listing['templates']))
            definition=service.preview({'type':'bug'})['workflow']
            self.assertEqual('fixer',definition['prepare']['profile'])
            saved=service.save(dict(definition,name='My bugs'),1)
            self.assertEqual(2,saved['revision'])
            self.assertEqual('Bug fix',service.get(saved['template_id'],1)['name'])
            with self.assertRaises(ConfigurationError):service.preview({'type':'bug','shell':'run'})

    def test_routes_enforce_local_origin_and_revision(self):
        import json
        from test_http_server import HttpTests
        fixture=HttpTests();fixture.setUp();self.addCleanup(fixture.doCleanups)
        store=TaskSettingsStore(Path(fixture.store.path).parent/'workflows.db')
        store.seed_defaults({p:RoleSettings('p','m','medium') for p in CAPABILITIES})
        templates=WorkflowTemplates(store);capture=WorkflowCapture(store,templates);capture.initialize()
        fixture.server.service.workflows=WorkflowService(templates,capture,store,lambda:{'ready':True})
        code,body=fixture.request('GET','/api/workflows');self.assertEqual(200,code)
        doc=json.loads(body)['templates'][0];doc.pop('archived');doc['name']='Edited'
        url='/api/workflows/'+doc['template_id']
        for headers in ({'Origin':'https://evil.test'},{'Host':'evil.test'},{'X-Factory-Token':''}):
            self.assertEqual(403,fixture.request('PUT',url,doc,headers)[0])
        self.assertEqual(200,fixture.request('PUT',url,doc)[0])
        self.assertEqual(409,fixture.request('PUT',url,doc)[0])
        code,old=fixture.request('GET',url+'?revision=1');self.assertEqual(200,code)
        self.assertEqual('Feature',json.loads(old)['name'])
        self.assertEqual(400,fixture.request('POST','/api/workflows/preview',{'type':'bug','capabilities':{}})[0])

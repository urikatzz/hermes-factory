import unittest
from factory_dashboard.workflow_handoffs import normalize_handoff
from factory_dashboard.workflow_gate import evaluate_cycle


def result(kind='implement', verdict=None, **changes):
    verdict = verdict or {'prepare':'DONE','implement':'DONE','repair':'DONE','review':'NO_BLOCKING_FINDINGS','verify':'PASS'}[kind]
    stage = dict(root_id='t_root',stage_key=kind,kind=kind,cycle=0,profile='worker',evidence_retry=0)
    metadata = dict(contract='factory-worker/v2', workflow_contract='factory-workflow/v1', root='t_root',stage_key=kind,stage=kind,cycle=1,verdict=verdict,
                    manifest_sha12='123456abcdef',ac_ids=['AC1'],ac_results={'AC1':'pass'},findings=[],artifacts=['/evidence/report.md','/evidence/src-123456abcdef.tgz'], release_audit='PASS',snapshot='/evidence/source.tgz',publish_commands=['manual command'])
    metadata.update(changes)
    run = dict(id=1,task_id='t_stage',profile='worker',claim_lock='owned',status='done',outcome='completed',summary=f'VERDICT={verdict} STAGE={kind} CYCLE=1 MANIFEST={metadata["manifest_sha12"]}',metadata=metadata)
    return normalize_handoff(dict(id='t_stage',status='done',current_run_id=1),run,stage)


class WorkflowGateTests(unittest.TestCase):
    def decide(self, writer=None, readers=None, repairs=0, maximum=3, previous=None, context=None):
        return evaluate_cycle(writer or result(), readers or [result('review'),result('verify')], previous, maximum, repairs, context or {})

    def test_same_manifest_and_acceptance_required(self):
        self.assertEqual('pass', self.decide().decision)
        self.assertEqual('human_review',self.decide(readers=[result('review',manifest_sha12='abcdef123456'),result('verify')]).decision)
        self.assertEqual('human_review',self.decide(readers=[result('verify',ac_results={})]).decision)
        self.assertEqual('human_review',self.decide(readers=[result('verify',release_audit='unknown')]).decision)

    def test_findings_and_repair_limits(self):
        for severity,ac,expected in [('BLOCKER','-','repair'),('HIGH','-','repair'),('MEDIUM','AC1','repair'),('MEDIUM','-','pass'),('LOW','-','pass')]:
            readers=[result('review',findings=[f'F1|{severity}|{ac}|a.py:1|problem']),result('verify')]
            self.assertEqual(expected,self.decide(readers=readers).decision)
        failures=[result('review',verdict='CHANGES_REQUIRED', findings=['F1|HIGH|-|a:1|bug']),result('verify')]
        self.assertEqual('human_review',self.decide(readers=failures,maximum=0).decision)
        self.assertEqual('human_review',self.decide(readers=failures,repairs=3).decision)
        self.assertEqual('repair',self.decide(readers=failures,repairs=2).decision)
        self.assertEqual('repair',self.decide(readers=[result('verify',findings_truncated=1)]).decision)

    def test_environment_no_progress_and_blocked_writer(self):
        self.assertEqual('blocked',self.decide(writer=result(verdict='BLOCKED',blocked_reason='tool unavailable')).decision)
        self.assertEqual('human_review',self.decide(readers=[result('verify',ac_results={'AC1':'unverified:environment'})]).decision)
        self.assertEqual('human_review',self.decide(readers=[result('verify',blocked_tools=[{'needed_for':'security'}])]).decision)
        self.assertEqual('human_review',self.decide(readers=[result('verify',verdict='FAIL',preexisting=True)]).decision)
        self.assertEqual('repair',self.decide(readers=[result('verify',ac_results={'AC1':'unverified:code'})]).decision)
        unity=result('verify',ac_results={'AC1':'unverified:environment'},environment_gaps={'AC1':'unity_editor'})
        self.assertEqual('pass',self.decide(readers=[unity],context={'unity_ci':True}).decision)
        self.assertEqual('human_review',self.decide(readers=[unity],context={}).decision)
        repeated=[result('review',findings=['F1|HIGH|-|a:1|same']),result('verify')]
        self.assertEqual('human_review',self.decide(writer=result('repair',rejected_findings=['F1']),readers=repeated,previous={'blocking':['worker:F1|HIGH|-|a:1|same']}).decision)

    def test_stale_and_missing_run_or_contract_cannot_count(self):
        stage=dict(root_id='r',stage_key='review',kind='review',cycle=0,profile='p')
        stale=normalize_handoff({'id':'t','status':'done','current_run_id':2},{'id':1},stage)
        self.assertFalse(stale.valid)
        self.assertFalse(result('review',contract='unknown').valid)
        self.assertFalse(result('review',artifacts=[]).valid)
        self.assertEqual('human_review',self.decide(writer=result(contract='unknown')).decision)

    def test_waived_findings_are_recorded(self):
        gate=self.decide(readers=[result('review',findings=['F1|MEDIUM|-|a:1|cosmetic']),result('verify')])
        self.assertTrue(gate.waived)

    def test_verification_requires_delivery_artifacts(self):
        for missing in ({'artifacts':['/evidence/report.md']},{'artifacts':['/evidence/src-abcdef123456.tgz']},{'publish_commands':[]},{'publish_commands':'command'}):
            with self.subTest(missing=missing):
                self.assertFalse(result('verify',**missing).valid)

    def test_malformed_environment_evidence_is_invalid(self):
        self.assertFalse(result('verify',environment_gaps=['unity_editor']).valid)

    def test_verifier_snapshot_uses_retained_manifest_archive(self):
        retained='/retained/src-123456abcdef.tgz'
        verified=result('verify',snapshot='/scratch/deleted/src-123456abcdef.tgz',artifacts=['/retained/report.md',retained])
        self.assertTrue(verified.valid)
        self.assertEqual(retained,verified.metadata['snapshot'])
        self.assertFalse(result('verify',snapshot='/scratch/src-123456abcdef.tgz',artifacts=['/retained/report.md','/retained/src-abcdef123456.tgz']).valid)

    def test_large_snapshot_is_explicitly_unattached(self):
        verified=result('verify',snapshot='/deleted/src-123456abcdef.tgz',snapshot_attached=False,artifacts=['/retained/report.md'])
        self.assertTrue(verified.valid)
        self.assertIsNone(verified.metadata['snapshot'])

    def test_unity_only_fail_is_waived_without_hiding_real_failures(self):
        unity=result('verify',verdict='FAIL',ac_results={'AC1':'unverified:environment'},environment_gaps={'AC1':'unity_editor'},checks_failed=0)
        self.assertEqual('pass',self.decide(readers=[unity],context={'unity_ci':True}).decision)
        audit=result('verify',verdict='FAIL',ac_results={'AC1':'unverified:environment'},environment_gaps={'AC1':'unity_editor'},release_audit='FAIL')
        self.assertEqual('repair',self.decide(readers=[audit],context={'unity_ci':True}).decision)
        check=result('verify',verdict='FAIL',ac_results={'AC1':'unverified:environment'},environment_gaps={'AC1':'unity_editor'},checks_failed=1,failed_checks=['unit tests'])
        self.assertEqual('repair',self.decide(readers=[check],context={'unity_ci':True}).decision)

    def test_preexisting_checks_are_normalized_and_scoped(self):
        for checks in ([{'cmd':'unit tests','preexisting':True}],['preexisting: unit tests']):
            verified=result('verify',verdict='FAIL',checks_failed=1,failed_checks=checks)
            self.assertEqual('human_review',self.decide(readers=[verified]).decision)
        invalid=result('verify',failed_checks=[{'cmd':'audit','preexisting':'yes'}])
        self.assertFalse(invalid.valid)

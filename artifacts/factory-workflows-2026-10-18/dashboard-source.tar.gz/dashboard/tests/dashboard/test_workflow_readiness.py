import tempfile
import unittest
from pathlib import Path
from factory_dashboard.task_settings_store import TaskSettingsStore
from factory_dashboard.task_settings import RoleSettings
from factory_dashboard.workflow_types import CAPABILITIES
from factory_dashboard.workflow_capture import WorkflowCapture
from factory_dashboard.workflow_templates import WorkflowTemplates
from factory_dashboard.workflow_service import WorkflowService, WorkflowDashboard
from factory_dashboard.model_policy import ConfigurationError


class WorkflowReadinessTests(unittest.TestCase):
    def test_missing_enforcement_blocks_new_submissions(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=TaskSettingsStore(Path(tmp)/'db')
            store.seed_defaults({p:RoleSettings('p','m','medium') for p in CAPABILITIES})
            templates=WorkflowTemplates(store);capture=WorkflowCapture(store,templates);capture.initialize();capture.set_enabled(True)
            service=WorkflowService(templates,capture,store,lambda:{'ready':False})
            self.assertFalse(service.list()['enabled'])
            class Adapter:
                def submit(self,payload):
                    raise AssertionError('Submission must not reach intake')
            dashboard=WorkflowDashboard(Adapter(),service,store,'b',lambda _:None)
            with self.assertRaisesRegex(ConfigurationError,'enforcement'):
                dashboard.submit({'submission_id':'00000000-0000-4000-8000-000000000001'})

    def test_prepared_unqueued_retry_still_requires_enforcement(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=TaskSettingsStore(Path(tmp)/'db')
            store.seed_defaults({p:RoleSettings('p','m','medium') for p in CAPABILITIES})
            templates=WorkflowTemplates(store);capture=WorkflowCapture(store,templates);capture.initialize();capture.set_enabled(True)
            payload={'submission_id':'00000000-0000-4000-8000-000000000001','defaults_revision':1}
            store.prepare_submission('b',payload)
            service=WorkflowService(templates,capture,store,lambda:{'ready':False})
            class Adapter:
                def submission_status(self,identity):return {'ticket_id':None,'state':'prepared'}
                def submit(self,payload):raise AssertionError('Unqueued retry reached intake')
            dashboard=WorkflowDashboard(Adapter(),service,store,'b',lambda _:None)
            with self.assertRaisesRegex(ConfigurationError,'enforcement'):dashboard.submit(payload)

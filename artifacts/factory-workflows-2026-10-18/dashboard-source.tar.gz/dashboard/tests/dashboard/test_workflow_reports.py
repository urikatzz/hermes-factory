import tempfile
import unittest
from pathlib import Path
from factory_dashboard.workflow_service import WorkflowDashboard
from factory_dashboard.workflow_capture import WorkflowCapture
from factory_dashboard.workflow_templates import WorkflowTemplates
from factory_dashboard.task_settings_store import TaskSettingsStore
from factory_dashboard.task_settings import RoleSettings
from factory_dashboard.workflow_types import CAPABILITIES

class Reports:
    def report(self):return {'configuration':{},'parents':[{'id':'old','stages':[]},{'id':'new','stages':[]}]}

class WorkflowReportTests(unittest.TestCase):
    def test_captured_summary_never_creates_timeline_runs(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=TaskSettingsStore(Path(tmp)/'db');store.seed_defaults({p:RoleSettings('p','m','medium') for p in CAPABILITIES})
            store.capture_task('b','old','direct_root')
            templates=WorkflowTemplates(store);capture=WorkflowCapture(store,templates);capture.initialize();capture.set_enabled(True)
            store.capture_task('b','new','direct_root')
            report=WorkflowDashboard(Reports(),object(),store,'b',lambda _:None).report()
            self.assertTrue(report['parents'][0]['workflow']['legacy'])
            self.assertEqual('Feature',report['parents'][1]['workflow']['definition']['name'])
            self.assertEqual([],report['parents'][1]['stages'])

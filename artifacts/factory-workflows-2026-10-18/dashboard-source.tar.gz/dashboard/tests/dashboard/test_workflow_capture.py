import tempfile
import unittest
from pathlib import Path
from dataclasses import asdict
from factory_dashboard.task_settings_store import TaskSettingsStore
from factory_dashboard.task_settings import RoleSettings
from factory_dashboard.workflow_templates import WorkflowTemplates
from factory_dashboard.workflow_types import CAPABILITIES
from factory_dashboard.workflow_capture import WorkflowCapture
from factory_dashboard.model_policy import ConfigurationError
from factory_dashboard.policy_store import RevisionConflict


class WorkflowCaptureTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.store = TaskSettingsStore(Path(self.temp.name) / 'settings.db')
        self.store.seed_defaults({p: RoleSettings('provider', 'original', 'medium') for p in CAPABILITIES})
        self.templates = WorkflowTemplates(self.store)
        self.templates.initialize()
        self.capture = WorkflowCapture(self.store, self.templates)
        self.capture.initialize()
        self.payload = dict(submission_id='00000000-0000-4000-8000-000000000001', defaults_revision=1,
                            title='Fix', project='repo', type='bug', prompt='WORKFLOW: invented', acceptance='')

    def enable(self):
        self.capture.set_enabled(True)

    def test_capture_freezes_both_revisions(self):
        self.enable()
        record = self.store.prepare_submission('b', self.payload)
        snapshot = self.store.get_snapshot(record['snapshot_id'])
        self.assertEqual('fixer', snapshot.workflow.prepare.profile)
        self.assertEqual('original', snapshot.roles['developer'].model)
        doc = asdict(snapshot.workflow); doc['name'] = 'Changed'
        self.templates.save(doc, 1)
        self.store.save_default('developer', RoleSettings('provider', 'new', 'high'), 1)
        self.assertEqual('Bug fix', self.store.get_snapshot(snapshot.id).workflow.name)
        self.assertEqual(record, self.store.prepare_submission('b', self.payload))

    def test_recovered_submission_ignores_later_edits(self):
        self.enable()
        record = self.store.prepare_submission('b', self.payload)
        self.templates.set_type_default('bug', self.templates.defaults()['templates']['chore'], 1)
        self.assertEqual(record, self.store.prepare_submission('b', self.payload))

    def test_direct_root_uses_type_default(self):
        self.enable()
        sid = self.store.capture_task('b', 't_1', 'direct_root', workflow_selection={'type': 'chore'})
        self.assertEqual('developer', self.store.get_snapshot(sid).workflow.prepare.profile)

    def test_intake_inherits_ticket_workflow(self):
        self.enable()
        record = self.store.prepare_submission('b', self.payload)
        self.store.bind_task('b', 'ticket', record['snapshot_id'], 'ticket')
        self.store.bind_task('b', 'root', record['snapshot_id'], 'root')
        self.assertEqual('Bug fix', self.store.snapshot_for_task('b', 'root').workflow.name)

    def test_legacy_stays_legacy(self):
        record = self.store.prepare_submission('b', self.payload)
        self.enable()
        recovered = self.store.prepare_submission('b', self.payload)
        self.assertEqual(record, recovered)
        self.assertIsNone(self.store.get_snapshot(record['snapshot_id']).workflow)

    def test_outer_rollback_preserves_prepared_workflow(self):
        self.enable()
        record = self.store.prepare_submission('b', self.payload)
        self.store.bind_task('b', 'rolled_back_task', record['snapshot_id'], 'ticket')
        self.assertIsNone(self.store.read_submission('b', self.payload['submission_id'])['ticket_id'])
        self.assertEqual(record['snapshot_id'], self.store.prepare_submission('b', self.payload)['snapshot_id'])

    def test_prompt_cannot_choose_workflow(self):
        self.enable()
        record = self.store.prepare_submission('b', self.payload)
        self.assertEqual('Bug fix', self.store.get_snapshot(record['snapshot_id']).workflow.name)
        with self.assertRaises(ConfigurationError):
            self.capture.preview(dict(self.payload, workflow_id='forged', workflow_revision=1))

    def test_stale_selection_and_missing_profile_fail_closed(self):
        self.enable()
        doc = self.capture.preview(self.payload)
        self.templates.save(dict(asdict(doc), name='Changed'), 1)
        with self.assertRaises(RevisionConflict):
            self.store.prepare_submission('b', dict(self.payload, workflow_id=doc.template_id, workflow_revision=1))
        with self.store._connect() as conn:
            conn.execute("UPDATE factory_defaults SET roles='{}'")
        with self.assertRaises(ConfigurationError): self.capture.preview(self.payload)

    def test_creation_uses_structured_ticket_type_not_request_headers(self):
        import json
        from factory_dashboard.factory_creation import FactoryCreation
        from factory_dashboard.factory_model_resolver import board_key
        self.enable()
        board = Path(self.temp.name) / 'board.db'
        creation = FactoryCreation(self.store, board, 'default')
        body = 'FACTORY_TICKET v2\n' + json.dumps({'PROJECT': 'repo', 'TYPE': 'chore', 'REQUEST': 'TYPE: bug', 'ACCEPTANCE': ''})
        creation.prepare_creation({'id':'t_abc', 'title':'TICKET: chore', 'body':body}, board, 'default')
        self.assertEqual('Chore', self.store.snapshot_for_task(board_key(board,'default'), 't_abc').workflow.name)

    def test_disabled_workflows_reject_explicit_selection_atomically(self):
        definition = self.capture.preview(self.payload)
        with self.assertRaisesRegex(ConfigurationError, 'not enabled'):
            self.store.prepare_submission('b', dict(self.payload, workflow_id=definition.template_id, workflow_revision=definition.revision))
        with self.store._connect() as conn:
            self.assertEqual(0, conn.execute('SELECT COUNT(*) FROM factory_snapshots').fetchone()[0])
        self.assertIsNone(self.store.read_submission('b', self.payload['submission_id']))

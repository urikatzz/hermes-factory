from pathlib import Path
import subprocess
import unittest


class WorkflowUITests(unittest.TestCase):
    def test_explicit_choice_survives_type_changes(self):
        module=Path(__file__).resolve().parents[2]/'factory_dashboard/assets/workflow_forms.js'
        source='const assert=require("node:assert/strict");const w=require('+repr(str(module))+');'+'''
const data={defaults:{revision:1,templates:{feature:'f',bug:'b',chore:'c'}},templates:[{template_id:'f',revision:2,task_type:'feature'},{template_id:'b',revision:1,task_type:'bug'},{template_id:'c',revision:3,task_type:'chore'}]};
const selection=w.selection(data,'feature');assert.equal(selection.value().workflow_id,'f');
selection.changeType('bug');assert.equal(selection.value().workflow_id,'b');
selection.choose('f');selection.changeType('chore');assert.equal(selection.value().workflow_id,'f');assert(selection.mismatch());
const refreshed=structuredClone(data);refreshed.defaults.revision=2;refreshed.templates[0].revision=3;
selection.refresh(refreshed);assert.equal(selection.value().workflow_id,'f');assert.equal(selection.value().workflow_revision,3);
refreshed.templates[0].archived=true;selection.refresh(refreshed);assert.throws(()=>selection.value(),/active workflow/);
selection.choose('c');assert.equal(selection.value().workflow_id,'c');
assert.deepEqual(w.allowedProfiles({developer:['prepare','implement'],fixer:['repair'],verifier:['verify']},'verify'),['verifier']);
assert.equal(w.summaryText({legacy:true}),'Legacy workflow');
'''
        result=subprocess.run(['node','-e',source],text=True,capture_output=True)
        self.assertEqual(0,result.returncode,result.stderr)

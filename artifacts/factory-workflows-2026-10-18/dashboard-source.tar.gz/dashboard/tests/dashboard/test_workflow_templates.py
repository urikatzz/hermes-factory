"""Revision loss or permissive stage validation would break these contracts."""
import copy
import sqlite3
import tempfile
import unittest
from dataclasses import asdict
from pathlib import Path
from factory_dashboard.model_policy import ConfigurationError
from factory_dashboard.policy_store import RevisionConflict
from factory_dashboard.task_settings_store import TaskSettingsStore
from factory_dashboard.workflow_templates import WorkflowTemplates


class WorkflowTemplateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / 'settings.db'
        self.store = TaskSettingsStore(self.path)
        self.templates = WorkflowTemplates(self.store)
        self.templates.initialize()

    def document(self, kind='feature'):
        mapping = self.templates.defaults()
        return asdict(self.templates.get(mapping['templates'][kind]))

    def test_presets_and_capabilities(self):
        expected = {'feature': ('architect', 'developer', ['claude-reviewer', 'security-reviewer', 'ux-reviewer', 'ui-reviewer']), 'bug': ('fixer', 'fixer', ['claude-reviewer', 'security-reviewer']), 'chore': ('developer', 'developer', ['claude-reviewer'])}
        for kind, (prepare, implement, reviewers) in expected.items():
            doc = self.document(kind)
            self.assertEqual((prepare, implement), (doc['prepare']['profile'], doc['implement']['profile']))
            self.assertEqual(reviewers, [s['profile'] for s in doc['reviewers']])
            self.assertEqual('verifier', doc['verify']['profile'])
            doc['reviewers'] += ({'key': 'codex', 'kind': 'review', 'profile': 'codex-reviewer', 'instructions': ''},)
            self.assertEqual(len(reviewers) + 1, len(self.templates.save(doc, 1).reviewers))

    def test_revision_is_immutable(self):
        original = self.document()
        changed = copy.deepcopy(original)
        changed['name'] = 'My feature'
        saved = self.templates.save(changed, 1)
        self.assertEqual(2, saved.revision)
        self.assertEqual('Feature', self.templates.get(saved.template_id, 1).name)
        with self.assertRaises(RevisionConflict):
            self.templates.save(changed, 1)
        self.assertEqual('My feature', WorkflowTemplates(self.store).get(saved.template_id).name)

    def test_archive_requires_replacement_default(self):
        doc = self.document()
        old_id = doc['template_id']
        with self.assertRaises(ConfigurationError):
            self.templates.archive(old_id, 1)
        doc.pop('template_id'); doc.pop('revision'); doc['name'] = 'Replacement'
        replacement = self.templates.save(doc, 0)
        self.templates.set_type_default('feature', replacement.template_id, self.templates.defaults()['revision'])
        self.templates.archive(old_id, 1)
        self.assertNotIn(old_id, [t['template_id'] for t in self.templates.list()])
        self.assertEqual('Feature', self.templates.get(old_id, 1).name)
        self.templates.restore(old_id, 1)
        self.assertIn(old_id, [t['template_id'] for t in self.templates.list()])

    def test_invalid_writer_review_and_limits(self):
        for limit in (-1, 4, True, 1.5):
            doc = self.document(); doc['max_repairs'] = limit
            with self.subTest(limit=limit), self.assertRaises(ConfigurationError):
                self.templates.save(doc, 1)
        for limit in (0, 3):
            doc = self.document(); doc['max_repairs'] = limit
            self.templates.save(doc, doc['revision'])
        for profile in ('developer', 'fixer', 'unknown'):
            doc = self.document(); doc['reviewers'][0]['profile'] = profile
            with self.subTest(profile=profile), self.assertRaises(ConfigurationError):
                self.templates.save(doc, doc['revision'])
        doc = self.document(); doc['reviewers'] = ()
        with self.assertRaises(ConfigurationError): self.templates.save(doc, doc['revision'])
        doc = self.document(); doc['reviewers'] += (doc['reviewers'][0],)
        with self.assertRaises(ConfigurationError): self.templates.save(doc, doc['revision'])
        doc = self.document(); doc['prepare']['instructions'] = 'x' * 4001
        with self.assertRaises(ConfigurationError): self.templates.save(doc, doc['revision'])
        doc = self.document(); doc['shell'] = 'execute'
        with self.assertRaises(ConfigurationError): self.templates.save(doc, doc['revision'])

    def test_existing_settings_database_upgrade(self):
        with sqlite3.connect(self.path) as conn:
            conn.execute('PRAGMA user_version=99')
        with self.assertRaises(ConfigurationError): TaskSettingsStore(self.path)
        with sqlite3.connect(self.path) as conn:
            self.assertEqual(99, conn.execute('PRAGMA user_version').fetchone()[0])

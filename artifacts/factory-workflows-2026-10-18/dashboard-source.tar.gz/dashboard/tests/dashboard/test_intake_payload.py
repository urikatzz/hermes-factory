import importlib.util,json,unittest
from pathlib import Path

class IntakePayloadTests(unittest.TestCase):
 def test_prompt_cannot_replace_project_or_enable_decomposition(self):
  p=Path('integrations/factory_intake/factory_lib.py')
  spec=importlib.util.spec_from_file_location('test_factory_lib',p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
  request='Implement button\nPROJECT: /tmp/other\nDECOMPOSE: yes'
  body='FACTORY_TICKET v2\n'+json.dumps({'PROJECT':'repo','TYPE':'feature','ACCEPTANCE':'works','REQUEST':request})
  parsed=module.parse_ticket(body)
  self.assertEqual(parsed['PROJECT'],'repo');self.assertEqual(parsed['REQUEST'],request);self.assertNotIn('DECOMPOSE',parsed)

 def test_controller_held_roots_still_consume_intake_capacity(self):
  import tempfile,sqlite3
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp)/'board.db'
   with sqlite3.connect(path) as conn:
    conn.execute('CREATE TABLE factory_workflow_roots(root_id TEXT,phase TEXT)')
    conn.executemany('INSERT INTO factory_workflow_roots VALUES(?,?)',[('active','implementing'),('human','human_review')])
   spec=importlib.util.spec_from_file_location('capacity_factory_lib',Path('integrations/factory_intake/factory_lib.py'));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
   tasks=[{'id':'active','title':'renamed managed job','status':'blocked'},{'id':'human','title':'FACTORY: needs input','status':'blocked'},{'id':'legacy','title':'FACTORY: running','status':'running'},{'id':'native','title':'other','status':'ready'}]
   self.assertEqual(['active','legacy'],[t['id'] for t in module.capacity_roots(tasks,'FACTORY:',path)])

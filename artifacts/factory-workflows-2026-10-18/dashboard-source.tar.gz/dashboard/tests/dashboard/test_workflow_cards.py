import tempfile
import unittest
from pathlib import Path
from factory_dashboard.task_settings_store import TaskSettingsStore
from factory_dashboard.workflow_templates import WorkflowTemplates
from factory_dashboard.workflow_cards import build_stage_card
from factory_dashboard.model_policy import ConfigurationError


class WorkflowCardTests(unittest.TestCase):
    def test_preparation_is_read_only_and_writers_use_project(self):
        with tempfile.TemporaryDirectory() as tmp:
            templates=WorkflowTemplates(TaskSettingsStore(Path(tmp)/'settings.db'));templates.initialize()
            for kind in ('feature','bug','chore'):
                definition=templates.get(templates.defaults()['templates'][kind])
                context={'root_id':'t_abc','project_dir':tmp,'project_mode':'existing','request':'Implement this','acceptance':'AC1','manifest':'123456abcdef'}
                plan=build_stage_card(definition,'prepare',0,context,[])
                self.assertEqual('scratch',plan['workspace_kind'])
                self.assertEqual(definition.prepare.profile,plan['assignee'])
                self.assertIn('PLAN.md',plan['body']);self.assertIn('Manifest include list',plan['body']);self.assertIn('Include .factory/PLAN.md and .factory/include.txt',plan['body'])
                implementation=build_stage_card(definition,'implement',0,context,['t_plan'])
                self.assertEqual(('dir',tmp),(implementation['workspace_kind'],implementation['workspace_path']))
                review=build_stage_card(definition,definition.reviewers[0].key,1,context,['t_fix'])
                self.assertEqual('scratch',review['workspace_kind'])
                self.assertIn('123456abcdef',review['body'])
                self.assertIn('CYCLE 2',review['body'])
                with self.assertRaises(ConfigurationError):
                    build_stage_card(definition,'missing',0,context,[])
